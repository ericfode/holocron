import copy
import json
from pathlib import Path
import tempfile
import unittest

import accounting as A


def config():
    value = dict(limits=copy.deepcopy(A.CAPS), arms=["correct", "id", "untrained", "wrong"],
                 updates_per_arm=200, optimizer_updates=800, training_forwards=800,
                 evaluation_forwards=8, export_forwards=0, pins=[{"fixture": "pure accounting test; no model/source loaded"}])
    value["config_sha256"] = A.digest(value)
    return value


def reservation(phase="card", updates=200):
    return dict(phase=phase, active_seconds=10., native_applies=0 if phase != "native" else 256,
                optimizer_updates=updates if phase == "card" else 0,
                training_forwards=updates if phase == "card" else 0,
                evaluation_forwards=2 if phase == "card" else 0, export_forwards=0)


class AccountingTests(unittest.TestCase):
    def initialized(self, root):
        path = root / "ledger.jsonl"
        A.initialize(path, {"status": "test-only-no-workload"})
        return path

    def freeze(self, path):
        with A.lease(path) as (stream, rows, _):
            A.append(stream, rows, path, "frozen", config())

    def test_unfrozen_launch_and_duplicate_initialize_are_blocked(self):
        with tempfile.TemporaryDirectory() as name:
            path = self.initialized(Path(name)); before = path.read_bytes()
            with A.lease(path) as (stream, rows, _), self.assertRaises(ValueError):
                A.append(stream, rows, path, "attempt-start", {"attempt": 1, "reservation": reservation()})
            self.assertEqual(path.read_bytes(), before)
            with self.assertRaises(FileExistsError): A.initialize(path, {})

    def test_pending_attempt_blocks_a_new_lease_and_copy_to_new_path(self):
        with tempfile.TemporaryDirectory() as name:
            root = Path(name); path = self.initialized(root); self.freeze(path)
            with A.lease(path) as (stream, rows, _):
                A.append(stream, rows, path, "attempt-start", {"attempt": 1, "reservation": reservation()})
            with self.assertRaisesRegex(ValueError, "unfinished"):
                with A.lease(path): pass
            copied = root / "reset.jsonl"; copied.write_bytes(path.read_bytes())
            with self.assertRaisesRegex(ValueError, "fixed"):
                with A.lease(copied): pass

    def test_failed_fit_debits_elapsed_and_reserved_updates_and_forwards(self):
        with tempfile.TemporaryDirectory() as name:
            path = self.initialized(Path(name)); self.freeze(path)
            with A.lease(path) as (stream, rows, _):
                A.append(stream, rows, path, "attempt-start", {"attempt": 1, "reservation": reservation()})
                value = A.append(stream, rows, path, "attempt-finish", dict(attempt=1, status="failed", active_seconds=2.5,
                    native_applies=0, native_journal_verified=True, observed_optimizer_updates=17,
                    training_forwards=17, evaluation_forwards=0, export_forwards=0))
                self.assertEqual(value["optimizer_updates"], 200)
                self.assertEqual(value["observed_optimizer_updates"], 17)
                self.assertEqual(value["training_forwards"], 200)
                self.assertEqual(value["observed_training_forwards"], 17)
                self.assertEqual(value["evaluation_forwards"], 2)
                self.assertEqual(value["active_seconds"], 2.5)
                with self.assertRaises(ValueError): A.append(stream, rows, path, "frozen", config())
                with self.assertRaises(ValueError): A.append(stream, rows, path, "credit", {"updates": 200})

    def test_unverified_native_journal_consumes_reserved_applies(self):
        with tempfile.TemporaryDirectory() as name:
            path = self.initialized(Path(name)); self.freeze(path)
            with A.lease(path) as (stream, rows, _):
                A.append(stream, rows, path, "attempt-start", {"attempt": 1, "reservation": reservation("native")})
                current = A.append(stream, rows, path, "attempt-finish", dict(attempt=1, status="failed", active_seconds=3,
                    native_applies=2, native_journal_verified=False, observed_optimizer_updates=0,
                    training_forwards=0, evaluation_forwards=0, export_forwards=0))
                self.assertEqual(current["native_applies"], 256)
                with self.assertRaises(ValueError):
                    A.append(stream, rows, path, "attempt-start", {"attempt": 2, "reservation": reservation("native")})

    def test_tamper_and_refreeze_with_more_budget_fail(self):
        with tempfile.TemporaryDirectory() as name:
            path = self.initialized(Path(name)); self.freeze(path)
            rows = [json.loads(x) for x in path.read_text().splitlines()]
            rows[-1]["data"]["optimizer_updates"] = 1200
            with self.assertRaises(ValueError): A.state(rows, path)
            changed = config(); changed["limits"]["active_seconds"] = 181
            changed["config_sha256"] = A.digest({k: v for k, v in changed.items() if k != "config_sha256"})
            with self.assertRaises(ValueError): A.validate_config(changed)

    def test_overrun_is_retained_as_failed_debit_and_stops_all_future_work(self):
        with tempfile.TemporaryDirectory() as name:
            path = self.initialized(Path(name)); self.freeze(path)
            with A.lease(path) as (stream, rows, _):
                A.append(stream, rows, path, "attempt-start", {"attempt": 1, "reservation": reservation("native")})
                current = A.append(stream, rows, path, "attempt-finish", dict(attempt=1, status="failed", active_seconds=91,
                    native_applies=257, native_journal_verified=True, observed_optimizer_updates=0,
                    training_forwards=0, evaluation_forwards=0, export_forwards=0))
                self.assertEqual(current["native_applies"], 257)
                self.assertTrue(current["ceiling_violated"])
                with self.assertRaises(ValueError):
                    A.append(stream, rows, path, "attempt-start", {"attempt": 2, "reservation": reservation()})


if __name__ == "__main__": unittest.main()
