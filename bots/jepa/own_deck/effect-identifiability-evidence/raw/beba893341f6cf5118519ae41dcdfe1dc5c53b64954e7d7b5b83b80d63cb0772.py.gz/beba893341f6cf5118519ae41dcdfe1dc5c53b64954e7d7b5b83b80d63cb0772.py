"""Run one pinned data-only command group under shared other30s. Preview default."""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
HERE=Path(__file__).resolve().parent
ACCOUNTING_SHA='a72d3ccc9bb381ba626032481d1bbb980236e302a6d532b0960e11445df8e0f9'
STAGES={'converter':10.,'independent-data':5.,'seal-preflight':5.,'result-verifier':5.}
READERS=HERE.parent.parent/'holocron-deck-context/bots/jepa/own_deck/native_effect_v2_collector/supervise.py'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
    p=Path(p).resolve();return dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
def load(p,name):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def verify(pins):
    for p in pins:
        if pin(p['path'])!=p:raise ValueError('pinned analysis input differs: '+p['path'])
def descriptor(path):
    d=json.loads(path.read_text())
    if d['stage'] not in STAGES or not math.isfinite(d['max_seconds']) or not 0<d['max_seconds']<=STAGES[d['stage']]:raise ValueError('fixed per-stage data-only ceiling required')
    if d.get('zero_neural_native_reviewed') is not True or not d.get('pins') or not d.get('commands'):raise ValueError('reviewed data-only exact command and pins required')
    verify(d['pins'])
    for command in d['commands']:
        argv=command['argv'];i=2 if len(argv)>1 and argv[1]=='-B' else 1
        if len(argv)<=i or not Path(argv[0]).is_absolute() or not Path(argv[0]).is_file() or not Path(argv[i]).is_absolute() or not argv[i].endswith('.py'):raise ValueError('direct absolute Python script argv required; no shell/-c/-m/isolation flags')
        if not any(p['path']==str(Path(argv[i]).resolve())for p in d['pins']):raise ValueError('script is not pinned')
        if not Path(command['cwd']).is_absolute()or not Path(command['cwd']).is_dir():raise ValueError('absolute existing cwd required')
        if set(command.get('env',{}))-{'PYTHONPATH'}:raise ValueError('only reviewed cached PYTHONPATH may be supplied')
        if any(x in argv for x in ('--execute','--fit','--train','--collect','--freeze')):raise ValueError('workload mode forbidden in analysis phase')
    return d

def run(command_path,out,ledger,execute=False):
    d=descriptor(command_path)
    if sha(HERE/'accounting.py')!=ACCOUNTING_SHA:raise ValueError('accounting source changed')
    A=load(HERE/'accounting.py','analysis_accounting')
    metadata=dict(command=pin(command_path),runner=pin(__file__),guard=pin(HERE/'analysis_guard/sitecustomize.py'),process_readers=pin(READERS),pins=d['pins'],argvs=d['commands'])
    if not execute:return dict(status='preview-no-execution',metadata=metadata,allocation=dict(phase='other',max_seconds=d['max_seconds'],native_applies=0,optimizer_updates=0,neural_forwards=0))
    if out.exists():raise FileExistsError('preserve analysis attempt directory')
    with A.lease(ledger)as(stream,rows,current):
        if not current['frozen']:raise ValueError('root-frozen campaign required')
        if any(r['event']=='attempt-start' and r['data']['metadata'].get('analysis_stage')==d['stage']for r in rows):raise ValueError('one attempt per predeclared analysis stage; no implicit retry')
        seconds=min(d['max_seconds'],30-current['phase_seconds']['other'],180-current['active_seconds'])
        if seconds<=0:raise ValueError('other/shared time exhausted')
        reservation=dict(phase='other',active_seconds=seconds,native_applies=0,optimizer_updates=0,training_forwards=0,evaluation_forwards=0,export_forwards=0)
        attempt=current['attempts']+1;out.mkdir(parents=True)
        A.append(stream,rows,ledger,'attempt-start',dict(attempt=attempt,reservation=reservation,metadata=dict(analysis_stage=d['stage'],**metadata)))
        start=time.monotonic();status='failed';error=None;receipts=[];peak=0;child=None
        try:
            reader=load(READERS,'analysis_live_rss');rss,members=reader.process_readers()
            for index,command in enumerate(d['commands']):
                verify(d['pins']);proof=out/f'child-{index}-proof.json';env=os.environ.copy();env.update(command.get('env',{}));env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',EFFECT_ANALYSIS_PROOF=str(proof.resolve()))
                env['PYTHONPATH']=str(HERE/'analysis_guard')+os.pathsep+env.get('PYTHONPATH','')
                for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):env[k]='1'
                with (out/f'child-{index}.stdout').open('wb')as stdout,(out/f'child-{index}.stderr').open('wb')as stderr:
                    child=subprocess.Popen(command['argv'],cwd=command['cwd'],env=env,stdout=stdout,stderr=stderr,start_new_session=True)
                    while child.poll()is None:
                        if time.monotonic()-start>=seconds:raise TimeoutError('data-only active wall timeout')
                        group=members(child.pid)
                        if any(pid!=child.pid for pid in group):raise RuntimeError('analysis spawned an unapproved process')
                        try:owned=rss(os.getpid())+sum(rss(pid)for pid in group)
                        except OSError:
                            if child.poll()is not None:break
                            raise
                        peak=max(peak,owned)
                        if peak>1073741824:raise MemoryError('1GiB sampled supervisor+owned-child RSS')
                        time.sleep(.01)
                    child.wait()
                if child.returncode!=0:raise RuntimeError('analysis child exit '+str(child.returncode))
                evidence=json.loads(proof.read_text())
                if not evidence.get('guard_loaded')or evidence['violations']or evidence['neural_modules_loaded']:raise RuntimeError('missing/failed zero-neural/native child proof')
                receipts.append(dict(argv=command['argv'],returncode=child.returncode,proof=pin(proof)));child=None
            verify(d['pins']);verify([metadata[k]for k in ('runner','guard','process_readers')]);status='completed'
        except BaseException as caught:error=dict(type=type(caught).__name__,message=str(caught))
        finally:
            if child is not None and child.poll()is None:
                os.killpg(child.pid,signal.SIGKILL);child.wait()
        elapsed=time.monotonic()-start
        if elapsed>seconds:status='failed';error=error or dict(type='TimeoutError',message='total active time exceeded reservation')
        receipt=dict(status=status,error=error,active_seconds=elapsed,reservation=reservation,commands=receipts,peak_live_rss_bytes=peak,native_applies=0,optimizer_updates=0,neural_forwards=0,paid_jobs=0,metadata=metadata)
        (out/'receipt.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
        A.append(stream,rows,ledger,'attempt-finish',dict(attempt=attempt,status=status,active_seconds=elapsed,native_applies=0,native_journal_verified=True,observed_optimizer_updates=0,training_forwards=0,evaluation_forwards=0,export_forwards=0,receipt=pin(out/'receipt.json')))
        if status!='completed':raise RuntimeError('analysis failure preserved: '+str(error))
        return receipt

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--command',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--ledger',type=Path,default=HERE/'campaign-ledger.jsonl');p.add_argument('--execute',action='store_true');a=p.parse_args();print(json.dumps(run(a.command,a.out,a.ledger,a.execute),allow_nan=False))
if __name__=='__main__':main()
