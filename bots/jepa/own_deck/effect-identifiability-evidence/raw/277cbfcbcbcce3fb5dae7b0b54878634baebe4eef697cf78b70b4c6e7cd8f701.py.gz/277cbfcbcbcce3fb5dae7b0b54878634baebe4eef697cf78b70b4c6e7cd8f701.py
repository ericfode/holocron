"""Data-only immutable packaging of completed effect-identifiability evidence."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import sys

ROOT = Path('/Users/ericfode/Documents/Codex/2026-10-17/task-7')
REPO = ROOT / 'holocron-deck-context'
CYCLE = ROOT / 'experiments/effect-identifiability-v2'
NATIVE = ROOT / 'experiments/native-effect-v2'
FINAL = REPO / 'bots/jepa/own_deck/effect-identifiability-evidence'
STAGING = FINAL.with_name(FINAL.name + '.staging')
REPORT_SHA = '4049921729ab16d5c0e8052339261a126479f4ebb8de0a3d7bd178c38b1dc6f6'
sys.path.insert(0, str(CYCLE))
import accounting as A


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    data = Path(path).read_bytes()
    return dict(path=str(Path(path).resolve()), sha256=digest(data), bytes=len(data))


def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def read(path):
    return json.loads(Path(path).read_text())


def main():
    import numpy as np  # saved array deserialization only; no model import
    if FINAL.exists() or STAGING.exists():
        raise FileExistsError('immutable final/staging already exists; never overwrite')
    config = read(CYCLE / 'frozen-config.json')
    report = REPO / 'bots/jepa/own_deck/EFFECT_IDENTIFIABILITY_RESULTS.md'
    assert pin(report)['sha256'] == REPORT_SHA
    result = read(CYCLE / 'fit-1/result.json')
    assert result['status'] == 'completed' and result['semantic_validated'] is False
    assert result['held_behavior_gate_passed'] is False
    assert result['counts'] == dict(optimizer_updates=1000, training_forwards=1000,
                                    evaluation_forwards=11, export_forwards=0, backwards=1000)
    assert read(CYCLE / 'fit-1-independent-verification.json')['status'] == 'passed'
    assert read(CYCLE / 'protected-after.json')['all_protected_files_unchanged']
    protected = read(CYCLE / 'preparation-receipt.json')['protected_prior_publications']
    for item in protected:
        assert pin(item['path']) == {k:item[k] for k in ('path','sha256','bytes')}
    paths = {}
    def add(path, role):
        path = Path(path).resolve()
        if path.is_symlink() or not path.is_file():
            raise ValueError('regular source file required: ' + str(path))
        paths.setdefault(path, set()).add(role)
    for base in (CYCLE, NATIVE):
        for path in base.rglob('*'):
            if any(p in {'__pycache__','target','.git','.cache','cache'} for p in path.parts):
                continue
            if path.is_file() and path.suffix not in {'.pyc','.pyo','.rlib','.rmeta'} and not path.name.endswith('.lock'):
                add(path, 'new-cycle-raw')
    for expected in config['pins']:
        assert pin(expected['path']) == expected, expected['path']
        add(expected['path'], 'frozen-active-input')
    for path in (REPO / 'bots/jepa/own_deck').glob('*EFFECT_IDENTIFIABILITY*.md'):
        add(path, 'final-source-report-or-protocol')
    for rel in ['bots/jepa/own_deck/IDENTIFIABLE_EFFECT_COHORT_AUDIT.md',
                'bots/jepa/own_deck/REMAINING_LEDGER.md',
                'bots/jepa/wasm/controller/src/remaining_ledger.rs',
                'bots/jepa/wasm/controller/src/own_deck.rs',
                'bots/jepa/wasm/controller/src/lib.rs']:
        add(REPO / rel, 'pure-ledger-source-or-review')
    add(Path(__file__), 'packager-source')
    prior = ROOT / 'experiments/sites-publication/b14055c85f00-697828c4c242-68037ca2a9e8-v2/provenance/raw'
    for name in ['0c50209297-821c60949788-LICENSE','22ad2f6784-821c60949788-LICENSE.Kessel',
                 'ec9e31c47c-da76f8adfcaf-LICENSE.TCGEngine','de5387bc08-3b3957ba5a89-LICENSE.forceteki']:
        add(prior / name, 'attribution-preserved-from-prior-publication')
    with A.lease(CYCLE / 'campaign-ledger.jsonl') as (_, __, ledger):
        assert ledger['frozen'] and ledger['pending'] is None and ledger['attempts'] == 6
        assert ledger['failures'] == 1 and ledger['native_applies'] == 87
        assert ledger['optimizer_updates'] == 1000
        assert ledger['training_forwards'] == 1000 and ledger['evaluation_forwards'] == 11
        STAGING.mkdir()
        (STAGING / 'raw').mkdir()
        artifacts = []; originals = {}
        for path in sorted(paths):
            raw = path.read_bytes(); expected = pin(path)
            assert digest(raw) == expected['sha256'] and len(raw) == expected['bytes']
            binary = path.suffix in {'.npz','.npy','.gz','.zip'}
            suffix = path.suffix.lower() if path.suffix else '.txt'
            packed = raw if binary else gzip.compress(raw, compresslevel=9, mtime=0)
            url = 'raw/' + expected['sha256'] + suffix + ('' if binary else '.gz')
            target = STAGING / url
            if not target.exists():
                with target.open('xb') as stream: stream.write(packed)
            assert target.read_bytes() == packed
            record = dict(url=url, sha256=digest(packed), bytes=len(packed),
                          encoding='identity' if binary else 'gzip',
                          original_sha256=expected['sha256'], original_bytes=len(raw),
                          status='preserved-exact-original-bytes', roles=sorted(paths[path]),
                          provenance=dict(original_path=str(path)))
            artifacts.append(record); originals[str(path)] = record
        relocation = []
        oldtest = CYCLE / 'test_analysis_runner-v1.py'
        expected_old = '5117d47c502384654daa64268d1b252b4f4932aa2ab5659095e52edc52881e86'
        assert pin(oldtest)['sha256'] == expected_old
        relocation.append(dict(original_path=str(CYCLE/'test_analysis_runner.py'), expected_sha256=expected_old,
                               archive_path=str(oldtest), bytes=oldtest.stat().st_size,
                               url=originals[str(oldtest)]['url'],
                               reason='Unexecuted stale descriptor rejected before stage; earlier test bytes archived, current test separately retained. No source or pin rewritten.'))
        source_registry = dict(schema='effect-source-closure/1', active_frozen_inputs=[
            dict(original_path=p['path'], expected_sha256=p['sha256'], bytes=p['bytes'],
                 url=originals[p['path']]['url']) for p in config['pins']],
            archived_pin_mappings=relocation,
            historical_preparations='Superseded unexecuted manifests/prepared plans retained byte-exact. Their historical source claims are not substituted for executed final pins.',
            raw_json_path_rule='Absolute original paths inside preserved raw JSON are provenance only. Consumers fetch only explicit relative index/manifest URLs.')
        write_json(STAGING/'source-closure.json',source_registry)
        prepared = read(CYCLE/'learner-prepared-v3.json')
        vector_spaces = []
        with np.load(CYCLE/'fit-1/card-vectors.npz',allow_pickle=False) as arrays:
            codes=arrays['codes'].astype(str).tolist()
            assert len(codes)==12 and set(codes)==set(prepared['codes'])
            for arm in config['arms']:
                data=arrays[arm]
                assert data.shape==(12,16) and data.dtype==np.float32 and np.isfinite(data).all()
                rows=[dict(id=code,source_card=code,split='train' if code in prepared['train_codes'] else 'heldout',
                           family_id=prepared['split']['family_groups'][code],vector=data[i].tolist(),
                           semantic_validated=False) for i,code in enumerate(codes)]
                bank=dict(schema='effect-identifiability-card-vector-bank/1',space_id='effect-v2-'+arm,
                          arm=arm,dimension=16,dtype='float32',semantic_validated=False,
                          held_behavior_gate_passed=False,
                          scope='12 selected cards, saved final evaluation vectors; each arm/checkpoint is a distinct space. No full-card/deck/gameplay claim.',
                          source_array=originals[str(CYCLE/'fit-1/card-vectors.npz')],
                          checkpoint=originals[str(CYCLE/'fit-1'/f'{arm}-checkpoint.npz')],rows=rows)
                target=STAGING/f'{arm}-vectors.json';write_json(target,bank)
                b=target.read_bytes();vector_spaces.append(dict(id=bank['space_id'],url=str(target.relative_to(STAGING)),
                    sha256=digest(b),bytes=len(b),rows=12,dimension=16,dtype='float32',arm=arm,semantic_validated=False,
                    basis='Distinct checkpoint space; not coordinate-compatible with earlier published spaces.'))
        for path in paths:
            assert pin(path)['sha256']==originals[str(path)]['original_sha256'], 'source changed during snapshot'
        for item in protected:
            assert pin(item['path'])=={k:item[k]for k in('path','sha256','bytes')}
        index=dict(schema='effect-identifiability-evidence/1',status='completed-negative',semantic_validated=False,
                   execution_source_commit=config['metadata']['execution_source_commit'],
                   frozen_config_sha256=config['config_sha256'],source_closure=dict(url='source-closure.json'),
                   artifacts=artifacts,spaces=vector_spaces,raw_artifact_records=len(artifacts),
                   frozen_inputs_verified=len(config['pins']),
                   result_gate=result['behavioral_gate'],
                   counters=dict(native_applies=87,native_roots=48,optimizer_updates=1000,
                                 neural_forwards=1011,training_forwards=1000,evaluation_forwards=11,
                                 export_forwards=0,paid_jobs=0,paid_spend_usd=0),
                   ledger_final_state=ledger,
                   failure=dict(status='preserved-failed-analysis-cleanup',attempt=4,
                       charged_seconds=5,actual_elapsed_seconds=None,os_absence_proven=False,
                       second_preflight_executed=False,retry_or_reset=False),
                   provenance=dict(prior_publications=protected,
                       previous_publication_unchanged=True,raw_json_paths_are_provenance_only=True),
                   packaging=dict(neural_forwards=0,optimizer_updates=0,native_applies=0,
                                  paid_jobs=0,vector_source='saved-final-evaluation-array-only'))
        write_json(STAGING/'index.json',index)
        files=[]
        for p in sorted(STAGING.rglob('*')):
            if p.is_file():
                b=p.read_bytes();files.append(dict(url=str(p.relative_to(STAGING)),sha256=digest(b),bytes=len(b)))
        manifest=dict(schema='effect-evidence-manifest/1',files=files,file_count=len(files),
                      stored_bytes=sum(p['bytes']for p in files),semantic_validated=False,
                      checks='Every raw decoded SHA/bytes, all142 frozen active source inputs, five12x16 saved banks and protected prior pins verified. Manifest self-hash is external.')
        write_json(STAGING/'manifest.json',manifest)
        os.rename(STAGING,FINAL)
        receipt=dict(status='packaged-negative-no-experiment',destination=str(FINAL),index=pin(FINAL/'index.json'),
                     manifest=pin(FINAL/'manifest.json'),source_closure=pin(FINAL/'source-closure.json'),
                     raw_records=len(artifacts),unique_payloads=len(list((FINAL/'raw').iterdir())),
                     payload_files=len(files)+1,stored_bytes=sum(p.stat().st_size for p in FINAL.rglob('*')if p.is_file()),
                     frozen_inputs_verified=len(config['pins']),saved_vector_spaces=vector_spaces,
                     all_sources_unchanged_after_copy=True,all_prior_publications_unchanged=True,
                     native_applies=0,neural_forwards=0,optimizer_updates=0,paid_jobs=0,paid_spend_usd=0)
        write_json(Path(__file__).parent/'packaging-receipt.json',receipt)
        print(json.dumps({k:v for k,v in receipt.items()if k!='saved_vector_spaces'},indent=2))


if __name__=='__main__': main()
