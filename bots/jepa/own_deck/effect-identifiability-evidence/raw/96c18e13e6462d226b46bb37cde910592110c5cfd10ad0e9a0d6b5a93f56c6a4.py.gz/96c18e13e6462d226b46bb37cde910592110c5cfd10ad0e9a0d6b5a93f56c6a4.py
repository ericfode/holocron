"""Fixed saved-result verifier; preview default, shared other5s, no subprocess."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import runpy
import sys
import time
HERE=Path(__file__).resolve().parent
VERIFIER_SHA='f80756fc1c1d162ab2ee47b9bc67328cdd42a5b8c5ab3fa82a6162c7ed738ccf'
ACCOUNTING_SHA='a72d3ccc9bb381ba626032481d1bbb980236e302a6d532b0960e11445df8e0f9'
COMMIT='e5cfcd98b99933f0a4110f5899857386e02ec808'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
 p=Path(p).resolve();return dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
def main():
 import os
 for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');a=p.parse_args()
 verifier=HERE/'verify_effect_identifiability.py';ledger=HERE/'campaign-ledger.jsonl';out=HERE/'fit-1-independent-verification.json';receipt_path=HERE/'fit-1-independent-verification-accounting.json'
 if sha(verifier)!=VERIFIER_SHA or sha(HERE/'accounting.py')!=ACCOUNTING_SHA:raise ValueError('reviewed verifier/accounting bytes required')
 argv=[str(verifier),'--root',str(HERE.parent),'--out',str(out),'--source-commit',COMMIT]
 paths=[Path(__file__),verifier,HERE/'accounting.py',HERE/'learner-plan.json',HERE/'fit-progress.jsonl',HERE.parent/'native-effect-v2/native-effect-v2.npz',HERE.parent/'native-effect-v2/native-effect-v2.manifest.json']+sorted((HERE/'fit-1').iterdir())
 pins=[pin(x)for x in paths if x.is_file()];metadata=dict(wrapper=pin(__file__),verifier=pin(verifier),argv=argv,pins=pins,source_commit=COMMIT,guard='Unchanged pinned verifier.main own5s SIGALRM/RSS guard; no child/process-group cleanup')
 if not a.execute:print(json.dumps(dict(status='preview-no-execution',metadata=metadata)));return
 if out.exists()or receipt_path.exists():raise FileExistsError('preserve prior verification/receipt')
 spec=importlib.util.spec_from_file_location('inprocess_verification_accounting',HERE/'accounting.py');A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)
 with A.lease(ledger)as(stream,rows,current):
  if any(r['event']=='attempt-start' and r['data']['metadata'].get('analysis_stage')=='result-verifier'for r in rows):raise ValueError('predeclared result verifier already attempted; no retry')
  seconds=min(5.,30-current['phase_seconds']['other'],180-current['active_seconds'])
  if seconds<5.:raise ValueError('full fixed verifier5s reservation unavailable')
  attempt=current['attempts']+1;reservation=dict(phase='other',active_seconds=5.,native_applies=0,optimizer_updates=0,training_forwards=0,evaluation_forwards=0,export_forwards=0)
  A.append(stream,rows,ledger,'attempt-start',dict(attempt=attempt,reservation=reservation,metadata=dict(analysis_stage='result-verifier',**metadata)))
  start=time.monotonic();status='failed';error=None;violations=[];previous=sys.argv[:]
  forbidden=('torch','tensorflow','jax','jaxlib','onnxruntime','mlx','kessel','modal')
  def audit(event,args):
   if event=='import'and any(args[0]==m or args[0].startswith(m+'.')for m in forbidden)or event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty'):
    violations.append(dict(event=event,name=str(args[0])if args else''));raise RuntimeError('data-only verification rejected neural import/process spawn')
  sys.addaudithook(audit)
  try:
   sys.argv=argv
   try:runpy.run_path(str(verifier),run_name='__main__')
   except SystemExit as exc:
    if exc.code not in(None,0):raise RuntimeError('verifier exited '+str(exc.code))
   result=json.loads(out.read_text())
   if result['status']!='passed'or violations:raise RuntimeError('independent verifier reported failure')
   for item in pins:
    if pin(item['path'])!=item:raise ValueError('protected verification input changed')
   status='completed'
  except BaseException as exc:error=dict(type=type(exc).__name__,message=str(exc))
  finally:sys.argv=previous
  elapsed=time.monotonic()-start
  if elapsed>5.:status='failed';error=error or dict(type='BudgetExceeded',message='total verifier wrapper time exceeded5s')
  loaded=[m for m in sys.modules if any(m==x or m.startswith(x+'.')for x in forbidden)]
  if loaded:status='failed';error=error or dict(type='UnexpectedNeuralImport',message=str(loaded))
  receipt=dict(status=status,error=error,active_seconds=elapsed,reservation=reservation,metadata=metadata,result=pin(out)if out.exists()else None,zero_workload_proof=dict(neural_import_violations=violations,neural_modules_loaded=loaded,native_applies=0,optimizer_updates=0,neural_forwards=0,subprocesses=0),scope='Pinned saved-artifact NumPy verifier only; own-process timer authorized; no forwards/native/optimizer/paid work.')
  with receipt_path.open('x')as f:json.dump(receipt,f,indent=2,allow_nan=False);f.write('\n')
  A.append(stream,rows,ledger,'attempt-finish',dict(attempt=attempt,status=status,active_seconds=elapsed,native_applies=0,native_journal_verified=True,observed_optimizer_updates=0,training_forwards=0,evaluation_forwards=0,export_forwards=0,receipt=pin(receipt_path)))
  print(json.dumps(dict(status=status,receipt=pin(receipt_path),result=pin(out)if out.exists()else None,active_seconds=elapsed)))
  if status!='completed':raise SystemExit(1)
if __name__=='__main__':main()
