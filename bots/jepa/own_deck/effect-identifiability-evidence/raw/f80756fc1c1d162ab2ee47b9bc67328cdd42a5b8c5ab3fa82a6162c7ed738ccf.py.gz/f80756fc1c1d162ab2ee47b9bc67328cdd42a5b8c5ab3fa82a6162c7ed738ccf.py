"""Independent saved-artifact verification; no learner imports or neural calls.

Run only after coordinator GO and completed artifacts. Five seconds includes
NumPy import, reads, arithmetic and hashes. Existing artifacts are read-only.
"""
import os
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import resource
import signal
import sys
import threading
import time

ARMS = ("rich-typed", "sparse-typed", "rich-id-only", "rich-untrained-typed", "rich-wrong-typed")
TRAIN = ("ASH_048", "LOF_151", "SEC_142", "JTL_144", "JTL_217", "ASH_171", "SEC_051")
HELD = ("JTL_102", "LAW_131", "JTL_079", "LAW_127", "ASH_228")
EFFECTS = {"damage": (2,), "exhaustion": (3,), "shield": (4,), "stats": (5, 6)}
FAMILIES = {
    "pointed-unit-friendly-space-count-damage": (("JTL_102",), ("damage", "shield")),
    "pointed-unit-event-stat-debuff": (("LAW_131", "JTL_079"), ("stats",)),
    "attached-host-exhaust": (("LAW_127", "ASH_228"), ("exhaustion", "stats")),
}
TOL = 5e-6


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stable(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


class Audit:
    def __init__(self):
        self.checks = {}; self.mismatches = []; self.largest_numeric_gap = 0.

    def check(self, name, condition):
        self.checks[name] = bool(condition)
        if not condition: self.mismatches.append(name)

    def compare(self, name, calculated, saved):
        if isinstance(calculated, dict):
            for k, v in calculated.items():
                if k not in saved: self.check(name + ".missing." + k, False)
                else: self.compare(name + "." + k, v, saved[k])
        elif isinstance(calculated, list):
            self.check(name + ".length", len(calculated) == len(saved))
            for i, (v, w) in enumerate(zip(calculated, saved)): self.compare(name + f"[{i}]", v, w)
        elif isinstance(calculated, bool) or calculated is None or isinstance(calculated, str):
            self.check(name, calculated == saved)
        elif isinstance(calculated, (int, float)):
            if saved is None: self.check(name, False)
            else:
                gap = abs(float(calculated) - float(saved)); self.largest_numeric_gap = max(self.largest_numeric_gap, gap)
                self.check(name, gap <= TOL + 1e-6 * abs(float(calculated)))
        else: raise TypeError(type(calculated))


def bank_signatures(np, plan):
    """Rebuild typed tensor bytes independently from public canonical documents."""
    def leaves(v, path=()):
        if isinstance(v, dict):
            yield path, "node", "object"
            for k in sorted(v): yield from leaves(v[k], path + (k,))
        elif isinstance(v, list):
            yield path, "length", len(v)
            for i, child in enumerate(v): yield from leaves(child, path + (i,))
        elif type(v) is bool: yield path, "boolean", v
        elif type(v) in (int, float): yield path, "number", float(v)
        elif isinstance(v, str): yield path, "enum", v
        elif v is None: yield path, "null", "null"
        else: raise ValueError("untyped public document")
    stream = [list(leaves(d)) for d in plan["documents"]]
    numbers = [v for code, row in zip(plan["codes"], stream) if code in TRAIN for _, kind, v in row if kind in ("number", "length")]
    literal_scale = max(1., float(np.std(numbers)))
    lookup = {k: {v: i for i, v in enumerate(values)} for k, values in plan["vocabularies"].items()}
    result = []
    for row in stream:
        b = dict(path_ids=np.zeros((512, 32), np.int64), path_lengths=np.zeros(512, np.int64), type_ids=np.zeros(512, np.int64), value_ids=np.zeros(512, np.int64), numeric=np.zeros((512, 2), np.float32), token_mask=np.zeros(512, np.float32), slot_mask=np.asarray(1., np.float32))
        for pos, (path, kind, value) in enumerate(row):
            if pos >= 512 or len(path) > 32: raise ValueError("frozen representation cap exceeded")
            b["path_ids"][pos, :len(path)] = [lookup["path"][("index:" if type(k) is int else "key:") + str(k)] for k in path]
            b["path_lengths"][pos] = len(path); b["type_ids"][pos] = lookup["type"][kind]
            b["value_ids"][pos] = lookup["value"]["NUMBER" if kind in ("number", "length") else kind + ":" + str(value)]
            b["token_mask"][pos] = 1
            if kind in ("number", "length"): b["numeric"][pos] = (value / literal_scale, np.sign(value) * np.log1p(abs(value)))
        h = hashlib.sha256()
        for k in sorted(b): h.update(k.encode() + str(b[k].dtype).encode() + str(b[k].shape).encode() + b[k].tobytes())
        result.append(h.hexdigest())
    return result, literal_scale


def input_conflicts(np, a, plan, signatures, mode):
    codes = plan["codes"]; identity = {c: str(TRAIN.index(c) + 1 if c in TRAIN else 0) for c in codes}
    signatures = dict(zip(codes, signatures)); seen = {}; conflicts = []; inputs = Counter()
    x, c = [(a[k] - np.asarray(plan["scalers"][k]["center"], np.float32)) / np.asarray(plan["scalers"][k]["scale"], np.float32) for k in ("context_features", "candidate_features")]
    for row, code in enumerate(a["source_cards"].astype(str)):
        visible = code
        if mode == "wrong_evaluation":
            group = TRAIN if code in TRAIN else HELD; visible = group[(group.index(code) + 1) % len(group)]
        card = identity[visible] if mode == "id_only" else signatures[visible]
        for category, ykey, mkey, candidates in (("source", "source_targets", "source_mask", [int(a["selected_candidate_indices"][row])]), ("candidate", "targets", "target_mask", range(8))):
            for j in candidates:
                key = hashlib.sha256(card.encode() + x[row].astype(np.float32).tobytes() + c[row, j].astype(np.float32).tobytes()).hexdigest()
                inputs[(category, key)] += 1
                y = a[ykey][row] if category == "source" else a[ykey][row, j]
                mask = a[mkey][row] if category == "source" else a[mkey][row, j]
                for head in np.flatnonzero(mask):
                    k = category, key, int(head); value = float(y[head])
                    if k in seen and seen[k][0] != value: conflicts.append(dict(kind=category, head=int(head), old_root=seen[k][1], root=row, old_value=seen[k][0], value=value))
                    else: seen[k] = value, row
    return dict(conflict_count=len(conflicts), conflicts=conflicts, distinct_source_inputs=sum(k[0] == "source" for k in inputs), distinct_candidate_inputs=sum(k[0] == "candidate" for k in inputs), scope="Actual public typed tensor or ID/UNK input contract; output masks never enter hash")


def verify(args, audit):
    import numpy as np
    root = Path(args.root).resolve(); fit = root / "effect-identifiability-v2/fit-1"; native = root / "native-effect-v2"
    paths = dict(plan=root / "effect-identifiability-v2/learner-plan.json", dataset=native / "native-effect-v2.npz", manifest=native / "native-effect-v2.manifest.json", result=fit / "result.json", contract=fit / "contract.json", receipt=fit / "receipt.json")
    p, m, r, contract, receipt = [read(paths[k]) for k in ("plan", "manifest", "result", "contract", "receipt")]
    with np.load(paths["dataset"], allow_pickle=False) as z: a = {k: z[k].copy() for k in z.files}
    for key, shape in dict(context_features=(48, 18), candidate_features=(48, 8, 34), source_targets=(48, 9), source_mask=(48, 9), targets=(48, 8, 7), target_mask=(48, 8, 7)).items():
        valid = a[key].shape == shape and a[key].dtype == np.float32 and np.isfinite(a[key]).all()
        if key.endswith("mask"): valid = valid and np.isin(a[key], [0, 1]).all()
        audit.check("finite_native_ABI:" + key, valid)
        if not valid: raise ValueError("invalid pinned native ABI: " + key)
    audit.check("completed_result_and_receipt", r["status"] == receipt["status"] == "completed")
    audit.check("generic_semantics_remain_unqualified", r["semantic_validated"] is False)
    audit.check("raw_native_dataset_pin", sha(paths["dataset"]) == m["artifact"]["sha256"])
    protected = {pin["path"]: pin["sha256"] for pin in p["pins"]}
    for path, expected in protected.items(): audit.check("protected_before:" + path, sha(path) == expected)
    audit.check("source_commit", args.source_commit == "e5cfcd98b99933f0a4110f5899857386e02ec808")
    audit.check("frozen_split", p["train_codes"] == list(TRAIN) and p["held_codes"] == list(HELD))
    codes = a["source_cards"].astype(str); states = a["state_families"]; n = len(codes)
    audit.check("complete_root_grid", n == 48 and set(zip(codes, states.tolist())) == {(c, s) for c in TRAIN + HELD for s in range(4)})
    cells = {"train": np.flatnonzero(np.isin(codes, TRAIN) & (states < 3)), "family_held": np.flatnonzero(np.isin(codes, HELD) & (states < 3)), "state_held": np.flatnonzero(np.isin(codes, TRAIN) & (states == 3)), "joint": np.flatnonzero(np.isin(codes, HELD) & (states == 3))}
    audit.compare("split_counts", {k: len(v) for k, v in cells.items()}, dict(train=21, family_held=15, state_held=7, joint=5))
    train = cells["train"]; scalers = {}
    for key in ("context_features", "candidate_features"):
        v = a[key][train]; axes = tuple(range(v.ndim - 1)); sc = dict(center=v.mean(axes).tolist(), scale=np.maximum(1, v.std(axes)).tolist()); audit.compare("TRAIN_scaler." + key, sc, p["scalers"][key])
    support = {}
    for ykey, mkey, names, binary in (("source_targets", "source_mask", m["source_head_names"], m["source_binary_heads"]), ("targets", "target_mask", m["target_names"], m["binary_heads"])):
        scalers[ykey] = []
        for h, name in enumerate(names):
            v = a[ykey][train, ..., h][a[mkey][train, ..., h] > 0]; counts = {str(s): int((np.sign(v) == s).sum()) for s in (-1, 0, 1)}; classes = sum(v > 0 for v in counts.values())
            sc = dict(name=name, binary=name in binary, known=len(v), varying=len(np.unique(v)) > 1, center=0. if name in binary or not len(v) else float(v.mean()), scale=1. if name in binary or not len(v) else max(1., float(v.std())), values=np.unique(v).tolist(), zero=int((v == 0).sum()), nonzero=int((v != 0).sum()), negative=int((v < 0).sum()), positive=int((v > 0).sum()), class_weights={s: len(v) / (classes * k) if k else 0. for s, k in counts.items()})
            scalers[ykey].append(sc)
    varying = sum(sc["varying"] for specs in scalers.values() for sc in specs); constant = sum(sc["known"] > 0 and not sc["varying"] for specs in scalers.values() for sc in specs)
    for key, specs in scalers.items():
        for sc in specs: sc["loss_coefficient"] = 1. / varying if sc["varying"] else .1 / constant if sc["known"] and constant else 0.
        audit.compare("TRAIN_target_scalers." + key, specs, p["scalers"][key])
    eligible = {name: all(scalers["targets"][h]["zero"] >= 2 and scalers["targets"][h]["nonzero"] >= 2 for h in heads) for name, heads in EFFECTS.items()}
    audit.check("four_mechanics_TRAIN_identifiable", all(eligible.values()))
    expected_sparse = a["target_mask"].copy(); expected_sparse[train, :, 2:7] = 0
    audit.check("five_heads_only_sparse_TRAIN_mask", np.array_equal(expected_sparse, a["sparse_target_mask"]) and np.array_equal(a["source_mask"], a["sparse_source_mask"]))
    for i in range(n): audit.check(f"no_unchosen_future:{i}", not a["target_mask"][i, np.arange(8) != a["selected_candidate_indices"][i], 2:].any())
    signatures, literal_scale = bank_signatures(np, p); audit.compare("literal_TRAIN_scale", literal_scale, p["numeric_scale"]); audit.check("exact_public_typed_tensor_signatures", signatures == p["semantic_tensor_sha256"])
    conflicts = {mode: input_conflicts(np, a, p, signatures, mode) for mode in ("typed", "id_only", "wrong_evaluation")}
    for mode, result in conflicts.items(): audit.compare("input_conflict_count." + mode, result["conflict_count"], p["input_audits"][mode]["conflict_count"])
    audit.check("typed_inputs_identifiable", conflicts["typed"]["conflict_count"] == 0)
    privacy_captures = 0
    for record in m["records"]:
        stack = [record]
        while stack:
            value = stack.pop()
            if isinstance(value, dict):
                if isinstance(value.get("state"), dict) and "players" in value["state"]:
                    privacy_captures += 1; players = value["state"]["players"]
                    audit.check(f"public_capture:{privacy_captures}", not players["p1"]["deck"] and not players["p2"]["deck"] and not players["p2"]["hand"])
                stack.extend(value.values())
            elif isinstance(value, list): stack.extend(value)
    for cell, ix in cells.items():
        support[cell] = {}
        for code in sorted(set(codes[ix])):
            rows = ix[codes[ix] == code]; support[cell][code] = {}
            for h, name in enumerate(m["target_names"]):
                y = a["targets"][rows, :, h]; mask = a["target_mask"][rows, :, h] > 0
                support[cell][code][name] = {"known": int(mask.sum()), "observed_roots": int(mask.any(1).sum()), **{label: dict(coordinates=int(((test(y)) & mask).sum()), roots=int(((test(y)) & mask).any(1).sum())) for label, test in (("zero", lambda v: v == 0), ("positive", lambda v: v > 0), ("negative", lambda v: v < 0))}}
                local = support[cell][code][name]
                audit.compare(f"saved_support:{cell}:{code}:{name}", {"known": local["known"], "observed_roots": local["observed_roots"], **{k: local[k]["coordinates"] for k in ("zero", "positive", "negative")}}, p["per_card_head_support"][cell][code][name])
    groups = dict(zip(p["codes"], p["document_sha256"]))
    index = {(c, int(s)): i for i, (c, s) in enumerate(zip(codes, states))}
    expected_pairs = [("JTL_102", 0, "JTL_102", 1, (2,)), ("JTL_102", 2, "JTL_102", 3, (2,))] + [(c, s, c, t, (3,)) for c in ("LAW_127", "ASH_228") for s, t in ((0, 1), (2, 3))] + [("LAW_131", s, "JTL_079", s, (5, 6)) for s in range(4)]
    pairs = m["plan"]["predeclared_behavior_pairs"]
    actual_pairs = [(z["left"]["card"], z["left"]["state"], z["right"]["card"], z["right"]["state"], tuple(m["target_names"].index(h) for h in z["heads"])) for z in pairs]
    audit.check("exact_fixed_ten_pair_panel", actual_pairs == expected_pairs)

    def summarize(source, branch):
        cell_results = {}
        for cell, ix in cells.items():
            family_results = {}
            for family, (members, mechanics) in FAMILIES.items():
                rows = [int(i) for i in ix if codes[i] in members]; mechanic_results = {}; observed_groups = set()
                for mechanic in mechanics:
                    head_results = {}; values = []
                    for h in EFFECTS[mechanic]:
                        mask = a["target_mask"][rows, :, h]; y = a["targets"][rows, :, h]; pred = branch[rows, :, h]; per_root = mask.sum(1); valid = per_root > 0
                        error = float((((np.abs(pred.astype(float) - y) * mask).sum(1) / np.maximum(1, per_root))[valid]).mean() / scalers["targets"][h]["scale"]) if valid.any() else None
                        head_results[m["target_names"][h]] = dict(known_coordinates=int(mask.sum()), observed_roots=int(valid.sum()), train_scaled_mae=error, zero=int(((y == 0) & (mask > 0)).sum()), nonzero=int(((y != 0) & (mask > 0)).sum()), eligible=eligible[mechanic])
                        if error is not None and eligible[mechanic]: values.append(error)
                        if eligible[mechanic]: observed_groups.update(groups[codes[rows[j]]] for j in np.flatnonzero(valid))
                    mechanic_results[mechanic] = dict(heads=head_results, mae=float(np.mean(values)) if len(values) == len(EFFECTS[mechanic]) else None)
                known = [v["mae"] for v in mechanic_results.values() if v["mae"] is not None]
                family_results[family] = dict(roots=rows, program_groups=sorted(observed_groups), mechanics=mechanic_results, mae=float(np.mean(known)) if known else None)
            known = [v for v in family_results.values() if v["mae"] is not None]
            cell_results[cell] = dict(behavior=dict(families=family_results, family_first_mae=float(np.mean([v["mae"] for v in known])) if known else None, known_families=len(known), known_program_groups=len({g for f in known for g in f["program_groups"]})))
        pair_results = []
        for pair in pairs:
            left, right = [index[(pair[k]["card"], pair[k]["state"])] for k in ("left", "right")]; li, ri = [int(a["selected_candidate_indices"][i]) for i in (left, right)]; heads = []
            for name in pair["heads"]:
                h = m["target_names"].index(name); ok = all(eligible[k] for k, hs in EFFECTS.items() if h in hs); known = bool(a["target_mask"][left, li, h] and a["target_mask"][right, ri, h])
                if not known: heads.append(dict(head=name, known=False, eligible=ok)); continue
                truth = float(a["targets"][left, li, h] - a["targets"][right, ri, h]); pred = float(branch[left, li, h] - branch[right, ri, h])
                direction = int(abs(pred) <= .25) if abs(truth) <= .25 else int(pred > .25) if truth > .25 else int(pred < -.25)
                heads.append(dict(head=name, known=True, eligible=ok, native_contrast=truth, predicted_contrast=pred, train_scaled_error=abs(pred - truth) / scalers["targets"][h]["scale"], direction_correct=direction))
            valid = [z for z in heads if z["known"] and z["eligible"]]; complete = len(valid) == len(heads)
            pair_results.append(dict(id=pair["id"], family=pair["family"], heads=heads, known=complete, mae=float(np.mean([z["train_scaled_error"] for z in valid])) if complete else None, direction_accuracy=float(np.mean([z["direction_correct"] for z in valid])) if complete else None))
        family_pairs = {}
        for family in FAMILIES:
            rows = [z for z in pair_results if z["family"] == family and z["known"]]
            family_pairs[family] = dict(known_pairs=len(rows), mae=float(np.mean([z["mae"] for z in rows])) if rows else None, direction_accuracy=float(np.mean([z["direction_accuracy"] for z in rows])) if rows else None)
        known = [v for v in family_pairs.values() if v["known_pairs"]]
        return dict(cells=cell_results, contrasts=dict(pairs=pair_results, families=family_pairs, known_pairs=sum(v["known_pairs"] for v in known), known_families=len(known), family_first_mae=float(np.mean([v["mae"] for v in known])) if known else None, family_first_direction_accuracy=float(np.mean([v["direction_accuracy"] for v in known])) if known else None))

    recomputed = {}; retained = []
    for arm in ARMS:
        for step in (0, 200):
            path = fit / f"{arm}-step{step}-predictions.npz"; retained.append(path)
            with np.load(path, allow_pickle=False) as z:
                source, branch = z["source"].copy(), z["branch"].copy()
                audit.check(f"alignment:{arm}:{step}", np.array_equal(z["source_cards"], a["source_cards"]) and np.array_equal(z["state_families"], states) and np.array_equal(z["selected_candidate_indices"], a["selected_candidate_indices"]))
            audit.check(f"finite_predictions:{arm}:{step}", source.shape == (48, 9) and branch.shape == (48, 8, 7) and np.isfinite(source).all() and np.isfinite(branch).all())
            result = summarize(source, branch); audit.compare(f"saved_metrics:{arm}:{step}", result, r["results"][arm]["evaluations"][str(step)])
            if step == 200: recomputed[arm] = result
    mean_predictions = []
    for ykey, mkey in (("source_targets", "source_mask"), ("targets", "target_mask")):
        values = [float(a[ykey][train, ..., h][a[mkey][train, ..., h] > 0].mean()) if (a[mkey][train, ..., h] > 0).any() else 0. for h in range(a[ykey].shape[-1])]
        mean_predictions.append(np.broadcast_to(np.asarray(values, np.float32), a[ykey].shape).copy())
    baselines = dict(train_constant=summarize(*mean_predictions), zero_heads=summarize(np.zeros_like(a["source_targets"]), np.zeros_like(a["targets"])))
    for name, result in baselines.items(): audit.compare("saved_baseline:" + name, result, r["zero_neural_baselines"][name])
    controls = {**{k: v for k, v in recomputed.items() if k != "rich-typed"}, **baselines}; rich = recomputed["rich-typed"]; primary = rich["cells"]["family_held"]["behavior"]; contrast = rich["contrasts"]
    errors = {k: v["cells"]["family_held"]["behavior"]["family_first_mae"] for k, v in controls.items()}; contrast_errors = {k: v["contrasts"]["family_first_mae"] for k, v in controls.items()}
    best = min(errors.values()) if all(v is not None for v in errors.values()) else None; cbest = min(contrast_errors.values()) if all(v is not None for v in contrast_errors.values()) else None
    support_pass = primary["known_families"] >= 2 and primary["known_program_groups"] >= 3 and contrast["known_pairs"] >= 4 and contrast["known_families"] >= 2
    audit.compare("saved_prefit_admission", dict(passed=bool(all(eligible.values()) and support_pass), held_known_families=primary["known_families"], held_known_program_groups=primary["known_program_groups"], contrast_known_pairs=contrast["known_pairs"], contrast_known_families=contrast["known_families"]), p["support_admission"])
    error_pass = best is not None and best > 0 and primary["family_first_mae"] <= .9 * best
    contrast_pass = cbest is not None and cbest > 0 and contrast["family_first_mae"] <= .9 * cbest and contrast["family_first_direction_accuracy"] >= .75
    gate = dict(passed=bool(support_pass and error_pass and contrast_pass), support_pass=support_pass, primary_error_pass=bool(error_pass), contrast_pass=bool(contrast_pass), rich_primary_error=primary["family_first_mae"], strongest_control_error=best, all_control_errors=errors, strongest_control_contrast_error=cbest, all_control_contrast_errors=contrast_errors)
    audit.compare("six_control_gate", gate, r["behavioral_gate"]); audit.check("limited_gate_flag", r["held_behavior_gate_passed"] == gate["passed"])
    with np.load(fit / "schedules.npz", allow_pickle=False) as z:
        batches, wrong = z["batches"], z["wrong_train"]
        audit.check("TRAIN_only_schedule", batches.shape == wrong.shape == (200, 18) and np.isin(batches, train).all())
        actual = np.asarray([p["codes"].index(str(c)) for c in codes])[batches]
        audit.check("fresh_wrong_excludes_actual_TRAIN_card", np.isin(wrong, [p["codes"].index(c) for c in TRAIN]).all() and (wrong != actual).all())
    old = r["saved_PR35_diagnostic"]; overlap = [i for i, c in enumerate(codes) if c in ("ASH_048", "JTL_217")]
    audit.check("saved_baseline_overlap_scope", old["new_rows"] == overlap and len(overlap) == 8 and not set(codes[overlap]) & set(HELD))
    audit.check("recorded_old_replay_witness_within_tolerance", 0 <= old["replay_max_abs_error"] <= 1e-5)
    old_errors = {}
    for key, mk, pred in (("source_targets", "source_mask", np.asarray(old["source_predictions"])), ("targets", "target_mask", np.asarray(old["branch_predictions"]))):
        y, mask = a[key][overlap], a[mk][overlap]; old_errors[key] = {name: dict(known=int(mask[..., h].sum()), native_mae=float(np.abs(pred[..., h] - y[..., h])[mask[..., h] > 0].mean()) if mask[..., h].any() else None) for h, name in enumerate(m["source_head_names"] if key == "source_targets" else m["target_names"])}
    journal = [json.loads(line) for line in (root / "effect-identifiability-v2/fit-progress.jsonl").read_text().splitlines() if line.strip()]
    updates = [z for z in journal if z["event"] == "optimizer-update"]; calls = [z for z in journal if z["event"] == "forward-intent"]
    counts = dict(optimizer_updates=len(updates), training_forwards=sum(z["kind"] == "train" for z in calls), evaluation_forwards=sum(z["kind"] == "evaluate" for z in calls), export_forwards=0, backwards=1000)
    audit.check("durable_update_sequence", [z["global_update"] for z in updates] == list(range(1, 1001)))
    audit.check("durable_forward_sequence", [z["global_forward"] for z in calls] == list(range(1, 1012)))
    audit.compare("recorded_counts", counts, r["counts"])
    for arm in ARMS: audit.check("matched_schedule_update_count:" + arm, sum(z["arm"] == arm for z in updates) == 200)
    audit.check("saved_initial_state", (fit / "initial-checkpoint.npz").is_file())
    with np.load(fit / "card-vectors.npz", allow_pickle=False) as z:
        audit.check("captured_vector_bank", z["codes"].astype(str).tolist() == p["codes"] and all(z[arm].shape == (12, 16) and np.isfinite(z[arm]).all() for arm in ARMS))
        audit.check("held_ID_vectors_remain_UNK0", not z["rich-id-only"][[p["codes"].index(c) for c in HELD]].any())
    with np.load(fit / "initial-checkpoint.npz", allow_pickle=False) as z: initial = {k: z[k].copy() for k in z.files}
    audit.check("initial_allocated_parameters", sum(v.size for v in initial.values()) == p["parameters"]["allocated"])
    for arm in ARMS:
        path = fit / f"{arm}-checkpoint.npz"; audit.check("checkpoint_pin:" + arm, sha(path) == r["results"][arm]["checkpoint"]["sha256"])
        with np.load(path, allow_pickle=False) as z:
            audit.check("finite_matched_checkpoint:" + arm, set(z.files) == set(initial) and sum(z[k].size for k in z.files) == p["parameters"]["allocated"] and all(np.isfinite(z[k]).all() for k in z.files))
            if arm in ("rich-id-only", "rich-untrained-typed"): audit.check("frozen_encoder:" + arm, all(np.array_equal(z[k], v) for k, v in initial.items() if k.startswith(("edge.", "depth", "kind.", "value.", "numeric.", "leaf.", "card_projection."))))
    for path, expected in protected.items(): audit.check("protected_after:" + path, sha(path) == expected)
    return dict(derived_gate=gate, recomputed_metrics=recomputed, recomputed_baselines=baselines, support_by_partition_and_card=support, input_conflicts=conflicts, privacy_capture_occurrences=privacy_captures, held_schedule_roots=0, counts=counts, saved_PR35_overlap=dict(rows=overlap, identities=sorted(set(codes[overlap])), new_held_identities=0, native_errors=old_errors, replay_retention_limit="Only scalar old-anchor parity witness retained; current replay tensors cannot be independently reconstructed. No additional forward requested."), artifacts={k: dict(path=str(v), sha256=sha(v)) for k, v in paths.items()}, protected_input_count=len(protected), retained_prediction_files=[dict(path=str(v), sha256=sha(v)) for v in retained])


def main():
    ap = argparse.ArgumentParser(description=__doc__); ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent); ap.add_argument("--out", type=Path, required=True); ap.add_argument("--source-commit", default="e5cfcd98b99933f0a4110f5899857386e02ec808"); args = ap.parse_args()
    if args.out.exists(): raise FileExistsError("preserve previous verification")
    start = time.monotonic(); cpu = resource.getrusage(resource.RUSAGE_SELF); audit = Audit(); result = {}; error = None; stop = threading.Event()
    def halt(*_): raise RuntimeError("independent verification5s/1GiB bound")
    signal.signal(signal.SIGALRM, halt); signal.setitimer(signal.ITIMER_REAL, 5.)
    def memory_guard():
        while not stop.wait(.01):
            peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1 if sys.platform == "darwin" else 1024)
            if peak > 1024 ** 3: os.kill(os.getpid(), signal.SIGALRM); return
    thread = threading.Thread(target=memory_guard, daemon=True); thread.start()
    try: result = verify(args, audit)
    except BaseException as exc: error = dict(type=type(exc).__name__, message=str(exc))
    finally: signal.setitimer(signal.ITIMER_REAL, 0); stop.set(); thread.join(.1)
    end = resource.getrusage(resource.RUSAGE_SELF); elapsed = time.monotonic() - start; peak = end.ru_maxrss * (1 if sys.platform == "darwin" else 1024)
    passed = error is None and not audit.mismatches and elapsed <= 5 and peak <= 1024 ** 3
    output = dict(schema="effect-identifiability-independent-verification/1", status="passed" if passed else "failed-preserved", error=error, source=dict(path=str(Path(__file__).resolve()), sha256=sha(__file__)), source_commit=args.source_commit, checks=audit.checks, mismatches=audit.mismatches, largest_numeric_gap=audit.largest_numeric_gap, absolute_tolerance=TOL, relative_tolerance=1e-6, results=result, receipt=dict(active_seconds=elapsed, cpu_seconds=end.ru_utime + end.ru_stime - cpu.ru_utime - cpu.ru_stime, peak_rss_bytes=peak, numerical_threads=1, neural_forwards=0, native_calls=0, optimizer_updates=0, paid_jobs=0, wall_limit_seconds=5, rss_limit_bytes=1024 ** 3))
    args.out.parent.mkdir(parents=True, exist_ok=True); args.out.write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")
    print(json.dumps(dict(status=output["status"], out=str(args.out), sha256=sha(args.out), receipt=output["receipt"], mismatches=len(audit.mismatches), error=error)))
    return 0 if passed else 1


if __name__ == "__main__": sys.exit(main())
