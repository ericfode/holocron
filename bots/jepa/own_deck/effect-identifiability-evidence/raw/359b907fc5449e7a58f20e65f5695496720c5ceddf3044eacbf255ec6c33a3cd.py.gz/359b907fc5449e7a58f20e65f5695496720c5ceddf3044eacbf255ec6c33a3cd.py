"""Analysis child guard. This is a guard on reviewed code, not a security sandbox."""
import atexit
import json
import os
import sys

proof = os.environ.get('EFFECT_ANALYSIS_PROOF')
forbidden = ('torch', 'tensorflow', 'jax', 'jaxlib', 'onnxruntime', 'mlx', 'kessel', 'modal', 'requests', 'httpx', 'urllib.request')
violations = []
def audit(event, args):
    blocked = (event == 'import' and any(args[0] == x or args[0].startswith(x + '.') for x in forbidden)) or event in ('subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn', 'os.fork', 'os.forkpty', 'socket.connect')
    if blocked:
        violations.append(dict(event=event, name=str(args[0]) if args else ''))
        raise RuntimeError('zero-neural/native analysis guard rejected ' + event)
def finish():
    if proof:
        with open(proof, 'w') as f:
            json.dump(dict(schema='effect-analysis-child-proof/1', guard_loaded=True, violations=violations, neural_modules_loaded=[x for x in sys.modules if any(x == p or x.startswith(p + '.') for p in forbidden)], native_applies=0, optimizer_updates=0, neural_forwards=0, scope='Pinned reviewed Python analysis plus import/spawn guard; not a sandbox against malicious ctypes code.'), f)
sys.addaudithook(audit)
atexit.register(finish)
