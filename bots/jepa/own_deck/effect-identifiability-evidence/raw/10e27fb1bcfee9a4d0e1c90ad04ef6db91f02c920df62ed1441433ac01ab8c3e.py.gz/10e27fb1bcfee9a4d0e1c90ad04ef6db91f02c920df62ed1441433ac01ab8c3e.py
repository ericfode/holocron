"""Synthetic only: no actual experiment receipts, labels, models or engines."""
import copy
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch

PATH = Path(__file__).with_name("verify_native_effect_v2.py")
SPEC = importlib.util.spec_from_file_location("independent_native_effect_verifier", PATH)
V = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(V)


def card(types, hp=None, power=None):
    result = dict(types=types, traits=[], aspects=[], cost=2, unique=False)
    if hp is not None: result["hp"] = hp
    if power is not None: result["power"] = power
    return dict(card=result, sourceHash="synthetic-source")


def fixture():
    rows = {"SEC_142": card(["unit"], 6, 2), "UNIT": card(["unit"], 12, 3),
            "BASE": card(["base"], 30), "LEADER": card(["leader"], 8, 3),
            "UPGRADE": card(["upgrade"]), "RESOURCE": card(["event"]),
            "TOKEN_SHIELD": card(["upgrade"]), "TOKEN_EXPERIENCE": card(["upgrade"])}
    refs = dict(zip(V.SLOTS, ("c0", "c1", "c2", "c3", "c4", "c5", "c6", "c7")))
    def wire(identity, code, **kwargs): return dict(id=identity, setCode=code, **kwargs)
    def unit(identity, upgrades=None):
        return wire(identity, "UNIT", hp=12, power=3, damage=0, exhausted=False, upgrades=upgrades or [])
    own = dict(base=wire("c6", "BASE", damage=0, hp=30), leader=wire("c8", "LEADER", deployed=False, exhausted=False),
               hand=[wire("c0", "SEC_142")], deck=[], discard=[],
               resources=[wire("r" + str(i), "RESOURCE", exhausted=False) for i in range(12)],
               ground=[unit("c1", [wire("c4", "UPGRADE", owner="p1", controller="p1")])], space=[unit("c2")])
    enemy = dict(base=wire("c7", "BASE", damage=0, hp=30), leader=wire("c9", "LEADER", deployed=False, exhausted=False),
                 hand=[], deck=[], discard=[], resources=[],
                 ground=[unit("c10", [wire("c5", "UPGRADE", owner="p2", controller="p2")])], space=[unit("c3")])
    capture = dict(decision="Window", actor="p1", sourceInstance=None, abilityProgramPlusOne=0,
                   abilityPc=0, abilityCommitted=False, terminal=False, settled=True,
                   settlement=dict(decision="Window", **{k: 0 for k in V.QUEUES}, event_group_active=False, support_pending=False),
                   own_aspect_sources=dict(base="BASE", leader="LEADER"), other_friendly_space_count=1,
                   other_friendly_fighter_count=0, state=dict(players=dict(p1=own, p2=enemy)),
                   offeredActions=[dict(kind="card", card="c0")])
    refresh(capture, refs, rows)
    return capture, refs, rows


def refresh(capture, refs, rows):
    """Only fixture caches use the same projector; asserted deltas are explicit."""
    indexed = V.wire_index(capture)
    capture["projections"] = {slot: V.derive_projection(identity, indexed, rows) for slot, identity in refs.items()}
    return capture


def source_play(before, refs, rows, prompt=True):
    frame = copy.deepcopy(before)
    own = frame["state"]["players"]["p1"]
    own["hand"] = []
    own["ground"].append(dict(id="c0", setCode="SEC_142", hp=6, power=2, damage=0, exhausted=True, upgrades=[]))
    own["resources"][0]["exhausted"] = True
    if prompt:
        frame.update(decision="AbilityTarget", abilityProgramPlusOne=1, sourceInstance="c0", settled=False)
        frame["settlement"].update(decision="AbilityTarget", ability_program=1)
    frame["offeredActions"] = [dict(kind="card", card="c1")]
    return refresh(frame, refs, rows)


def settled_after(prompt, refs, rows, damage=2):
    frame = copy.deepcopy(prompt)
    frame.update(decision="Window", abilityProgramPlusOne=0, settled=True, offeredActions=[])
    frame["settlement"].update(decision="Window", ability_program=0)
    frame["state"]["players"]["p1"]["ground"][0]["damage"] = damage
    return refresh(frame, refs, rows)


def case_fixture():
    before, refs, rows = fixture()
    prompt = source_play(before, refs, rows)
    after = settled_after(prompt, refs, rows)
    play, target = before["offeredActions"][0], prompt["offeredActions"][0]
    witnesses = []
    for slot, host in (("nonunique_upgrade", "c1"), ("unique_upgrade", "c10")):
        query = copy.deepcopy(before)
        query.update(decision="UpgradeTarget", sourceInstance=refs[slot], settled=False,
                     offeredActions=[dict(kind="card", card=host)])
        query["settlement"]["decision"] = "UpgradeTarget"
        witnesses.append(dict(upgrade=refs[slot], host=host, publicTargetQuery=query, offeredHost=query["offeredActions"][0]))
    case = dict(card="SEC_142", state_family=0, refs=refs, chosen_ref="friendly_ground", observation_mode="chosen-target",
                before=before, playAction=play, targetPrompt=prompt, targetAction=target, final=after,
                engineError=None, completion="settled", applyCalls=2, chosenTargetCommitted=True, lastObserved=after,
                publicSnapshotRoundtripExact=True, attachmentTargetWitnesses=witnesses, shieldFixtureWitnesses=[],
                steps=[dict(stage="play-own-hand", before=before, action=play, after=prompt),
                       dict(stage="chosen-target", before=prompt, action=target, after=after)])
    plan = dict(query_specs={"SEC_142": [dict(ref="friendly_ground", mode="chosen-target")]},
                contexts=[dict(ready_resources=12, ground=dict(damage=0, exhausted=False, shield=0),
                               small=dict(code="UNIT", owner="p1", damage=0, exhausted=False, shield=0),
                               large=dict(code="UNIT", owner="p2", damage=0, exhausted=False, shield=0))])
    return case, plan, rows


class SyntheticVerifierTests(unittest.TestCase):
    def test_wire_physical_links_and_cached_tampering(self):
        capture, refs, rows = fixture()
        projections, indexed = V.validate_capture(capture, refs, rows)
        self.assertEqual(indexed["c4"]["host"], "c1")
        self.assertEqual(projections["friendly_ground"]["hp"], 12)
        capture["projections"]["friendly_ground"]["power"] = 99
        with self.assertRaisesRegex(ValueError, "cached projection"):
            V.validate_capture(capture, refs, rows)

    def test_opponent_privacy_and_duplicate_wire_rejected(self):
        capture, refs, rows = fixture()
        capture["state"]["players"]["p2"]["hand"] = [dict(id="secret", setCode="UNIT")]
        with self.assertRaisesRegex(ValueError, "opponent private"):
            V.validate_capture(capture, refs, rows)
        capture, refs, rows = fixture()
        capture["state"]["players"]["p1"]["ground"].append(copy.deepcopy(capture["state"]["players"]["p1"]["ground"][0]))
        with self.assertRaisesRegex(ValueError, "duplicate wire"):
            V.wire_index(capture)

    def test_settlement_requires_clean_explicit_queues(self):
        capture, _, _ = fixture()
        capture["settlement"]["death_pending"] = 1
        with self.assertRaisesRegex(ValueError, "queue witness"):
            V.explicit_settlement(capture)
        capture["settled"] = False
        self.assertFalse(V.explicit_settlement(capture))
        capture["settlement"]["support_pending"] = 0
        with self.assertRaisesRegex(ValueError, "boolean"):
            V.explicit_settlement(capture)

    def test_native_delta_known_zero_and_paid_source(self):
        case, plan, rows = case_fixture()
        sy, sm, ty, tm, _ = V.labels_for_case(case, plan, rows)
        self.assertEqual(sy[:3], [1., 1., 1.])
        self.assertEqual(sm[:3], [1., 1., 1.])
        self.assertEqual(ty[1], [1., 0., 2., 0., 0., 0., 0.])
        self.assertEqual(tm[1], [1.] * 7)
        self.assertEqual(sum(sum(row[1:]) for row in tm), 6.)

    def test_setup_requires_real_attachment_host_offer(self):
        case, plan, rows = case_fixture()
        case["attachmentTargetWitnesses"][0]["publicTargetQuery"]["offeredActions"] = []
        with self.assertRaisesRegex(ValueError, "actual public target query"):
            V.labels_for_case(case, plan, rows)

    def test_signed_power_hp_deltas_use_native_values(self):
        case, plan, rows = case_fixture()
        after = case["final"]
        after["state"]["players"]["p1"]["ground"][0].update(power=1, hp=11)
        refresh(after, case["refs"], rows)
        _, _, ty, tm, _ = V.labels_for_case(case, plan, rows)
        self.assertEqual(ty[1][5:], [-2., -1.])
        self.assertEqual(tm[1][5:], [1., 1.])

    def test_error_after_actual_target_attempt_keeps_futures_unknown(self):
        case, plan, rows = case_fixture()
        case.update(steps=case["steps"][:1], final=None, lastObserved=case["targetPrompt"],
                    engineError="NATIVE_APPLY_ERROR: synthetic", completion="native-error")
        pre, _ = V.validate_capture(case["before"], case["refs"], rows)
        with patch.object(V, "setup", return_value=(pre, {})):
            _, sm, _, tm, _ = V.labels_for_case(case, plan, rows)
        self.assertEqual(sm, [1.] + [0.] * 8)
        self.assertEqual([row[0] for row in tm], [1.] * 8)
        self.assertEqual(sum(sum(row[1:]) for row in tm), 0.)

    def test_pending_cannot_claim_final_label(self):
        case, plan, rows = case_fixture()
        case["final"]["settlement"]["pending_programs"] = 1
        pre, _ = V.validate_capture(case["before"], case["refs"], rows)
        with patch.object(V, "setup", return_value=(pre, {})), self.assertRaisesRegex(ValueError, "queue witness"):
            V.labels_for_case(case, plan, rows)

    def test_no_unit_death_or_xp_hook(self):
        before, refs, _ = fixture()
        after = copy.deepcopy(before)
        after["state"]["players"]["p2"]["space"][0]["hp"] = 0
        with self.assertRaisesRegex(ValueError, "nonpositive remaining HP"):
            V.no_unit_death_or_xp([before, after], refs)
        after = copy.deepcopy(before)
        after["state"]["players"]["p1"]["ground"][0]["upgrades"].append(dict(id="xp", setCode="TOKEN_EXPERIENCE", token=True))
        with self.assertRaisesRegex(ValueError, "XP hook"):
            V.no_unit_death_or_xp([before, after], refs)

    def test_journal_exact_success_and_missing_end_rejected(self):
        case, _, _ = case_fixture()
        receipt = dict(cases=[case], applyCalls=2, selectedWholeCards=["SEC_142"], collectionPlanSha256="synthetic")
        context = "SEC_142-family-0"
        journal = [dict(schema="native-effect-v2-apply-journal/1", sourceRevision=V.REVISION, selectedWholeCards=receipt["selectedWholeCards"], planSha256="synthetic")]
        for i, step in enumerate(case["steps"], 1):
            journal.extend([dict(phase="beforeApply", applyCall=i, context=context, branch=step["stage"], before=step["before"], offeredAction=step["action"]),
                            dict(phase="afterApply", applyCall=i, context=context, branch=step["stage"], after=step["after"])])
        journal.append(dict(phase="contextComplete", context=context, case=case))
        self.assertEqual(len(V.journal_check(journal, receipt)[0]), 2)
        journal.pop(-2)
        with self.assertRaisesRegex(ValueError, "global applies mismatch"):
            V.journal_check(journal, receipt)


if __name__ == "__main__":
    unittest.main()
