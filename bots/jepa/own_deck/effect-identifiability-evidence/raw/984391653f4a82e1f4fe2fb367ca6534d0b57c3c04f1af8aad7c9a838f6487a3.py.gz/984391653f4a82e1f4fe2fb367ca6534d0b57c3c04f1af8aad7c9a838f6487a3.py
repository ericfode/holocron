import json
from pathlib import Path
import tempfile
import unittest
import analysis_runner as R
class AnalysisTests(unittest.TestCase):
    def descriptor(self,d):
        script=d/'pure.py';script.write_text('print("pure fixture")\n');p=d/'command.json';value=dict(stage='converter',max_seconds=10.,zero_neural_native_reviewed=True,pins=[R.pin(script)],commands=[dict(argv=['/usr/bin/python3','-B',str(script)],cwd=str(d),env={})]);p.write_text(json.dumps(value));return p,value
    def test_preview_has_zero_work(self):
        with tempfile.TemporaryDirectory()as d:
            p,_=self.descriptor(Path(d));r=R.run(p,Path(d)/'out',Path(d)/'no-ledger');self.assertEqual(r['status'],'preview-no-execution');self.assertFalse((Path(d)/'out').exists())
    def test_changed_pin_rejected(self):
        with tempfile.TemporaryDirectory()as d:
            p,v=self.descriptor(Path(d));Path(v['pins'][0]['path']).write_text('different')
            with self.assertRaises(ValueError):R.descriptor(p)
    def test_mode_timeout_and_environment_fail_closed(self):
        with tempfile.TemporaryDirectory()as d:
            p,v=self.descriptor(Path(d))
            for change in ('time','mode','env'):
                value=json.loads(json.dumps(v))
                if change=='time':value['max_seconds']=11
                if change=='mode':value['commands'][0]['argv'].append('--execute')
                if change=='env':value['commands'][0]['env']['PYTHONHOME']='bad'
                p.write_text(json.dumps(value))
                with self.assertRaises(ValueError):R.descriptor(p)
    def test_direct_script_not_shell_or_c(self):
        with tempfile.TemporaryDirectory()as d:
            p,v=self.descriptor(Path(d));v['commands'][0]['argv']=['/bin/sh','-c','echo bad'];p.write_text(json.dumps(v))
            with self.assertRaises(ValueError):R.descriptor(p)
    def test_child_import_spawn_guard_without_importing_neural_library(self):
        from unittest.mock import patch
        registered=[]
        with patch('sys.addaudithook',side_effect=registered.append),patch('atexit.register'),patch.dict('os.environ',{},clear=True):
            scope={};exec((R.HERE/'analysis_guard/sitecustomize.py').read_text(),scope)
        hook=registered[0];hook('import',('numpy',None))
        for event,args in [('import',('torch',None)),('import',('jax.numpy',None)),('subprocess.Popen',('echo',)),('os.system',('echo',)),('socket.connect',('host',))]:
            with self.assertRaises(RuntimeError):hook(event,args)
        self.assertEqual(len(scope['violations']),5)
if __name__=='__main__':unittest.main()
