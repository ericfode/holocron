"""Verify and freeze the one shared campaign configuration. Never launch a job.

Default CLI mode is preview. --freeze only appends the one frozen config event;
it does not import a learner/engine, execute an argv, or spend anything.
"""
import argparse
import hashlib
import json
from pathlib import Path

import accounting as A

HERE = Path(__file__).resolve().parent
LEDGER = HERE / "campaign-ledger.jsonl"
ARMS = ["rich-typed", "sparse-typed", "rich-id-only", "rich-untrained-typed", "rich-wrong-typed"]
COUNTS = dict(updates_per_arm=200, optimizer_updates=1000, training_forwards=1000,
              evaluation_forwards=11, export_forwards=0)
NATIVE = dict(roots=48, max_applies_per_root=5, native_applies=240)


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path.resolve()), sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))


def verify_config(config, ledger=LEDGER):
    A.validate_config(config)
    if str(Path(config["ledger_path"]).resolve()) != str(Path(ledger).resolve()):
        raise ValueError("config must identify the fixed shared ledger")
    if config["arms"] != ARMS or any(config[k] != v for k, v in COUNTS.items()):
        raise ValueError("exact reviewed five-arm/1000-update/1011-forward allocation required")
    if config.get("native_allocation") != NATIVE:
        raise ValueError("exact48 roots and240 native apply reservation required")
    if config.get("hypothesis_status") != "reviewed-before-labels":
        raise ValueError("hypothesis/protocol must be reviewed before label collection")
    seen = set()
    pins = []
    for expected in config["pins"]:
        if not isinstance(expected, dict) or set(expected) != {"path", "sha256", "bytes"}:
            raise ValueError("every frozen pin requires exact path/sha256/bytes")
        path = Path(expected["path"])
        if not path.is_absolute() or str(path.resolve()) != expected["path"]:
            raise ValueError("frozen paths must be absolute and canonical")
        if expected["path"] in seen:
            raise ValueError("duplicate frozen source/input pin")
        if type(expected["bytes"]) is not int or expected["bytes"] < 0:
            raise ValueError("pin byte size must be a nonnegative integer")
        actual = pin(path)
        if actual != expected:
            raise ValueError("frozen source/input bytes differ: " + str(path))
        seen.add(expected["path"])
        pins.append(actual)
    for required in (HERE / "accounting.py", Path(__file__).resolve()):
        if str(required.resolve()) not in seen:
            raise ValueError("freeze must pin the accounting module and launcher")
    return pins


def inspect_or_freeze(config_path, *, ledger=LEDGER, freeze=False):
    config_path = Path(config_path).resolve()
    config = json.loads(config_path.read_text())
    verified = verify_config(config, ledger)
    with A.lease(ledger) as (stream, rows, current):
        if current["frozen"] or current["attempts"]:
            raise ValueError("campaign already frozen/started; never replace or reset config")
        before = current["last_hash"]
        if freeze:
            current = A.append(stream, rows, ledger, "frozen", config)
        return dict(schema="jepa-effect-identifiability-freeze/1",
                    status="frozen-no-workload-launched" if freeze else "preview-only-unfrozen",
                    config_file=pin(config_path), config_sha256=config["config_sha256"],
                    verified_pins=verified, ledger=pin(ledger),
                    previous_ledger_record_sha256=before, ledger_state=current,
                    counters=dict(native_applies=0, optimizer_updates=0, neural_forwards=0,
                                  paid_jobs=0, paid_spend_usd=0))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--freeze", action="store_true", help="append one frozen config only, after coordinator GO")
    parser.add_argument("--receipt", help="new receipt path under this campaign; existing files are never replaced")
    args = parser.parse_args()
    target = Path(args.receipt).resolve() if args.receipt else None
    if target and (not target.is_relative_to(HERE) or target.exists()):
        raise ValueError("receipt must be a new campaign-local path")
    result = inspect_or_freeze(args.config, freeze=args.freeze)
    output = json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + "\n"
    if target:
        with target.open("x") as stream:
            stream.write(output)
            stream.flush()
            A.os.fsync(stream.fileno())
    print(output, end="")


if __name__ == "__main__":
    main()
