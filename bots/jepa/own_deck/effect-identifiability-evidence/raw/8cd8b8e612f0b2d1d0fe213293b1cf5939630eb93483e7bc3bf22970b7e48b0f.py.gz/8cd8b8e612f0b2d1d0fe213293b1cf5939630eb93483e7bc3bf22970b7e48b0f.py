import copy
import json
from pathlib import Path
import tempfile
import unittest

import accounting as A
import freeze_campaign as F


def config(ledger, extra):
    value = dict(limits=copy.deepcopy(A.CAPS), arms=F.ARMS.copy(), **F.COUNTS,
                 native_allocation=F.NATIVE.copy(), hypothesis_status="reviewed-before-labels",
                 ledger_path=str(ledger.resolve()),
                 pins=[F.pin(F.HERE / "accounting.py"), F.pin(Path(F.__file__)), F.pin(extra)])
    value["config_sha256"] = A.digest(value)
    return value


class FreezeTests(unittest.TestCase):
    def setup_paths(self, directory):
        root = Path(directory)
        ledger = root / "ledger.jsonl"
        A.initialize(ledger, {"test_only": True})
        source = root / "reviewed-source.txt"
        source.write_text("pure fixture, no workload\n")
        target = root / "config.json"
        return ledger, source, target

    def save(self, target, value):
        target.write_text(json.dumps(value))

    def test_preview_changes_no_ledger_bytes_then_freeze_is_one_event_only(self):
        with tempfile.TemporaryDirectory() as name:
            ledger, source, target = self.setup_paths(name)
            self.save(target, config(ledger, source))
            before = ledger.read_bytes()
            preview = F.inspect_or_freeze(target, ledger=ledger)
            self.assertEqual(ledger.read_bytes(), before)
            self.assertFalse(preview["ledger_state"]["frozen"])
            receipt = F.inspect_or_freeze(target, ledger=ledger, freeze=True)
            self.assertTrue(receipt["ledger_state"]["frozen"])
            self.assertEqual(receipt["ledger_state"]["attempts"], 0)
            self.assertEqual(len(ledger.read_text().splitlines()), 2)
            with self.assertRaisesRegex(ValueError, "already frozen"):
                F.inspect_or_freeze(target, ledger=ledger, freeze=True)

    def test_changed_source_bytes_block_freeze_without_append(self):
        with tempfile.TemporaryDirectory() as name:
            ledger, source, target = self.setup_paths(name)
            self.save(target, config(ledger, source)); before = ledger.read_bytes()
            source.write_text("mutated fixture\n")
            with self.assertRaisesRegex(ValueError, "bytes differ"):
                F.inspect_or_freeze(target, ledger=ledger, freeze=True)
            self.assertEqual(ledger.read_bytes(), before)

    def test_wrong_quotas_or_fixed_ledger_or_missing_launcher_pin_rejected(self):
        with tempfile.TemporaryDirectory() as name:
            ledger, source, _ = self.setup_paths(name)
            base = config(ledger, source)
            for change in (dict(evaluation_forwards=10), dict(native_allocation=dict(F.NATIVE, native_applies=256)),
                           dict(ledger_path=str(Path(name) / "other.jsonl")), dict(pins=[F.pin(source)])):
                value = dict(base, **change)
                value["config_sha256"] = A.digest({k:v for k,v in value.items() if k != "config_sha256"})
                with self.assertRaises(ValueError): F.verify_config(value, ledger)

    def test_pin_size_hash_and_duplicates_are_all_checked(self):
        with tempfile.TemporaryDirectory() as name:
            ledger, source, _ = self.setup_paths(name)
            for mode in ("size", "hash", "duplicate"):
                value = config(ledger, source)
                if mode == "size": value["pins"][-1]["bytes"] += 1
                elif mode == "hash": value["pins"][-1]["sha256"] = "0" * 64
                else: value["pins"].append(value["pins"][-1])
                value["config_sha256"] = A.digest({k:v for k,v in value.items() if k != "config_sha256"})
                with self.assertRaises(ValueError): F.verify_config(value, ledger)


if __name__ == "__main__": unittest.main()
