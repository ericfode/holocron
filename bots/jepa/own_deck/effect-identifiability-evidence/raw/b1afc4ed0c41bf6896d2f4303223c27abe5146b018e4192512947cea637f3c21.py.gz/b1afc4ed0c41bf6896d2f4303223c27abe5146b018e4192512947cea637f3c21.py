"""One append-only failed closure of known analysis attempt4; preview by default.

No analysis, process signals, retry, reset, credit or workload execution.
"""
import argparse
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
LAST='17d41a9a5a7dd34c47b05d32d15b0d21eaeb3b0f7ee43e54befcb8d46e82d819'
ACCOUNTING='a72d3ccc9bb381ba626032481d1bbb980236e302a6d532b0960e11445df8e0f9'
EXPECTED={'analysis_runner.py':'beba893341f6cf5118519ae41dcdfe1dc5c53b64954e7d7b5b83b80d63cb0772','analysis_guard/sitecustomize.py':'359b907fc5449e7a58f20e65f5695496720c5ceddf3044eacbf255ec6c33a3cd','analysis-seal-preflight/child-0-proof.json':'341f28ed92b8b3569b8781f0a4921fcc07cb46d691c51b20eec66dd48ff54ffc','analysis-seal-preflight/child-0.stdout':'e15edc3e69983485924c4f524e0dcee46e0f42b3020189f2b00e4d1b3161e41c','analysis-seal-preflight/child-0.stderr':'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855','learner-plan.json':'6eadc7c3231c93b8aeebf85e1d6d44bb16b98ff80143283cc84c95071a3dd3b2'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
 p=Path(p).resolve();return dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--append-failed-finish',action='store_true');a=p.parse_args();ledger=HERE/'campaign-ledger.jsonl'
 if sha(HERE/'accounting.py')!=ACCOUNTING:raise ValueError('accounting changed')
 spec=importlib.util.spec_from_file_location('recovery_accounting',HERE/'accounting.py');A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)
 with ledger.open('r+')as stream:
  fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);rows=A.read_rows(stream);state=A.state(rows,ledger)
  if rows[-1]['record_sha256']!=LAST or rows[-1]['event']!='attempt-start' or state['pending']['attempt']!=4:raise ValueError('exact pending4 required; no reset/retry')
  pending=state['pending'];reservation=dict(phase='other',active_seconds=5,native_applies=0,optimizer_updates=0,training_forwards=0,evaluation_forwards=0,export_forwards=0)
  if pending['reservation']!=reservation or pending['metadata']['analysis_stage']!='seal-preflight':raise ValueError('reservation differs')
  for item in pending['metadata']['pins']:
   if pin(item['path'])!=item:raise ValueError('attempt input changed: '+item['path'])
  for key in ('command','runner','guard','process_readers'):
   item=pending['metadata'][key]
   if pin(item['path'])!=item:raise ValueError('attempt source changed: '+key)
  evidence=[]
  for name,expected in EXPECTED.items():
   path=HERE/name
   if sha(path)!=expected:raise ValueError('recovery artifact differs: '+name)
   evidence.append(pin(path))
  folder=HERE/'analysis-seal-preflight'
  if list(folder.glob('child-1*')) or (folder/'receipt.json').exists() or (HERE/'fit-1').exists() or (HERE/'fit-progress.jsonl').exists():raise ValueError('unexpected later analysis/fit artifact')
  proof=json.loads((folder/'child-0-proof.json').read_text());plan=json.loads((HERE/'learner-plan.json').read_text());stdout=json.loads((folder/'child-0.stdout').read_text())
  if not proof['guard_loaded']or proof['violations']or proof['neural_modules_loaded']or any(proof[k]!=0 for k in ('native_applies','optimizer_updates','neural_forwards')):raise ValueError('zero workload proof differs')
  if stdout['sha256']!=EXPECTED['learner-plan.json']or plan['status']!='sealed-awaiting-root-GO'or not plan['support_admission']['passed']:raise ValueError('completed seal witness differs')
  receipt=dict(schema='effect-analysis-pending4-manual-failed-closure/1',status='failed',attempt=4,pending_start_sha256=LAST,ledger_sha256_before=sha(ledger),recovery_source=pin(__file__),evidence=evidence,charged_active_seconds=5.0,actual_elapsed_seconds=None,charge_basis='Conservative full5second reservation; not reconstructed measured runtime. Outer elapsed is not persisted.',native_applies=0,optimizer_updates=0,training_forwards=0,evaluation_forwards=0,export_forwards=0,root_reported_cleanup_error='PermissionError EPERM from finally os.killpg; original triggering exception not preserved.',underlying_error='unknown; RSS/exit race is an unconfirmed hypothesis',process_evidence=dict(normal_atexit_child_guard_proof=True,reviewed_seal_has_no_spawn_or_neural_path=True,child1_artifacts_absent=True,formal_OS_process_absence_proof=False,limitations='No child PID persisted; ps blocked by sandbox. Normal reviewed seal atexit completion is scoped workload-completion evidence, not an OS death observation.'),preservation='All input/output bytes retained. Failed closure only; no reset, quota credit, retry or seal rerun.',unexecuted_second_preflight=True)
  if not a.append_failed_finish:
   path=HERE/'pending-analysis4-recovery-plan.json'
   if path.exists():
    if json.loads(path.read_text())!=receipt:raise FileExistsError('preserve historical preview')
   else:path.write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
   print(json.dumps(dict(status='preview-no-ledger-write',receipt=pin(path))));return
  target=folder/'recovery-receipt.json'
  with target.open('x')as f:json.dump(receipt,f,indent=2,allow_nan=False);f.write('\n')
  result=A.append(stream,rows,ledger,'attempt-finish',dict(attempt=4,status='failed',active_seconds=5.0,native_applies=0,native_journal_verified=True,observed_optimizer_updates=0,training_forwards=0,evaluation_forwards=0,export_forwards=0,receipt=pin(target),recovery='explicit conservative full-reservation manual failed closure; no reset/credit'))
  print(json.dumps(dict(status='failed-finish-appended',receipt=pin(target),ledger_sha256=sha(ledger),pending=result['pending'],active_seconds=result['active_seconds'],other_seconds=result['phase_seconds']['other'])))
if __name__=='__main__':main()
