"""Independent saved-public-state -> dataset verifier. No engine/model imports.

Default prints source-only usage and never opens receipts, labels or arrays.
Use --verify only after the coordinator authorizes inspection of collected data.
The verification reads immutable files and writes one NEW audit JSON. Numeric
labels come from captured public native wire values, never rule/effect amounts.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import sys

REVISION = "c7ee39554901278cee70f61fd8b26fb1920696b3"
TRAIN = ("ASH_048", "LOF_151", "SEC_142", "JTL_144", "JTL_217", "ASH_171", "SEC_051")
HELD = ("JTL_102", "LAW_131", "JTL_079", "LAW_127", "ASH_228")
SLOTS = ("source", "friendly_ground", "space_small", "space_large", "nonunique_upgrade", "unique_upgrade", "own_base", "opponent_base")
ASPECTS = ("vigilance", "command", "aggression", "cunning", "heroism", "villainy")
CONTEXT = ("ready_resources", "source_in_hand", *("own_aspect_" + x for x in ASPECTS),
           "other_friendly_space_count", "other_friendly_fighter_count", "source_power", "source_hp", "source_damage", "source_exhausted",
           "known_source_power", "known_source_hp", "known_source_damage", "known_source_exhausted")
CANDIDATE = ("owner_self", "owner_opponent", "is_unit", "is_base", "zone_ground", "zone_space", "same_source", "present",
             "damage", "hp", "remaining_hp", "power", "exhausted", "shield_count", "xp_count", "known_damage", "known_hp",
             "known_remaining_hp", "known_power", "known_exhausted", "known_shield_count", "known_xp_count", "trait_imperial", "trait_creature",
             "trait_spectre", "known_traits", "printed_cost", "known_printed_cost", "unique", "known_unique", "is_upgrade", "is_leader", "trait_vehicle", "trait_fighter")
SOURCE_HEADS = ("play_available", "play_committed", "cost_resource", "source_in_arena", "source_in_discard", "source_in_hand_after", "source_damage_delta", "source_shield_delta", "source_exhausted_after")
TARGET_HEADS = ("target_allowed", "target_removed", "target_damage_delta", "target_exhausted_delta", "target_shield_delta", "target_power_delta", "target_hp_delta")
DELTA_FIELDS = ("damage", "exhausted", "shield_count", "power", "hp")
MODES = {"chosen-target", "upgrade-attachment", "passive-area-anchor", "self-entry"}
QUEUES = ("ability_program", "death_depth", "death_pending", "death_window", "pending_programs", "pending_triggers", "after_attack_triggers", "after_attack_programs")
KNOWN_FIELDS = ("identity", "owner", "damage", "exhausted", "hp", "power", "shield_count", "xp_count")


def require(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def boolean(value, message="explicit boolean required"):
    require(type(value) is bool, message)
    return value


def number(value):
    require(type(value) in (int, float) and math.isfinite(value), "finite public number required")
    return value


def explicit_settlement(capture):
    witness = capture["settlement"]
    require(witness["decision"] == capture["decision"] and witness["ability_program"] == capture["abilityProgramPlusOne"], "settlement/capture mismatch")
    for key in QUEUES:
        require(type(witness[key]) is int and witness[key] >= 0, "invalid settlement queue")
    terminal = boolean(capture["terminal"])
    event_active = boolean(witness["event_group_active"])
    support_pending = boolean(witness["support_pending"])
    settled = terminal or (capture["decision"] == "Window" and all(witness[k] == 0 for k in QUEUES)
                           and not event_active and not support_pending)
    require(boolean(capture["settled"]) == settled, "settled flag lacks queue witness")
    require(not terminal, "unreviewed terminal root")
    return settled


def wire_index(capture):
    """Native snapshot membership/parent links, independent of cached projections."""
    indexed = {}
    for seat in ("p1", "p2"):
        player = capture["state"]["players"][seat]
        for key in ("hand", "deck", "resources", "discard", "ground", "space"):
            require(isinstance(player[key], list), "zone must be a public list")
        require(not player["deck"], "hidden draw pile/order in capture")
        require(seat != "p2" or (not player["hand"] and not player["resources"]), "opponent private hand/resource identities in capture")
        for zone in ("base", "leader", "hand", "resources", "discard", "ground", "space"):
            cards = [player[zone]] if zone in ("base", "leader") else player[zone]
            for card in cards:
                identity = card["id"]
                require(identity not in indexed, "duplicate wire identity/zone")
                indexed[identity] = dict(wire=card, seat=seat, zone="resource" if zone == "resources" else zone, host=None)
                for upgrade in card.get("upgrades", []):
                    require(zone in ("ground", "space"), "upgrades require an arena parent")
                    require(upgrade["id"] not in indexed, "duplicate physical attachment/token identity")
                    require(upgrade.get("parent", identity) == identity, "attachment parent differs from nesting")
                    indexed[upgrade["id"]] = dict(wire=upgrade, seat=seat, zone="upgrade", host=identity)
    return indexed


def derive_projection(identity, indexed, rows):
    entry = indexed.get(identity)
    if entry is None:
        # This bounded cohort has no ordinary unit defeat. Only a genuinely
        # absent reference can use this branch; no guessed identity/statistics.
        return dict(id=identity, code=None, owner=None, zone="absent", present=False, in_arena=False, attackable=False, is_unit=False, is_base=False,
                    damage=0, exhausted=False, hp=0, power=0, shield_count=0, xp_count=0,
                    known={key: False for key in KNOWN_FIELDS})
    wire, zone, seat = entry["wire"], entry["zone"], entry["seat"]
    code = wire.get("setCode") or wire.get("code")
    require(code in rows, "wire references a card absent from complete pinned definitions")
    printed = rows[code]["card"]
    types = set(printed["types"])
    unit = "unit" in types or "leader" in types and wire.get("deployed") is True
    base, upgrade = "base" in types, "upgrade" in types
    owner = wire.get("owner", wire.get("controller", seat))
    require(owner in ("p1", "p2"), "public owner unknown")
    # Thin own-hand/discard references omit counters. These fixtures construct
    # the own source with default0/False and never override its hand counters.
    damage = 0 if upgrade else wire.get("damage", 0)
    exhausted = False if upgrade else wire.get("exhausted", False)
    hp = wire.get("hp", printed.get("hp"))
    power = wire.get("power", printed.get("power"))
    attached = wire.get("upgrades", []) if unit else []
    shields = [card for card in attached if card.get("setCode") == "TOKEN_SHIELD"]
    xp = [card for card in attached if card.get("setCode") == "TOKEN_EXPERIENCE"]
    for token in shields + xp:
        require(token.get("token") is True, "Shield/Experience is not a physical native token")
    known = dict(identity=True, owner=True, damage=unit or base, exhausted=unit, hp=(unit or base) and hp is not None,
                 power=unit and power is not None, shield_count=unit, xp_count=unit)
    return dict(id=identity, code=code, zone=zone, owner=owner, present=True, is_unit=unit, is_base=base, in_arena=zone in ("ground", "space"),
                attackable=zone in ("ground", "space", "base"), damage=number(damage), exhausted=boolean(exhausted),
                hp=0 if upgrade or hp is None else number(hp), power=0 if upgrade or power is None else number(power),
                shield_count=len(shields), xp_count=len(xp), known=known)


def validate_capture(capture, refs, rows):
    explicit_settlement(capture)
    require(set(capture["projections"]) == set(SLOTS) and set(refs) == set(SLOTS), "candidate roles differ")
    require(len(set(refs.values())) == 8, "candidate reference IDs not distinct")
    indexed = wire_index(capture)
    independently_derived = {}
    for slot in SLOTS:
        original = capture["projections"][slot]
        require(original["id"] == refs[slot], "stable reference drift")
        require(set(original["known"]) == set(KNOWN_FIELDS), "known-mask ABI drift")
        for flag in original["known"].values():
            boolean(flag)
        public = derive_projection(refs[slot], indexed, rows)
        for key in ("id", "code", "zone", "owner", "present", "in_arena", "attackable", "is_unit", "is_base", "damage", "exhausted", "hp", "power", "shield_count", "xp_count", "known"):
            # Removed references have unknowable def/type after deletion. Their
            # future numeric masks must be0; identity/zone are still checked.
            if not public["present"] and key in ("damage", "exhausted", "hp", "power", "shield_count", "xp_count"):
                continue
            require(original[key] == public[key], f"cached projection differs from wire: {slot}/{key}")
        independently_derived[slot] = public
    return independently_derived, indexed


def offered(capture, identity):
    return [action for action in capture["offeredActions"] if action.get("kind") == "card" and action.get("card") == identity]


def resources(capture):
    cards = capture["state"]["players"]["p1"]["resources"]
    return sum(not boolean(card["exhausted"]) for card in cards)


def candidate_features(p, source_id, rows):
    card = rows[p["code"]]["card"] if p["code"] in rows else None
    k = p["known"]
    values = [p["owner"] == "p1", p["owner"] == "p2", p.get("is_unit", card is not None and "unit" in card["types"]),
              card is not None and "base" in card["types"], p["zone"] == "ground", p["zone"] == "space", p["id"] == source_id, p["present"]]
    numeric = {key: float(p[key]) if k[key] else 0. for key in ("damage", "hp", "power", "exhausted", "shield_count", "xp_count")}
    remaining = k["hp"] and k["damage"]
    values += [numeric["damage"], numeric["hp"], numeric["hp"] - numeric["damage"] if remaining else 0., numeric["power"], numeric["exhausted"], numeric["shield_count"], numeric["xp_count"],
               k["damage"], k["hp"], remaining, k["power"], k["exhausted"], k["shield_count"], k["xp_count"]]
    traits = card.get("traits") if card else None
    known_traits = isinstance(traits, list) and all(isinstance(t, str) for t in traits)
    traits = set(t.lower() for t in traits) if known_traits else set()
    values += [x in traits for x in ("imperial", "creature", "spectre")] + [known_traits]
    cost = card.get("cost") if card else None
    cost_known = type(cost) in (int, float) and math.isfinite(cost)
    unique = card.get("unique") if card else None
    values += [cost if cost_known else 0., cost_known, unique if type(unique) is bool else False, type(unique) is bool,
               card is not None and "upgrade" in card["types"], card is not None and "leader" in card["types"], "vehicle" in traits, "fighter" in traits]
    require(len(values) == 34, "candidate34 contract")
    return [float(value) for value in values]


def context_features(capture, p, refs, indexed, rows):
    aspects = Counter()
    player = capture["state"]["players"]["p1"]
    for role in ("base", "leader"):
        code = player[role].get("setCode") or player[role].get("code") or capture["own_aspect_sources"][role]
        aspects.update(rows[code]["card"]["aspects"])
    own_units = [entry for entry in indexed.values() if entry["seat"] == "p1" and entry["zone"] in ("ground", "space") and entry["wire"]["id"] != refs["source"]]
    spaces = sum(entry["zone"] == "space" for entry in own_units)
    fighters = sum("fighter" in rows[entry["wire"]["setCode"]]["card"]["traits"] for entry in own_units)
    require(capture["other_friendly_space_count"] == spaces and capture["other_friendly_fighter_count"] == fighters, "cached public counts differ")
    source = p["source"]
    return [resources(capture), float(source["zone"] == "hand"), *(aspects[x] for x in ASPECTS), spaces, fighters,
            *(float(source[x]) for x in ("power", "hp", "damage", "exhausted")), *(float(source["known"][x]) for x in ("power", "hp", "damage", "exhausted"))]


def setup(case, plan, rows):
    b, refs = case["before"], case["refs"]
    p, indexed = validate_capture(b, refs, rows)
    context = plan["contexts"][case["state_family"]]
    require(explicit_settlement(b) and b["decision"] == "Window" and case["publicSnapshotRoundtripExact"] is True, "root not settled/roundtrip certified")
    require(resources(b) == context["ready_resources"] and len(b["state"]["players"]["p1"]["resources"]) == 12, "setup resources differ")
    require(p["source"]["code"] == case["card"] and p["source"]["owner"] == "p1" and p["source"]["zone"] == "hand", "source not own exact known hand card")
    require(len(b["state"]["players"]["p1"]["hand"]) == 1, "unreviewed own hand content")
    for slot, name in (("friendly_ground", "ground"), ("space_small", "small"), ("space_large", "large")):
        expected = context[name]
        require((p[slot]["damage"], p[slot]["exhausted"], p[slot]["shield_count"]) == (expected["damage"], expected["exhausted"], expected["shield"]), "planned public anchor state differs")
        if name != "ground":
            require((p[slot]["code"], p[slot]["owner"]) == (expected["code"], expected["owner"]), "space helper/owner differs")
    witnesses = case["attachmentTargetWitnesses"]
    require(len(witnesses) == 2, "initial physical attachments lack both legality queries")
    for slot, witness in zip(("nonunique_upgrade", "unique_upgrade"), witnesses):
        q = witness["publicTargetQuery"]
        validate_capture(q, refs, rows)
        entry = indexed.get(refs[slot])
        require(entry is not None and entry["zone"] == "upgrade" and entry["host"] == witness["host"], "initial attachment physical parent differs")
        require(witness["upgrade"] == refs[slot] and q["decision"] == "UpgradeTarget" and q["sourceInstance"] == refs[slot] and witness["offeredHost"] in offered(q, entry["host"]), "initial attachment not certified by actual public target query")
    physical_shields = {(identity, e["host"]): e for identity, e in indexed.items() if e["wire"].get("setCode") == "TOKEN_SHIELD"}
    declared = case["shieldFixtureWitnesses"]
    require(len(declared) == len(physical_shields), "incomplete Shield fixture witnesses")
    require(len({x["token"] for x in declared}) == len(declared), "duplicate Shield witness")
    for witness in declared:
        entry = physical_shields.get((witness["token"], witness["parent"]))
        require(entry is not None and witness["code"] == "TOKEN_SHIELD" and witness["owner"] == entry["seat"] and witness["sourceHash"] == rows["TOKEN_SHIELD"]["sourceHash"], "physical Shield source/owner/parent differs")
    return p, indexed


def journal_check(records, receipt):
    header = records[0]
    require(header["schema"] == "native-effect-v2-apply-journal/1" and header["sourceRevision"] == REVISION, "journal header/revision")
    require(header["selectedWholeCards"] == receipt["selectedWholeCards"] and header["planSha256"] == receipt["collectionPlanSha256"], "journal source/plan binding")
    intents, ends, completed = {}, {}, {}
    for row in records[1:]:
        phase = row["phase"]
        if phase == "beforeApply":
            n = row["applyCall"]
            require(type(n) is int and n == len(intents) + 1, "journal nonsequential/duplicate intent")
            require(row["offeredAction"] in row["before"]["offeredActions"], "attempted action not actually offered")
            intents[n] = row
        elif phase in ("afterApply", "applyError"):
            n = row["applyCall"]
            require(n in intents and n not in ends, "journal outcome lacks unique intent")
            require((row["context"], row["branch"]) == (intents[n]["context"], intents[n]["branch"]), "journal attempt identity differs")
            ends[n] = row
        elif phase == "contextComplete":
            require(row["context"] not in completed, "duplicate root journal boundary")
            completed[row["context"]] = row["case"]
        else:
            raise ValueError("unexpected journal phase")
    require(len(intents) == receipt["applyCalls"] and set(intents) == set(ends), "journal/receipt global applies mismatch")
    for case in receipt["cases"]:
        key = f"{case['card']}-family-{case['state_family']}"
        require(completed.get(key) == case, "journal case boundary differs")
        ns = [n for n, row in intents.items() if row["context"] == key]
        require(len(ns) == case["applyCalls"] == len(case["steps"]) + int(case["engineError"] is not None), "root apply accounting")
        for n, step in zip(ns, case["steps"]):
            before, end = intents[n], ends[n]
            require(before["before"] == step["before"] and before["offeredAction"] == step["action"] and before["branch"] == step["stage"] and end.get("after") == step["after"], "step detached from durable apply boundary")
        if case["engineError"] is not None:
            require(ns and ends[ns[-1]]["phase"] == "applyError", "engine error lacks durable attempted apply")
            failed = intents[ns[-1]]
            last = case["steps"][-1]["after"] if case["steps"] else case["before"]
            require(failed["before"] == last and failed["offeredAction"] in last["offeredActions"], "failed apply not tied to last offered public frame")
    require(set(completed) == {f"{c['card']}-family-{c['state_family']}" for c in receipt["cases"]}, "missing/extra root journal boundaries")
    return intents, ends


def no_unit_death_or_xp(captures, refs):
    before = wire_index(captures[0])
    original_units = {identity for identity, e in before.items() if e["zone"] in ("ground", "space")}
    enemy_before = {identity for identity in original_units if before[identity]["seat"] == "p2"}
    for capture in captures:
        indexed = wire_index(capture)
        for identity in original_units:
            require(identity in indexed and indexed[identity]["zone"] in ("ground", "space"), "unreviewed fixture unit death/removal")
            wire = indexed[identity]["wire"]
            require(number(wire["hp"]) - number(wire["damage"]) > 0, "nonpositive remaining HP in unreviewed death path")
        require({i for i, e in indexed.items() if e["seat"] == "p2" and e["zone"] in ("ground", "space")} == enemy_before, "opponent-unit identity changed")
        require(not any(e["wire"].get("setCode") == "TOKEN_EXPERIENCE" for e in indexed.values()), "unmeasured XP hook/token appeared")
        require(all(p["xp_count"] == 0 for p in capture["projections"].values()), "XP projection observed despite no-death scope")


def labels_for_case(case, plan, rows):
    b, refs = case["before"], case["refs"]
    pre, _ = setup(case, plan, rows)
    spec = plan["query_specs"][case["card"]][case["state_family"]]
    require(case["chosen_ref"] == spec["ref"] and case["observation_mode"] == spec["mode"] and spec["mode"] in MODES, "query chosen after outcomes or unknown role")
    mode, chosen = spec["mode"], spec["ref"]
    source, source_mask = [0.] * 9, [0.] * 9
    target, target_mask = [[0.] * 7 for _ in SLOTS], [[0.] * 7 for _ in SLOTS]
    source[0], source_mask[0] = float(bool(offered(b, refs["source"]))), 1.
    require((case["playAction"] is None) == (source[0] == 0), "source offer/action mismatch")
    if case["playAction"] is not None:
        require(case["playAction"] in offered(b, refs["source"]), "play source action identity")
    captures, last, committed_target = [b], b, False
    for index, step in enumerate(case["steps"]):
        require(step["before"] == last and step["action"] in last["offeredActions"], "raw offered chain differs")
        action, stage = step["action"], step["stage"]
        if index == 0:
            require(stage == "play-own-hand" and action == case["playAction"], "first native action not own source play")
        elif stage in ("chosen-target", "attach-intended-host"):
            decision = "AbilityTarget" if stage == "chosen-target" else "UpgradeTarget"
            expected_mode = "chosen-target" if stage == "chosen-target" else "upgrade-attachment"
            require(not committed_target and mode == expected_mode and last["decision"] == decision and last == case["targetPrompt"] and action == case["targetAction"] and action in offered(last, refs[chosen]), "target commit lacks exact actual prompt/identity")
            committed_target = True
        elif stage == "decline-unoffered-target":
            require(last == case["targetPrompt"] and not offered(last, refs[chosen]) and (action.get("arg") in ("cancel", "passAbility") or action.get("label") == "Cancel"), "decline replaced a legal selected target")
        elif stage == "accept-optional-trigger":
            require(last["decision"] == "AbilityOptional" and action.get("arg") == "trigger", "optional menu choice differs")
        elif stage == "use-no-effect-anyway":
            require(last["decision"] == "AbilityNoEffect" and type(action.get("arg")) is int and action["arg"] == 0, "no-effect continuation differs")
        elif stage == "sole-trigger-order":
            require(last["decision"] == "TriggerOrder" and len(last["offeredActions"]) == 1, "non-unique trigger continuation")
        else:
            raise ValueError("unreviewed continuation stage")
        validate_capture(step["after"], refs, rows)
        captures.append(step["after"])
        last = step["after"]
    require(case.get("lastObserved", last) == last, "last observed frame differs")
    attempted = case["targetAction"] is not None
    require(case.get("chosenTargetCommitted", attempted) == attempted, "attempted-target diagnostic flag differs")
    prompt = case["targetPrompt"]
    if prompt is not None:
        validate_capture(prompt, refs, rows)
        require(mode in ("chosen-target", "upgrade-attachment") and any(step["after"] == prompt for step in case["steps"]), "fictional target prompt")
        if attempted:
            require(case["targetAction"] in offered(prompt, refs[chosen]), "attempted target not offered")
        for index, slot in enumerate(SLOTS):
            target[index][0], target_mask[index][0] = float(bool(offered(prompt, refs[slot]))), 1.
    else:
        require(not attempted, "target action without prompt")
    final = case["final"]
    if final is not None:
        require(final == last and case["engineError"] is None and case["completion"] == "settled" and explicit_settlement(final), "future labels without settled exact native endpoint")
        post, indexed = validate_capture(final, refs, rows)
        a, z = pre["source"], post["source"]
        source_attached = refs["source"] in indexed and indexed[refs["source"]]["zone"] == "upgrade"
        did_play = z["zone"] != "hand" and (z["in_arena"] or z["zone"] == "discard" or z["zone"] == "upgrade" and source_attached)
        cost = resources(b) - resources(final)
        require(cost >= 0, "unexpected resource gain")
        source[1:] = [float(did_play), float(cost), float(z["in_arena"]), float(z["zone"] == "discard"), float(z["zone"] == "hand"), z["damage"] - a["damage"], z["shield_count"] - a["shield_count"], float(z["exhausted"])]
        source_mask[1:6] = [1.] * 5
        for index, field in ((6, "damage"), (7, "shield_count"), (8, "exhausted")):
            source_mask[index] = float(z["in_arena"] and a["known"][field] and z["known"][field])
        observe = did_play and cost > 0 and (committed_target if mode in ("chosen-target", "upgrade-attachment") else True)
        if mode == "upgrade-attachment" and committed_target:
            require(source_attached and indexed[refs["source"]]["host"] == refs[chosen], "actual physical upgrade source attached elsewhere")
        if mode == "passive-area-anchor":
            require(case["card"] == "SEC_051" and not committed_target and prompt is None, "area anchor mislabeled as target choice")
        if mode == "self-entry" and observe:
            require(chosen == "source" and z["in_arena"], "entry anchor is not source lifecycle")
        if observe:
            a, z = pre[chosen], post[chosen]
            removed = not z["present"] or z["zone"] in ("discard", "absent")
            index = SLOTS.index(chosen)
            target[index][1], target_mask[index][1] = float(removed), 1.
            continuous = mode != "self-entry" and not removed and a["present"] and z["present"] and a["zone"] == z["zone"]
            for h, field in enumerate(DELTA_FIELDS, 2):
                if continuous and a["known"][field] and z["known"][field]:
                    target[index][h] = float(z[field]) - float(a[field])
                    target_mask[index][h] = 1.
            if case["card"] == "JTL_079":
                require(not removed and z["known"]["hp"] and z["known"]["damage"] and z["hp"] - z["damage"] > 0, "held targeted-stat probe did not survive")
    if not source[0]:
        require(not case["steps"] and case["final"] is None and case["engineError"] is None and prompt is None, "unavailable action has fictional futures")
    no_unit_death_or_xp(captures, refs)
    return source, source_mask, target, target_mask, pre


def assembled_subset_hash(generated, selected):
    manifest = read(generated / "manifest.json")
    shards = {key: read(generated / manifest["files"][key]) for key in ("cards", "inputs", "diagnostics")}
    require(all(shard["compilerHash"] == manifest["compilerHash"] for shard in shards.values()), "catalogue shard compiler hashes differ")
    diagnostics = {r["setCode"]: r["diagnostics"] for r in shards["diagnostics"]["cards"]}
    cards = [{**row, "diagnostics": diagnostics.get(row["setCode"], [])} for row in shards["cards"]["cards"] if row["setCode"] in selected]
    subset = dict(schema="swu-card-ir/v1", **{key: manifest[key] for key in ("compilerVersion", "typescriptVersion", "sourceTreeHash", "compilerHash", "sourceSupport", "inventory")}, inputs=shards["inputs"]["inputs"], cards=cards)
    return digest(subset)


def support(values, masks, names):
    import numpy as np
    result = {}
    for h, name in enumerate(names):
        y, mask = values[..., h], masks[..., h] > 0
        known = y[mask]
        def roots(condition):
            return int(np.count_nonzero(condition if condition.ndim == 1 else condition.any(axis=-1)))
        result[name] = dict(known=int(mask.sum()), roots=roots(mask), values=np.unique(known).astype(float).tolist(), zero=int(((y == 0) & mask).sum()), nonzero=int(((y != 0) & mask).sum()),
                            positive=int(((y > 0) & mask).sum()), negative=int(((y < 0) & mask).sum()), zero_roots=roots((y == 0) & mask), nonzero_roots=roots((y != 0) & mask), positive_roots=roots((y > 0) & mask), negative_roots=roots((y < 0) & mask))
    return result


def verify(args):
    import numpy as np
    plan, receipt, manifest = read(args.plan), read(args.receipt), read(args.manifest)
    require(receipt["schema"] == "jepa-native-effect-v2/1" and receipt["sourceRevision"] == REVISION, "native receipt ABI/revision")
    require(receipt["collectionPlan"] == plan and receipt["collectionPlanSha256"] == sha(args.plan), "raw frozen plan differs")
    require(receipt["candidateOrder"] == list(SLOTS) == plan["candidate_order"], "candidate slot ABI")
    require((plan["context_feature_names"], plan["candidate_feature_names"], plan["source_head_names"], plan["target_names"]) == (list(CONTEXT), list(CANDIDATE), list(SOURCE_HEADS), list(TARGET_HEADS)), "named numeric ABI differs")
    require(receipt["selectedWholeCards"] == plan["selected_whole_cards"] and receipt["selectedCatalogueSha256"] == assembled_subset_hash(args.generated, plan["selected_whole_cards"]), "complete selected native catalogue differs")
    require(sha(args.dataset) == manifest["artifact"]["sha256"] and sha(args.receipt) == manifest["native_receipt"]["sha256"] and sha(args.journal) == manifest["journal"]["sha256"], "dataset/receipt/journal artifact pins")
    for item in [*manifest.get("source_pins", []), *plan.get("source_pins", [])]:
        require(sha(item["path"]) == item["sha256"], "frozen source input changed: " + item["path"])
    require(receipt.get("noHiddenCardsOrDrawOrder") is True and receipt.get("forcetekiOracleRun") is False, "native privacy/oracle declaration differs")
    cases = sorted(receipt["cases"], key=lambda x: (x["state_family"], x["card"]))
    require(len(cases) == 48 and {(c["card"], c["state_family"]) for c in cases} == {(code, f) for code in TRAIN + HELD for f in range(4)}, "48 roots / complete card-state product")
    require(len(plan["cards"]) == 12 and plan["split"]["train_codes"] == list(TRAIN) and plan["split"]["heldout_codes"] == list(HELD), "frozen7/5 cohort differs")
    require(type(receipt["applyCalls"]) is int and 0 <= receipt["applyCalls"] <= 240, "native apply quota")
    journal = [json.loads(line) for line in args.journal.read_text().splitlines() if line.strip()]
    journal_check(journal, receipt)
    require(sum(c["applyCalls"] for c in cases) == receipt["applyCalls"], "sum root applies differs")
    require(manifest["records"] == cases and manifest["plan"] == plan, "manifest raw records/plan differ")
    require(manifest.get("semantic_validated") is False, "unreviewed semantic qualification claim")
    require(manifest["cards"] == {card["code"]: card for card in plan["cards"]}, "manifest whole card/split flags differ")
    rows = {row["setCode"]: row for row in read(args.generated / "cards.json")["cards"]}
    for code, row in plan["selected_whole_rows"].items():
        require(rows.get(code) == row, "unmodified full compiler row differs: " + code)
    source, source_mask, targets, target_mask, context, candidates, indices, partitions = [], [], [], [], [], [], [], []
    cards = {card["code"]: card for card in plan["cards"]}
    for case in cases:
        code, family = case["card"], case["state_family"]
        require(case["identity_partition"] == cards[code]["partition"] and case["state_partition"] == plan["contexts"][family]["partition"], "case split flags differ")
        require(type(case["applyCalls"]) is int and 0 <= case["applyCalls"] <= 5, "root apply quota")
        sy, sm, ty, tm, pre = labels_for_case(case, plan, rows)
        source.append(sy); source_mask.append(sm); targets.append(ty); target_mask.append(tm)
        _, indexed = validate_capture(case["before"], case["refs"], rows)
        context.append(context_features(case["before"], pre, case["refs"], indexed, rows))
        candidates.append([candidate_features(pre[slot], case["refs"]["source"], rows) for slot in SLOTS])
        indices.append(SLOTS.index(case["chosen_ref"]))
        partitions.append("joint" if code in HELD and family == 3 else "program-held" if code in HELD else "state-held" if family == 3 else "train")
    expected = dict(source_targets=np.asarray(source, np.float32), source_mask=np.asarray(source_mask, np.float32), targets=np.asarray(targets, np.float32), target_mask=np.asarray(target_mask, np.float32),
                    context_features=np.asarray(context, np.float32), candidate_features=np.asarray(candidates, np.float32), candidate_mask=np.ones((48, 8), np.float32),
                    source_cards=np.asarray([c["card"] for c in cases]), state_families=np.asarray([c["state_family"] for c in cases], np.int64), partition=np.asarray(partitions),
                    selected_candidate_indices=np.asarray(indices, np.int64), observation_modes=np.asarray([c["observation_mode"] for c in cases]), native_family_ids=np.asarray([cards[c["card"]]["family"] for c in cases]))
    for part in ("train", "program-held", "state-held", "joint"):
        expected[part.replace("-", "_") + "_idx"] = np.flatnonzero(expected["partition"] == part).astype(np.int64)
    require([len(expected[k + "_idx"]) for k in ("train", "program_held", "state_held", "joint")] == [21, 15, 7, 5], "21/15/7/5 split differs")
    expected["sparse_source_mask"] = expected["source_mask"].copy()
    expected["sparse_target_mask"] = expected["target_mask"].copy()
    expected["sparse_target_mask"][expected["train_idx"], :, 2:7] = 0
    with np.load(args.dataset, allow_pickle=False) as packed:
        require(set(packed.files) == set(expected), "unexpected/missing NPZ fields")
        for key, value in expected.items():
            require(packed[key].shape == value.shape and packed[key].dtype == value.dtype and np.array_equal(packed[key], value), "independent wire-derived array mismatch: " + key)
    groups = {part: np.flatnonzero(expected["partition"] == part) for part in set(partitions)}
    groups.update({code: np.flatnonzero(expected["source_cards"] == code) for code in TRAIN + HELD})
    independent_support = {}
    for group, ix in groups.items():
        independent_support[group] = {**support(expected["source_targets"][ix], expected["source_mask"][ix], SOURCE_HEADS), **support(expected["targets"][ix], expected["target_mask"][ix], TARGET_HEADS)}
    # The saved converter exposes zero/positive/negative root counts but not
    # nonzero_roots. Keep the latter independent diagnostic without requiring
    # a field outside that frozen manifest ABI.
    manifest_support = {group: {name: {key: value for key, value in counts.items() if key != "nonzero_roots"}
                                for name, counts in heads.items()} for group, heads in independent_support.items()}
    require(manifest_support == manifest["head_support"], "manifest support counts/known zeros/signs differ")
    errors = [dict(card=c["card"], state=c["state_family"], reason=c["engineError"]) for c in cases if c["engineError"] is not None]
    pending = [dict(card=c["card"], state=c["state_family"], completion=c["completion"]) for c in cases if c["playAction"] is not None and c["final"] is None and c["engineError"] is None]
    require(manifest["native_engine_error_roots"] == len(errors) and manifest["pending_roots"] == len(pending), "manifest failure/pending accounting differs")
    blockers = []
    if errors: blockers.append("native engine errors")
    if pending: blockers.append("pending native outcomes")
    primary = []
    for name in TARGET_HEADS[2:]:
        s = independent_support["train"][name]
        eligible = s["zero_roots"] >= 2 and s["nonzero_roots"] >= 2
        primary.append(dict(head=name, eligible=eligible, **s))
        if not eligible: blockers.append("TRAIN lacks2known-zero+2known-nonzero roots: " + name)
    require(bool(manifest["planned_settlement_precheck_passed"]) == (not errors and not pending), "settlement fit gate flag differs")
    conflicts = []
    contract = read(args.cohort_contract)
    docs = {c["code"]: c["normalized_program_group"] for c in contract["cards"]}
    require(set(docs) == set(TRAIN + HELD), "strict family contract cohort differs")
    seen = {}
    for i, case in enumerate(cases):
        intended = indices[i]
        source_key = docs[case["card"]] + expected["context_features"][i].tobytes().hex() + expected["candidate_features"][i, intended].tobytes().hex()
        for kind, names, ys, ms in (("source", SOURCE_HEADS, expected["source_targets"][i:i+1], expected["source_mask"][i:i+1]), ("candidate", TARGET_HEADS, expected["targets"][i], expected["target_mask"][i])):
            for j in range(len(ys)):
                base = source_key if kind == "source" else docs[case["card"]] + expected["context_features"][i].tobytes().hex() + expected["candidate_features"][i, j].tobytes().hex()
                for h, name in enumerate(names):
                    if ms[j, h]:
                        key = (kind, base, name)
                        value = float(ys[j, h])
                        if key in seen and seen[key][0] != value:
                            conflicts.append(dict(kind=kind, head=name, first=seen[key], second=[value, i, j]))
                        seen[key] = (value, i, j)
    if conflicts: blockers.append("identical available model inputs have conflicting known native labels")
    pair_diagnostics = []
    by_root = {(case["card"], case["state_family"]): i for i, case in enumerate(cases)}
    for pair in plan.get("predeclared_behavior_pairs", []):
        left, right = (by_root[(pair[side]["card"], pair[side]["state"])] for side in ("left", "right"))
        li, ri = indices[left], indices[right]
        measured = {}
        for head in pair["heads"]:
            h = TARGET_HEADS.index(head)
            known = bool(expected["target_mask"][left, li, h] and expected["target_mask"][right, ri, h])
            lv, rv = float(expected["targets"][left, li, h]), float(expected["targets"][right, ri, h])
            measured[head] = dict(both_known=known, left=lv if known else None, right=rv if known else None, right_minus_left=rv-lv if known else None)
        pair_diagnostics.append(dict(id=pair["id"], family=pair["family"], measurements=measured))
    return dict(schema="native-effect-v2-independent-verification/1", status="PASS-data-contract", fit_gate="BLOCKED" if blockers else "PASS", fit_blockers=blockers,
                method="Independent native wire/state+physical links to arrays; no production converter/planner helpers, no IR-derived effect targets, no native/model/optimizer execution.",
                sources={key: dict(path=str(path), sha256=sha(path)) for key, path in dict(verifier=Path(__file__), plan=args.plan, receipt=args.receipt, journal=args.journal, dataset=args.dataset, manifest=args.manifest, cohort_contract=args.cohort_contract).items()},
                roots=48, native_apply_calls_in_receipt=receipt["applyCalls"], roots_by_partition={k: len(v) for k, v in groups.items() if k in ("train", "program-held", "state-held", "joint")},
                independent_support=independent_support, primary_train_support_gate=primary, input_conflicts=conflicts, errors=errors, pending=pending,
                predeclared_pair_measurements=pair_diagnostics,
                preserved_unknown_masks=True, privacy_checks_passed=True, all_original_units_survive=True, no_xp_hook_observed=True,
                fit_scope="Three held template families; source availability is constant-positive diagnostic. SEC051XP/SEC142onAttack unmeasured; no whole-card/gameplay claim.",
                audit_compute=dict(native_applies=0, neural_forwards=0, backwards=0, optimizer_updates=0))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true", help="Only after root authorizes reading actual collected labels")
    for key in ("plan", "receipt", "journal", "dataset", "manifest", "cohort-contract", "out"):
        parser.add_argument("--" + key, type=Path)
    parser.add_argument("--generated", type=Path, default=Path("/Users/ericfode/Documents/Codex/2026-10-17/task-5/kessel-pilot-source/compiler/generated"))
    args = parser.parse_args()
    if not args.verify:
        print(json.dumps(dict(status="SOURCE-ONLY-NO-INPUTS-OPENED", verifier_sha256=sha(__file__), native_applies=0, neural_forwards=0, optimizer_updates=0)))
        return
    require(all(getattr(args, key.replace("-", "_")) is not None for key in ("plan", "receipt", "journal", "dataset", "manifest", "cohort-contract", "out")), "verify needs explicit input/output paths")
    require(not args.out.exists(), "preserve prior verification; choose a new output")
    try:
        report = verify(args)
    except BaseException as error:
        report = dict(schema="native-effect-v2-independent-verification/1", status="FAIL", fit_gate="BLOCKED", error_type=type(error).__name__, error=str(error), verifier_sha256=sha(__file__), audit_compute=dict(native_applies=0, neural_forwards=0, optimizer_updates=0))
        args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
        raise
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps(dict(path=str(args.out), sha256=sha(args.out), status=report["status"], fit_gate=report["fit_gate"], fit_blockers=report["fit_blockers"])))
    if report["fit_gate"] != "PASS":
        sys.exit(2)


if __name__ == "__main__":
    main()
