import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import analysis_once as A

class AnalysisOnceTests(unittest.TestCase):
    def fixture(self,root):
        entry=root/'pure.py';entry.write_text('raise AssertionError("preview must not execute")\n')
        desc=dict(stage='data',seconds=10.,argv=[str(entry),'--run'],outputs=[str(root/'new-output')],pins=[A.pin(entry),A.pin(A.E_PATH),A.pin(Path(A.__file__))])
        records=[]
        for event,data in [('initialized',{}),('attempt-start',{}),('attempt-finish',{'status':'completed'})]:
            body=dict(sequence=len(records),previous_sha256=records[-1]['record_sha256']if records else'0'*64,event=event,data=data);records.append(dict(body,record_sha256=A.digest(body)))
        (root/'campaign-ledger.jsonl').write_text(''.join(json.dumps(x)+'\n'for x in records))
        p=root/'descriptor.json';p.write_text(json.dumps(desc));return p,desc
    def test_preview_no_marker_journal_or_script_and_ledger_identical(self):
        with tempfile.TemporaryDirectory()as name:
            root=Path(name).resolve();p,d=self.fixture(root);before=(root/'campaign-ledger.jsonl').read_bytes()
            with patch.object(A,'HERE',root):self.assertEqual(A.once(p)['status'],'preview-only')
            self.assertEqual(before,(root/'campaign-ledger.jsonl').read_bytes());self.assertFalse((root/'data.once.json').exists());self.assertFalse((root/'analysis-ledger.jsonl').exists())
    def test_marker_blocks_retry_and_pending_neural_blocks_preview(self):
        with tempfile.TemporaryDirectory()as name:
            root=Path(name).resolve();p,d=self.fixture(root);(root/'data.once.json').write_text('{}')
            with patch.object(A,'HERE',root),self.assertRaises(FileExistsError):A.once(p)
            (root/'data.once.json').unlink();records=A.rows(root/'campaign-ledger.jsonl');(root/'campaign-ledger.jsonl').write_text(''.join(json.dumps(x)+'\n'for x in records[:-1]))
            with patch.object(A,'HERE',root),self.assertRaises(ValueError):A.once(p)
    def test_exact_caps_pins_and_new_campaign_outputs(self):
        with tempfile.TemporaryDirectory()as name:
            root=Path(name).resolve();p,d=self.fixture(root)
            for change in [dict(seconds=11.),dict(stage='other'),dict(outputs=[str(p)]),dict(outputs=['/tmp/unrelated']),dict(pins=[])]:
                value=dict(d,**change)
                with patch.object(A,'HERE',root),self.assertRaises(ValueError):A.validate(value)
            Path(d['argv'][0]).write_text('changed')
            with patch.object(A,'HERE',root),self.assertRaises(ValueError):A.validate(d)
    def test_append_hash_chain_and_tamper_rejected(self):
        with tempfile.TemporaryDirectory()as name:
            p=Path(name)/'analysis.jsonl';A.append(p,'start',{'no_compute':True});A.append(p,'finish',{'active_seconds':.1})
            records=A.rows(p);A.chain(records);records[-1]['data']['active_seconds']=0
            with self.assertRaises(ValueError):A.chain(records)

if __name__=='__main__':unittest.main()
