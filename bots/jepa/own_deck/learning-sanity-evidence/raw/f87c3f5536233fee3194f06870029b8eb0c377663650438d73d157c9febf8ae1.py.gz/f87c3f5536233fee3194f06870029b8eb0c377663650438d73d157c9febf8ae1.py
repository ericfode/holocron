"""Saved-byte evidence packaging only; no neural/native/optimizer execution."""
import argparse,fcntl,gzip,hashlib,json,os
from pathlib import Path
ROOT=Path('/Users/ericfode/Documents/Codex/2026-10-17/task-7')
REPO=ROOT/'holocron-deck-context';CYCLE=ROOT/'experiments/learning-sanity-v1'
FINAL=REPO/'bots/jepa/own_deck/learning-sanity-evidence';STAGING=FINAL.with_name(FINAL.name+'.staging')
PARENT=ROOT/'experiments/effect-identifiability-v2'
PARENT_FILE_SHA='e69410d8caa5c5219f46107a6238e4c811125c65cead3db15d970b9a25133259'
PARENT_CHAIN='a4ebccf072b203af8242004155be55dd0f8b34ba4ec68532aa12d172986a1cf0'
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),sha256=sha(b),bytes=len(b))
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
    with p.open('x')as f:json.dump(x,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
def chain(p):
    records=[json.loads(x)for x in Path(p).read_text().splitlines()if x.strip()];previous='0'*64
    for i,r in enumerate(records):
        body={k:v for k,v in r.items()if k!='record_sha256'}
        assert r['sequence']==i and r['previous_sha256']==previous and sha(json.dumps(body,sort_keys=True,separators=(',',':'),allow_nan=False).encode())==r['record_sha256'];previous=r['record_sha256']
    return records,previous
def main(report_sha):
    import numpy as np  # only saved NPZ deserialization/bitwise verification
    assert not FINAL.exists()and not STAGING.exists()
    report=REPO/'bots/jepa/own_deck/LEARNING_SANITY_RESULTS.md';assert pin(report)['sha256']==report_sha
    parent_pin=pin(PARENT/'campaign-ledger.jsonl');assert parent_pin['sha256']==PARENT_FILE_SHA
    assert chain(PARENT/'campaign-ledger.jsonl')[1]==PARENT_CHAIN
    sanity=read(CYCLE/'sanity-plan.json');data=read(CYCLE/'data-plan.json');result=read(CYCLE/'fit-1/result.json')
    assert result['status']=='completed'and result['semantic_validated']is False
    assert result['counts']==dict(optimizer_updates=900,training_forwards=900,evaluation_forwards=6,export_forwards=0,backwards=900)
    baseline=read(CYCLE/'data-analysis-1/result.json');assert baseline['compute']['closed_form_head_fits']==32
    assert read(CYCLE/'independent-verification.json')['status']=='PASS'
    protected=read(CYCLE/'protected-after.json');assert protected['status']in('passed','PASS')
    source_pins={}
    for document in [sanity,data,read(CYCLE/'data-descriptor.json'),read(CYCLE/'verification-descriptor.json')]:
        for p in document['pins']:
            assert pin(p['path'])==p,p['path'];old=source_pins.get(p['path']);assert old is None or old==p;source_pins[p['path']]=p
    paths={}
    def add(p,role):
        p=Path(p)
        if p.is_symlink()or not p.is_file():raise ValueError('regular source required: '+str(p))
        paths.setdefault(p.resolve(),set()).add(role)
    for p in CYCLE.rglob('*'):
        if '__pycache__'not in p.parts and p.is_file()and p.suffix not in('.pyc','.pyo'):add(p,'complete-new-cycle-raw')
    for p in source_pins.values():add(p['path'],'active-input-or-source-pin')
    add(report,'final-root-results-report');add(__file__,'packaging-source')
    for name in ['LEARNING_SANITY_PROTOCOL.md','learning_sanity.py','test_learning_sanity.py','learning_sanity_data.py','test_learning_sanity_data.py']:
        add(REPO/'bots/jepa/own_deck'/name,'executed-source-protocol-or-pure-tests')
    parent_index=REPO/'bots/jepa/own_deck/effect-identifiability-evidence/index.json';parent_index_pin=pin(parent_index)
    parent_index_data=read(parent_index)
    for p in parent_index_data['artifacts']:
        if 'attribution-preserved-from-prior-publication'in p['roles']:
            add(parent_index.parent/p['url'],'attribution-preserved-parent-compressed-bytes')
    prior_protected=parent_index_data['provenance']['prior_publications']
    for p in prior_protected:assert pin(p['path'])=={k:p[k]for k in('path','sha256','bytes')}
    with (CYCLE/'campaign-ledger.jsonl').open('r')as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);nn,last=chain(CYCLE/'campaign-ledger.jsonl')
        assert len(nn)==3 and nn[-1]['event']=='attempt-finish'and nn[-1]['data']['status']=='completed'
        analyses,analysis_last=chain(CYCLE/'analysis-ledger.jsonl');assert len(analyses)==4 and all(r['data']['status']=='completed'for r in analyses if r['event']=='finish')
        STAGING.mkdir();(STAGING/'raw').mkdir();artifacts=[];by_path={}
        for p in sorted(paths):
            raw=p.read_bytes();expected=pin(p);assert sha(raw)==expected['sha256']and len(raw)==expected['bytes']
            binary=p.suffix in('.npz','.npy','.gz','.zip');stored=raw if binary else gzip.compress(raw,compresslevel=9,mtime=0)
            url='raw/'+expected['sha256']+(p.suffix.lower()or'.txt')+(''if binary else'.gz');target=STAGING/url
            if not target.exists():
                with target.open('xb')as f:f.write(stored)
            assert target.read_bytes()==stored
            a=dict(url=url,sha256=sha(stored),bytes=len(stored),encoding='identity'if binary else'gzip',original_sha256=expected['sha256'],original_bytes=len(raw),roles=sorted(paths[p]),status='byte-exact-preservation',provenance=dict(original_path=str(p)))
            artifacts.append(a);by_path[str(p)]=a
        registry=dict(schema='learning-sanity-source-closure/1',sources=[dict(original_path=p['path'],expected_sha256=p['sha256'],bytes=p['bytes'],url=by_path[p['path']]['url'])for p in source_pins.values()],archive_relocations=[],raw_path_rule='Absolute paths within unmodified raw JSON are provenance, never fetch URLs; use explicit bundle-relative URLs only.')
        write(STAGING/'source-closure.json',registry);spaces=[]
        for arm in('correct','fixed-shuffle','fresh-shuffle'):
            source=CYCLE/'fit-1'/f'{arm}-step300-predictions.npz'
            with np.load(source,allow_pickle=False)as arrays:vector=arrays['card_vectors'].copy()
            assert vector.shape==(12,16)and vector.dtype==np.float32 and np.isfinite(vector).all()
            rows=[dict(id=code,source_card=code,split='train'if code in sanity['train_codes']else'heldout',family_id=sanity['split']['family_groups'][code],vector=vector[i].tolist(),semantic_validated=False)for i,code in enumerate(sanity['codes'])]
            value=dict(schema='learning-sanity-saved-vector-bank/1',space_id='learning-sanity-v1-'+arm,arm=arm,dimension=16,dtype='float32',semantic_validated=False,scope='Saved final step300 evaluation bank only; TRAIN overfit is not semantics or held transfer. Each checkpoint has its own basis.',source_array=by_path[str(source)],checkpoint=by_path[str(CYCLE/'fit-1'/f'{arm}-checkpoint.npz')],rows=rows)
            p=STAGING/(arm+'-vectors.json');write(p,value);b=p.read_bytes();spaces.append(dict(id=value['space_id'],url=p.name,sha256=sha(b),bytes=len(b),rows=12,dimension=16,dtype='float32',arm=arm,semantic_validated=False))
        for p in paths:assert pin(p)['sha256']==by_path[str(p)]['original_sha256'],'input changed during copy'
        assert pin(PARENT/'campaign-ledger.jsonl')==parent_pin and pin(parent_index)==parent_index_pin
        for p in prior_protected:assert pin(p['path'])=={k:p[k]for k in('path','sha256','bytes')}
        times=dict(neural=read(CYCLE/'fit-1/receipt.json')['active_seconds'],data=read(CYCLE/'data-analysis-receipt.json')['active_seconds'],verification=read(CYCLE/'verification-analysis-receipt.json')['active_seconds'])
        index=dict(schema='learning-sanity-evidence/1',status='completed-diagnostic-no-semantic-qualification',semantic_validated=False,artifacts=artifacts,spaces=spaces,source_closure=dict(url='source-closure.json'),source_pins_verified=len(source_pins),correct_overfit_gate=result['correct_overfit_gate'],compute=dict(new_increment=dict(optimizer_updates=900,neural_forwards=906,training_forwards=900,evaluation_forwards=6,export_forwards=0,native_applies=0,closed_form_head_fits=32,active_seconds=sum(times.values()),phase_seconds=times,paid_jobs=0,paid_spend_usd=0),parent_PR36_subtotal=dict(optimizer_updates=1000,neural_forwards=1011,native_applies=87,charged_active_seconds=parent_index_data['ledger_final_state']['active_seconds'],closed_form_head_fits=0),linked_two_cycle_subtotal=dict(optimizer_updates=1900,neural_forwards=1917,native_applies=87,closed_form_head_fits=32),scope='This linked two-cycle subtotal only; not an invented all-history total. New authorization adds exposure and never resets prior accounting.'),execution_source=dict(neural_commit='187860ce7dfd76aae5e574d5b73f7371542ea918',analysis_commit='d5939b2285a8cb7d8a59d57a61d3345e278a0512'),accounting=dict(neural_final_record=last,analysis_final_record=analysis_last,failures=0,retries=0),provenance=dict(parent_ledger=parent_pin,parent_final_record=PARENT_CHAIN,parent_evidence=parent_index_pin,prior_publication_pins=prior_protected),limitations=['Correct TRAIN overfit passed; fixed assigned labels also fit and fresh/true controls differ. This is diagnostic, not card-semantic qualification.','Held correct1.5998 remains worse than zero1.4147. Preserve all per-head, ridge/constant, unknown/support and descriptive consumed-held results.','No new native calls, paid compute, capacity search or new representation. Prior publications remain unchanged.'],packaging=dict(neural_forwards=0,native_applies=0,optimizer_updates=0,paid_jobs=0))
        write(STAGING/'index.json',index);files=[]
        for p in sorted(STAGING.rglob('*')):
            if p.is_file():b=p.read_bytes();files.append(dict(url=str(p.relative_to(STAGING)),sha256=sha(b),bytes=len(b)))
        write(STAGING/'manifest.json',dict(schema='learning-sanity-evidence-manifest/1',files=files,file_count=len(files),semantic_validated=False,self_hash='external'))
        os.rename(STAGING,FINAL)
        receipt=dict(status='sealed-saved-data-only',destination=str(FINAL),index=pin(FINAL/'index.json'),manifest=pin(FINAL/'manifest.json'),source_closure=pin(FINAL/'source-closure.json'),raw_records=len(artifacts),unique_raw_payloads=len(list((FINAL/'raw').iterdir())),total_files=len(files)+1,stored_bytes=sum(p.stat().st_size for p in FINAL.rglob('*')if p.is_file()),source_pins_verified=len(source_pins),vector_spaces=3,vector_rows=36,all_source_bytes_verified_after_copy=True,parent_and_prior_publications_unchanged=True,neural_forwards=0,native_applies=0,optimizer_updates=0,paid_jobs=0)
        write(Path(__file__).parent/'packaging-receipt.json',receipt);print(json.dumps(receipt,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--report-sha256',required=True);main(p.parse_args().report_sha256)
