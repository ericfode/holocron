"""Preparation-only accounting. No subprocess/model/engine entry points.

The coordinator must freeze exact source/config/quotas before obtaining an
attempt lease. One fixed ledger is hash chained and append only; a pending
attempt or damaged journal blocks later work. No credits/reset event exists.
"""
from contextlib import contextmanager
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path

SCHEMA = "jepa-effect-identifiability-accounting/1"
PHASES = ("native", "card", "other")
CAPS = dict(active_seconds=180., native_seconds=90., card_seconds=60., other_seconds=30.,
            native_applies=256, optimizer_updates=1200, rss_bytes=1073741824,
            cpu_threads=1, paid_jobs=0, paid_spend_usd=0.)


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def nonnegative(value, integer=False):
    if integer:
        if type(value) is not int or value < 0:
            raise ValueError("nonnegative integer counter required")
    elif type(value) not in (int, float) or not math.isfinite(value) or value < 0:
        raise ValueError("finite nonnegative time required")
    return value


def state(rows, ledger_path):
    result = dict(initialized=False, frozen=False, config=None, pending=None,
                  active_seconds=0., phase_seconds={p: 0. for p in PHASES},
                  native_applies=0, optimizer_updates=0, observed_optimizer_updates=0,
                  training_forwards=0, evaluation_forwards=0, export_forwards=0,
                  observed_training_forwards=0, observed_evaluation_forwards=0, observed_export_forwards=0,
                  attempts=0, failures=0, ceiling_violated=False, last_hash="0" * 64)
    for i, row in enumerate(rows):
        body = {k: v for k, v in row.items() if k != "record_sha256"}
        if type(row.get("sequence")) is not int or row.get("sequence") != i or row.get("previous_sha256") != result["last_hash"] or digest(body) != row.get("record_sha256"):
            raise ValueError("ledger sequence/hash chain damaged; no reset")
        event, data = row["event"], row["data"]
        if event == "initialized":
            if i or data["ledger_path"] != str(Path(ledger_path).resolve()) or data["schema"] != SCHEMA:
                raise ValueError("one fixed initialized ledger required")
            result["initialized"] = True
        elif not result["initialized"]:
            raise ValueError("campaign initialization required")
        elif event == "frozen":
            if result["frozen"] or result["pending"]:
                raise ValueError("config cannot be refrozen/reset")
            validate_config(data)
            result.update(frozen=True, config=data)
        elif event == "attempt-start":
            if not result["frozen"] or result["pending"]:
                raise ValueError("frozen config and no unfinished attempt required")
            reservation = data["reservation"]
            check_reservation(result, reservation)
            if data["attempt"] != result["attempts"] + 1:
                raise ValueError("attempt sequence cannot reset")
            result["attempts"] += 1
            result["pending"] = data
        elif event == "attempt-finish":
            pending = result["pending"]
            if pending is None or data["attempt"] != pending["attempt"]:
                raise ValueError("finish must match the live attempt")
            if data["status"] not in ("completed", "failed", "stopped"):
                raise ValueError("explicit completed/failed/stopped status required")
            seconds = nonnegative(data["active_seconds"])
            actual_calls = nonnegative(data["native_applies"], True)
            actual_updates = nonnegative(data["observed_optimizer_updates"], True)
            reserve = pending["reservation"]
            if type(data["native_journal_verified"]) is not bool:
                raise ValueError("explicit journal/zero-native proof status required")
            calls = max(reserve["native_applies"], actual_calls) if not data["native_journal_verified"] else actual_calls
            updates = actual_updates if data["status"] == "completed" else max(reserve["optimizer_updates"], actual_updates)
            if data["status"] == "completed" and not data["native_journal_verified"]:
                raise ValueError("completed stage requires verified native journal/zero-native proof")
            if data["status"] == "completed" and (seconds > reserve["active_seconds"] or actual_calls > reserve["native_applies"] or actual_updates != reserve["optimizer_updates"]):
                raise ValueError("completed stage violates its time/counter allocation")
            for key in ("training_forwards", "evaluation_forwards", "export_forwards"):
                observed = nonnegative(data[key], True)
                if data["status"] == "completed" and observed != reserve[key]:
                    raise ValueError("completed stage differs from fixed forward allocation")
                result["observed_" + key] += observed
                result[key] += observed if data["status"] == "completed" else max(observed, reserve[key])
            result["active_seconds"] += seconds
            result["phase_seconds"][reserve["phase"]] += seconds
            result["native_applies"] += calls
            result["optimizer_updates"] += updates
            result["observed_optimizer_updates"] += actual_updates
            result["failures"] += data["status"] != "completed"
            result["pending"] = None
            result["ceiling_violated"] = (result["active_seconds"] > CAPS["active_seconds"]
                or any(result["phase_seconds"][p] > CAPS[p + "_seconds"] for p in PHASES)
                or result["native_applies"] > CAPS["native_applies"]
                or result["optimizer_updates"] > result["config"]["optimizer_updates"]
                or any(result[key] > result["config"][key] for key in ("training_forwards", "evaluation_forwards", "export_forwards")))
        else:
            raise ValueError("unsupported event; no credits, resets or implicit amendments")
        result["last_hash"] = row["record_sha256"]
    return result


def validate_config(config):
    if config.get("limits") != CAPS or config.get("config_sha256") != digest({k: v for k, v in config.items() if k != "config_sha256"}):
        raise ValueError("exact ceilings and canonical frozen config digest required")
    arms = config["arms"]
    if not isinstance(arms, list) or not 4 <= len(arms) <= 6 or len(set(arms)) != len(arms) or any(not isinstance(x, str) or not x for x in arms):
        raise ValueError("freeze four to six unique named arms")
    per_arm = nonnegative(config["updates_per_arm"], True)
    if not 1 <= per_arm <= 200 or config["optimizer_updates"] != per_arm * len(arms):
        raise ValueError("exact matched arm/update allocation required")
    if config["optimizer_updates"] > CAPS["optimizer_updates"]:
        raise ValueError("update ceiling exceeded")
    for key in ("training_forwards", "evaluation_forwards", "export_forwards"):
        nonnegative(config[key], True)
    if config["evaluation_forwards"] > 12 or config["export_forwards"] != 0:
        raise ValueError("at most12 fixed eval calls; capture exports in those calls")
    if not isinstance(config.get("pins"), list) or not config["pins"]:
        raise ValueError("frozen source/data/command/config pins required")


def check_reservation(current, reservation):
    if current["ceiling_violated"]:
        raise ValueError("prior ceiling violation blocks every further workload")
    phase = reservation["phase"]
    if phase not in PHASES:
        raise ValueError("unknown phase")
    seconds = nonnegative(reservation["active_seconds"])
    if not seconds or current["active_seconds"] + seconds > CAPS["active_seconds"] or current["phase_seconds"][phase] + seconds > CAPS[phase + "_seconds"]:
        raise ValueError("active wall allocation exhausted; no cap reset")
    for key in ("native_applies", "optimizer_updates"):
        nonnegative(reservation[key], True)
        maximum = current["config"][key] if key == "optimizer_updates" else CAPS[key]
        if current[key] + reservation[key] > maximum:
            raise ValueError("campaign counter allocation exhausted")
    if phase != "native" and reservation["native_applies"] or phase != "card" and reservation["optimizer_updates"]:
        raise ValueError("phase/counter mismatch")
    config = current["config"]
    for key in ("training_forwards", "evaluation_forwards", "export_forwards"):
        nonnegative(reservation[key], True)
        if phase != "card" and reservation[key]:
            raise ValueError("only the frozen card phase may execute neural calls")
        if current[key] + reservation[key] > config[key]:
            raise ValueError("fixed forward budget exhausted")


def read_rows(stream):
    stream.seek(0)
    return [json.loads(line) for line in stream if line.strip()]


def append(stream, rows, ledger_path, event, data):
    previous = state(rows, ledger_path)
    body = dict(sequence=len(rows), previous_sha256=previous["last_hash"], event=event, data=data)
    row = dict(body, record_sha256=digest(body))
    state([*rows, row], ledger_path)  # reject invalid event before append
    stream.seek(0, os.SEEK_END)
    stream.write(encoded(row).decode() + "\n"); stream.flush(); os.fsync(stream.fileno())
    rows.append(row)
    return state(rows, ledger_path)


@contextmanager
def lease(path):
    """Hold this nonblocking lease for the ENTIRE future owned workload."""
    path = Path(path).resolve()
    if not path.is_file():
        raise FileNotFoundError("initialize the fixed ledger explicitly before leasing")
    with path.open("a+") as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        rows = read_rows(stream)
        current = state(rows, path)
        if current["pending"]:
            raise ValueError("unfinished attempt blocks launch; preserve journal and process proof")
        yield stream, rows, current


def initialize(path, metadata):
    path = Path(path).resolve()
    if path.exists():
        raise FileExistsError("campaign ledger exists; never reset")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x+") as stream:
        fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return append(stream, [], path, "initialized", dict(schema=SCHEMA, ledger_path=str(path), metadata=metadata))
