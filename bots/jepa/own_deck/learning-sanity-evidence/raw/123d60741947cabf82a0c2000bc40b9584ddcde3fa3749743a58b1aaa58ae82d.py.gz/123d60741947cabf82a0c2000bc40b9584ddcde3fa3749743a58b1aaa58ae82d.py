"""Synthetic arrays only. No experiment artifacts, NN, or native execution."""
import copy
import importlib.util
from pathlib import Path
import unittest

import numpy as np

spec=importlib.util.spec_from_file_location("independent_sanity_verifier",Path(__file__).with_name("learning_sanity_verify.py"))
V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)


class VerificationTests(unittest.TestCase):
    def test_masked_root_balanced_metrics_and_native_deadband(self):
        y=np.array([[0.,-1.],[1.,77.]])
        p=np.array([[1.,2.],[3.,-999.]])
        m=np.array([[1,1],[1,0]])
        r=V.metrics(p,y,m,2.)
        self.assertEqual(r['mae'],2.);self.assertAlmostEqual(r['rmse'],np.sqrt(4.5))
        self.assertEqual((r['max_error'],r['normalized_mae']),(3.,1.))
        self.assertEqual(r['known_coordinates'],3)
        z=V.metrics(np.array([.25,-.25,.25001,-.25001]),np.zeros(4),np.ones(4),1.)
        self.assertEqual(z['zero_sign_accuracy'],.5)
        self.assertIsNone(V.metrics(np.zeros(2),np.ones(2),np.zeros(2),1.)['mae'])

    def test_packet_shuffle_joint_permutation_masks_and_value_ties(self):
        y=np.zeros((4,8,7),np.float32);y[2:,:,2:7]=2
        arrays=dict(targets=y,target_mask=np.ones_like(y),source_targets=np.arange(36).reshape(4,9),source_mask=np.ones((4,9)),selected_candidate_indices=np.zeros(4,np.int64))
        plan=dict(shuffle_roots=list(range(4)),effect_columns=list(range(2,7)))
        mapped,report=V.assigned(arrays,plan,np.array([1,0,3,2],np.int64))
        self.assertEqual(report['changed_vectors'],0)
        np.testing.assert_array_equal(mapped['target_mask'],arrays['target_mask'])
        np.testing.assert_array_equal(mapped['source_targets'],arrays['source_targets'])
        with self.assertRaisesRegex(ValueError,'derangement'):V.assigned(arrays,plan,np.arange(4,dtype=np.int64))
        arrays['target_mask'][0,0,2]=0
        with self.assertRaisesRegex(ValueError,'known'):V.assigned(arrays,plan,np.array([1,0,3,2],np.int64))

    def test_seeded_schedules_and_no_extra_journal_exposure(self):
        fixed,fresh=V.seeded_mappings(14,2)
        self.assertTrue(np.all(fixed!=np.arange(14)));self.assertEqual(fresh.shape,(2,14))
        rows=[];f=u=0
        for arm in V.ARMS:
            f+=1;rows.append(dict(event='forward-intent',kind='evaluate',arm=arm,step=0,global_forward=f))
            for s in (1,2):
                f+=1;u+=1;rows.extend([dict(event='forward-intent',kind='train',arm=arm,step=s,global_forward=f),dict(event='optimizer-update',arm=arm,arm_update=s,global_update=u,loss=1.,preclip_gradient_norm=.1)])
            f+=1;rows.append(dict(event='forward-intent',kind='evaluate',arm=arm,step=2,global_forward=f))
        self.assertEqual(V.audit_journal(rows,2)['total_forwards'],12)
        with self.assertRaisesRegex(ValueError,'extra'):V.audit_journal(rows+[rows[-1]],2)
        broken=copy.deepcopy(rows);broken[2]['global_update']=8
        with self.assertRaisesRegex(ValueError,'counter'):V.audit_journal(broken,2)

    def test_gate_zero_initial_amendment_and_all_heads(self):
        before={'a':dict(normalized_mae=1.),'zero':dict(normalized_mae=0.)}
        after={'a':dict(normalized_mae=.04,zero_sign_accuracy=1.),'zero':dict(normalized_mae=.04,zero_sign_accuracy=1.)}
        r=V.gate(before,after);self.assertTrue(r['passed']);self.assertIsNone(r['per_head']['zero']['relative_error_ratio'])
        after['a']['zero_sign_accuracy']=.94
        self.assertFalse(V.gate(before,after)['passed'])

    def test_ridge_normal_equation_weights_intercept_and_saved_predictions(self):
        x=np.zeros((6,59));x[:,0]=np.arange(6)-2
        y=np.array([-2.,-1.,0.,1.,2.,3.]);m=np.ones(6);train=np.arange(6)
        spec=dict(binary=False,center=.5,scale=2.,class_weights={'-1':2.,'0':3.,'1':1.})
        design=np.column_stack((np.ones(6),x));w=np.where(y<0,2.,np.where(y>0,1.,3.));penalty=np.eye(60);penalty[0,0]=0
        beta=np.linalg.solve(design.T@(w[:,None]*design)+penalty,design.T@(w*((y-.5)/2)))
        r=V.ridge_residual(x,y,m,spec,train,beta)
        self.assertLess(r['relative_normal_equation_residual'],1e-12)
        np.testing.assert_array_equal(r['weights'],w)
        wrong=beta.copy();wrong[0]+=.2
        self.assertGreater(V.ridge_residual(x,y,m,spec,train,wrong)['relative_normal_equation_residual'],1e-4)
        # Known-candidate averaging is per root, not a neural-head coefficient.
        xx=np.broadcast_to(x[:,None,:],(6,2,59));yy=np.column_stack((y,y));mm=np.ones((6,2));mm[0,1]=0
        r=V.ridge_residual(xx,yy,mm,spec,train,beta)
        self.assertEqual(r['weights'][0],2.);self.assertEqual(r['weights'][1],1.)

    def test_ridge_features_fit_train_stats_and_held_identity_zero(self):
        arrays=dict(source_cards=np.array(['a','b','held']),state_families=np.array([0,0,3]),context_features=np.arange(54).reshape(3,18).astype(float),candidate_features=np.arange(816).reshape(3,8,34).astype(float),selected_candidate_indices=np.array([0,1,2]))
        plan=dict(train_codes=['a','b','c','d','e','f','g'],split=dict(train_state_families=[0]))
        source,t=V.ridge_design(arrays,plan,'source')
        np.testing.assert_allclose(source[:2,:52].mean(0),0,atol=1e-12)
        self.assertFalse(source[2,52:].any());self.assertEqual(t['observations'],2)
        arrays['context_features'][2]+=99999
        _,same=V.ridge_design(arrays,plan,'source')
        np.testing.assert_array_equal(same['center'],t['center'])


if __name__=='__main__':unittest.main()
