from pathlib import Path
from collections import Counter,defaultdict
import datetime,hashlib,json,sys
import numpy as np
repo=Path('/Users/ericfode/Documents/Codex/2026-10-17/task-7/holocron-deck-context');task=repo.parent;root=task/'experiments';own=repo/'bots/jepa/own_deck';folder=root/'learning-sanity-v1'
sys.path.insert(0,str(own));import effect_identifiability_fit as F
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());digest=lambda v:hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
paths=dict(plan=root/'native-effect-v2/native-plan.json',receipt=root/'native-effect-v2/native-attempt-1/native-receipt.json',journal=root/'native-effect-v2/native-attempt-1/native-transitions.jsonl',dataset=root/'native-effect-v2/native-effect-v2.npz',manifest=root/'native-effect-v2/native-effect-v2.manifest.json',learner_plan=root/'effect-identifiability-v2/learner-plan.json',fit_contract=root/'effect-identifiability-v2/fit-1/contract.json',cohort=root/'actual-corpus/effect-cohort-audit-v1/strict12-contract-v3.json',prior_audit=root/'effect-identifiability-v2/independent-data-verification.json',catalog=Path('/Users/ericfode/Documents/Codex/2026-10-17/task-5/kessel-pilot-source/compiler/generated/cards.json'))
plan,receipt,manifest,lp,contract,cohort,prior,catalog=(read(paths[k])for k in('plan','receipt','manifest','learner_plan','fit_contract','cohort','prior_audit','catalog'))
with np.load(paths['dataset'],allow_pickle=False)as z:a={k:z[k]for k in z.files}
issues=[];checks=Counter();records=[];supports=defaultdict(lambda:defaultdict(set));anchors=Counter();modes=Counter();stage_counts=Counter();privacy_count=0
need=lambda ok,message:issues.append(message)if not ok else None
offers=lambda capture,instance:[v for v in capture['offeredActions']if v.get('kind')=='card'and v.get('card')==instance]
ready=lambda capture:sum(not v['exhausted']for v in capture['state']['players']['p1']['resources'])
caseby={(c['card'],c['state_family']):c for c in receipt['cases']};ordered=[caseby[str(c),int(s)]for c,s in zip(a['source_cards'],a['state_families'])]
need(ordered==manifest['records'],'manifest/data ordered roots differ');need(receipt['collectionPlan']==plan,'embedded plan differs');need(receipt['collectionPlanSha256']==sha(paths['plan']),'embedded plan hash differs')
journal=[json.loads(line)for line in paths['journal'].read_text().splitlines()if line.strip()];intents={r['applyCall']:r for r in journal if r.get('phase')=='beforeApply'};ends={r['applyCall']:r for r in journal if r.get('phase')in('afterApply','applyError')};complete={r['context']:r['case']for r in journal if r.get('phase')=='contextComplete'}
need(sorted(intents)==list(range(1,88))and len(ends)==87,'87 sequential durable intent/outcome pairs required')
for i,c in enumerate(ordered):
 code,state=c['card'],c['state_family'];key=f'{code}-family-{state}';j=int(a['selected_candidate_indices'][i]);chosen=plan['candidate_order'][j];spec=plan['query_specs'][code][state];b=c['before'];f=c['final'];mode=c['observation_mode'];modes[mode]+=1;sid=c['refs']['source'];tid=c['refs'][chosen]
 need(chosen==c['chosen_ref']==spec['ref']and mode==spec['mode'],f'{key}: selected index/role/mode mismatch')
 need((b['projections']['source']['code'],b['projections']['source']['owner'],b['projections']['source']['zone'])==(code,'p1','hand'),f'{key}: source hand identity mismatch')
 need(c['playAction']in offers(b,sid),f'{key}: initial play not actual offered source action')
 need(complete.get(key)==c,f'{key}: raw completion differs from journal')
 previous=b;actual_commits=[];captures=[b]
 calls=[n for n,r in intents.items()if r['context']==key]
 need(len(calls)==c['applyCalls']==len(c['steps']),f'{key}: root call/step counts differ')
 for n,step in zip(calls,c['steps']):
  stage_counts[step['stage']]+=1;checks['offered_action_membership']+=1
  need(step['before']==previous and step['action']in previous['offeredActions'],f'{key}: unoffered or disconnected step')
  need((intents[n]['before'],intents[n]['offeredAction'],intents[n]['branch'],ends[n].get('after'))==(step['before'],step['action'],step['stage'],step['after']),f'{key}: step differs from durable intent/outcome')
  if step['stage']in('chosen-target','attach-intended-host'):
   actual_commits.append(step);need(step['action']in offers(previous,tid)and previous==c['targetPrompt']and step['action']==c['targetAction'],f'{key}: wrong selected target action')
  previous=step['after'];captures.append(previous)
 need(f==previous and f['settled']and c['completion']=='settled'and c['engineError']is None,f'{key}: endpoint not settled')
 for capture in captures:
  privacy_count+=1
  need(all(not capture['state']['players'][seat]['deck']for seat in('p1','p2'))and not capture['state']['players']['p2']['hand'],f'{key}: private hand/deck found')
 # Targets are observed at actual post-entry target/attachment prompt; inputs are before-play only.
 p=c['targetPrompt']
 if p is not None:
  need(np.array_equal(a['target_mask'][i,:,0],np.ones(8,np.float32)),f'{key}: prompt membership known mask differs')
  for k,slot in enumerate(plan['candidate_order']):need(a['targets'][i,k,0]==bool(offers(p,c['refs'][slot])),f'{key}: membership does not equal actual native prompt')
 else:need(not a['target_mask'][i,:,0].any(),f'{key}: fabricated target membership without prompt')
 need(not a['target_mask'][i,np.arange(8)!=j,1:].any(),f'{key}: unchosen future mask')
 z=f['projections']['source'];attached=[(host['id'],u['id'])for seat in('p1','p2')for zone in('ground','space')for host in f['state']['players'][seat][zone]for u in host.get('upgrades',[])]
 committed=z['zone']!='hand'and(z['in_arena']or z['zone']=='discard'or(z['zone']=='upgrade'and any(u==sid for h,u in attached)));cost=ready(b)-ready(f);paid=committed and cost>0
 need(bool(a['source_targets'][i,1])==committed and a['source_targets'][i,2]==cost,f'{key}: source commit/cost mismatch')
 observed=paid and (bool(actual_commits)if mode in('chosen-target','upgrade-attachment')else True)
 if mode=='upgrade-attachment':need((tid,sid)in attached,f'{key}: actual source upgrade on wrong parent')
 if mode=='passive-area-anchor':need(code=='SEC_051'and not actual_commits and p is None,f'{key}: area anchor gained fictional selection')
 old=b['projections'][chosen];new=f['projections'][chosen];removed=not new['present']or new['zone']in('discard','absent');same=mode!='self-entry'and not removed and old['present']and new['present']and old['zone']==new['zone']
 need(bool(a['target_mask'][i,j,1])==bool(observed),f'{key}: removal observation mask mismatch')
 if observed:need(bool(a['targets'][i,j,1])==removed,f'{key}: removal value mismatch')
 for h,field in enumerate(('damage','exhausted','shield_count','power','hp'),2):
  known=bool(observed and same and old['known'][field]and new['known'][field]);need(bool(a['target_mask'][i,j,h])==known,f'{key}: {field} mask mismatch')
  if known:
   val=float(new[field])-float(old[field]);need(a['targets'][i,j,h]==val,f'{key}: {field} direct native delta mismatch')
   if str(a['partition'][i])=='train':supports[manifest['target_names'][h]]['zero'if val==0 else'nonzero'].add(code)
 # Independent public feature rebuild from projections and printed metadata.
 rows=plan['selected_whole_rows'];aspects=Counter()
 for role in('base','leader'):
  pr=b['state']['players']['p1'][role];pc=pr.get('setCode')or pr.get('code')or b['own_aspect_sources'][role];aspects.update(rows[pc]['card']['aspects'])
 source=b['projections']['source'];x=[ready(b),float(source['zone']=='hand'),*[aspects[v]for v in('vigilance','command','aggression','cunning','heroism','villainy')],b['other_friendly_space_count'],b['other_friendly_fighter_count'],*[float(source[v])for v in('power','hp','damage','exhausted')],*[float(source['known'][v])for v in('power','hp','damage','exhausted')]]
 need(np.array_equal(np.asarray(x,np.float32),a['context_features'][i]),f'{key}: context rebuilt before-only differs')
 for k,slot in enumerate(plan['candidate_order']):
  v=b['projections'][slot];known=v['known'];num={name:float(v[name])if known[name]else 0. for name in('damage','hp','power','exhausted','shield_count','xp_count')};traits=set(rows[v['code']]['card']['traits']);card=rows[v['code']]['card'];rem=bool(known['hp']and known['damage']);cost0=card.get('cost');kc=type(cost0)in(int,float);unique=card.get('unique');ku=type(unique)is bool
  cv=[v['owner']=='p1',v['owner']=='p2',v['is_unit'],v['is_base'],v['zone']=='ground',v['zone']=='space',v['id']==sid,v['present'],num['damage'],num['hp'],num['hp']-num['damage']if rem else 0.,num['power'],num['exhausted'],num['shield_count'],num['xp_count'],known['damage'],known['hp'],rem,known['power'],known['exhausted'],known['shield_count'],known['xp_count'],*[t in traits for t in('imperial','creature','spectre')],True,cost0 if kc else 0.,kc,unique if ku else False,ku,'upgrade'in card['types'],'leader'in card['types'],'vehicle'in traits,'fighter'in traits]
  need(np.array_equal(np.asarray(cv,np.float32),a['candidate_features'][i,k]),f'{key}: candidate {slot} rebuilt before-only differs')
 anchors[mode+':observed-future'if observed else mode+':unknown-future']+=1
 records.append(dict(card=code,state=state,partition=str(a['partition'][i]),mode=mode,intended_ref=chosen,selected_index=j,actual_target_commits=len(actual_commits),paid=bool(paid),source_cost=float(cost),settled=True,known_primary_delta_heads=int(a['target_mask'][i,j,2:].sum())))
# All provenance rows/source docs, learner bank order and fitted saved contract must agree.
cat={r['setCode']:r for r in catalog['cards']};cc={c['code']:c for c in cohort['cards']};docs=[]
for k,code in enumerate(lp['codes']):
 row=manifest['cards'][code]['raw_card'];need(row==cat[code]==plan['selected_whole_rows'][code],code+': full card row differs')
 doc,cleanup=F.canonical_document(row);need(doc==lp['documents'][k]==cc[code]['normalized_document'],code+': canonical learner document differs');need(digest(doc)==lp['document_sha256'][k]==contract['documents_sha256'][k],code+': saved document digest/order differs');docs.append(dict(code=code,bank_index=k,canonical_id=row['card']['id'],source_hash=row['sourceHash'],raw_row_sha256=digest(row),document_sha256=digest(doc),display_cleanup_paths=len(cleanup['display_paths']),callback_occurrences=len(cleanup['callback_occurrences'])))
need(contract['plan']['sha256']==sha(paths['learner_plan']),'fit contract plan pin differs')
need(sha(paths['prior_audit']).startswith('5410975ad9'),'previous independent audit pin changed')
for key,v in prior['sources'].items():
 if key in paths:need(sha(paths[key])==v['sha256'],'prior audit input pin changed '+key)
need('torch'not in sys.modules,'unexpected Torch import in pure audit')
# Sparse exactly changes the declared five TRAIN masks and no feature or label value.
expected_sparse=a['target_mask'].copy();expected_sparse[a['train_idx'],:,2:7]=0
need(np.array_equal(expected_sparse,a['sparse_target_mask'])and np.array_equal(a['source_mask'],a['sparse_source_mask']),'sparse observation operator differs')
summary=dict(schema='learning-sanity-native-pairing-audit/1',checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='passed'if not issues else'issues',issues=issues,sources={k:dict(path=str(p),sha256=sha(p))for k,p in paths.items()},roots=48,journal_native_calls=len(intents),native_calls_executed_by_audit=0,neural_forwards=0,backwards=0,optimizer_updates=0,torch_imported='torch'in sys.modules,offered_action_memberships_checked=checks['offered_action_membership'],before_only_context_rebuilds=48,before_only_candidate_rebuilds=384,private_capture_checks=privacy_count,observation_modes=dict(modes),future_observation_roles=dict(anchors),stage_counts=dict(stage_counts),per_training_head_source_support={h:{sign:sorted(codes)for sign,codes in values.items()}for h,values in supports.items()},document_alignment=docs,records=records,source_mapping='Dataset row source_cards/state_families -> exact native manifest root; query index is learner_plan.codes.index(source_card), source input includes intended candidate, branch input only its own candidate. Saved fit contract document order matched.',limitations=['All48 source plays are available/paid; availability/hand-after/source-damage are constant diagnostics, not meaningful unseen legal-action qualification.','One source-specific query per state and only21TRAINroots support memorization; no independent candidate intervention set.','Two positive training exhaust outcomes are the same JTL217 template; negative training stat consequences are only SEC051 on one enemy anchor.','SEC051 target power delta is -1 because printed/current power1 floors at0, while HPdelta is -3; held target-stat effects -2/-5 are not interpolated from multiple TRAINdebuff templates.','SEC051 event-hook XP and SEC142 onAttack retained in full documents but never exercised; all actions are own-hand plays.','No legal-action/mask-anchor/data-document mismatch was found in saved observed48roots; this cannot establish all-state engine conformance or prove optimization/generalization quality.'])
out=folder/'native-pairing-audit.json'
if out.exists():raise ValueError('preserve existing audit')
out.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(path=str(out),sha256=sha(out),status=summary['status'],issues=issues,counts=dict(roots=48,calls=len(intents),captures=privacy_count),support=summary['per_training_head_source_support'])))
