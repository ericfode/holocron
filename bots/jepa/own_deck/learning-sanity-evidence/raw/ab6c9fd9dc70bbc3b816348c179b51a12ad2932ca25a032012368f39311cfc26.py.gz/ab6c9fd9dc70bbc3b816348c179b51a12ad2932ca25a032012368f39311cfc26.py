"""Independent saved-output verification. NumPy/stdlib only; no NN/native/refits.

Actual artifact verification is an explicit coordinator action after stage GO.
Pure unit tests use synthetic arrays exclusively. Existing output is preserved.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

import os
for _key in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","VECLIB_MAXIMUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[_key]="1"
import numpy as np

ARMS = ("correct", "fixed-shuffle", "fresh-shuffle")
DEADBAND = .25


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(value): return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
def load(path):
    with np.load(path, allow_pickle=False) as p: return {k:p[k].copy() for k in p.files}
def pin(path):
    p = Path(path).resolve(); return dict(path=str(p), sha256=sha(p), bytes=p.stat().st_size)
def close(a, b, message, atol=2e-7):
    require(np.allclose(a, b, atol=atol, rtol=2e-6, equal_nan=False), message)


def partitions(arrays, plan):
    card = np.isin(arrays["source_cards"], plan["train_codes"])
    state = np.isin(arrays["state_families"], plan["split"]["train_state_families"])
    return dict(train=np.flatnonzero(card & state), family_held=np.flatnonzero(~card & state),
                state_held=np.flatnonzero(card & ~state), joint=np.flatnonzero(~card & ~state))


def metrics(prediction, target, mask, scale, binary=False):
    p, y, m = np.asarray(prediction, np.float64), np.asarray(target, np.float64), np.asarray(mask) > 0
    require(p.shape == y.shape == m.shape and np.isfinite(p).all() and np.isfinite(y).all(), "metric shape/finite")
    require(scale > 0 and np.isfinite(scale), "metric scale")
    count = m.astype(int) if m.ndim == 1 else m.sum(-1)
    valid = count > 0
    if not valid.any(): return dict(known_coordinates=0, observed_roots=0, mae=None, normalized_mae=None, rmse=None, normalized_rmse=None, max_error=None, normalized_max_error=None, zero_sign_accuracy=None)
    def rootmean(v): return v if m.ndim == 1 else (v*m).sum(-1)/np.maximum(count, 1)
    residual = p-y; observed = y[m]
    sign = np.where(p > DEADBAND, 1, np.where(p < -DEADBAND, -1, 0)); correct = sign == np.sign(y)
    recalls = {str(s):float(correct[(np.sign(y)==s)&m].mean()) if ((np.sign(y)==s)&m).any() else None for s in (-1,0,1)}
    mae = float(rootmean(abs(residual))[valid].mean()); rmse = float(np.sqrt(rootmean(residual**2)[valid].mean())); maximum = float(abs(residual)[m].max())
    return dict(known_coordinates=int(m.sum()), observed_roots=int(valid.sum()), mae=mae, normalized_mae=mae/scale,
                rmse=rmse, normalized_rmse=rmse/scale, max_error=maximum, normalized_max_error=maximum/scale,
                signed_residual=float(rootmean(residual)[valid].mean()), zero_sign_accuracy=float(rootmean(correct.astype(float))[valid].mean()),
                zero_sign_coordinate_accuracy=float(correct[m].mean()), zero_accuracy=recalls["0"], sign_recall=recalls,
                nonzero_sign_accuracy=float(correct[(y!=0)&m].mean()) if ((y!=0)&m).any() else None,
                zero_threshold_native=DEADBAND, positive=int((observed>0).sum()), negative=int((observed<0).sum()), zero=int((observed==0).sum()),
                native_mean=float(observed.mean()), native_variance=float(observed.var()), native_values=np.unique(observed).tolist(),
                binary_accuracy=float(rootmean(((p>=.5)==y).astype(float))[valid].mean()) if binary else None, binary_threshold=.5 if binary else None)


def score(source, branch, arrays, plan, cells=None):
    cells = partitions(arrays, plan) if cells is None else cells
    return {cell:{spec["name"]:metrics(pred[ix,...,h], arrays[key][ix,...,h], arrays[mk][ix,...,h], spec["scale"],spec["binary"])
                 for pred,key,mk,specs in ((source,"source_targets","source_mask",plan["scalers"]["source_targets"]),(branch,"targets","target_mask",plan["scalers"]["targets"]))
                 for h,spec in enumerate(specs)} for cell,ix in cells.items()}


def assigned(arrays, plan, mapping):
    roots = np.asarray(plan["shuffle_roots"], np.int64); cols = np.asarray(plan["effect_columns"], np.int64); mapping = np.asarray(mapping)
    require(mapping.dtype == np.int64 and mapping.shape == roots.shape and sorted(mapping.tolist()) == list(range(len(roots))) and np.all(mapping != np.arange(len(roots))), "packet derangement")
    selected = arrays["selected_candidate_indices"][roots]
    require(arrays["target_mask"][roots[:,None],selected[:,None],cols].all(), "all packet coordinates known")
    result = dict(arrays); result["targets"] = arrays["targets"].copy()
    packets = arrays["targets"][roots[:,None],selected[:,None],cols].copy()
    result["targets"][roots[:,None],selected[:,None],cols] = packets[mapping]
    for key in arrays:
        if key != "targets": require(np.array_equal(result[key], arrays[key]), "shuffle altered inputs/masks")
    outside = np.ones(arrays["targets"].shape, bool); outside[roots[:,None],selected[:,None],cols] = False
    require(np.array_equal(result["targets"][outside],arrays["targets"][outside]), "shuffle altered nonpacket labels")
    require(sorted(map(tuple, packets.tolist())) == sorted(map(tuple, packets[mapping].tolist())), "joint packet multiset")
    changed = packets[mapping] != packets
    return result, dict(root_index_derangement=True, changed_vectors=int(changed.any(-1).sum()), vector_fraction=float(changed.any(-1).mean()),
                        changed_coordinates=int(changed.sum()), coordinate_fraction=float(changed.mean()), per_head_changed_fraction=changed.mean(0).tolist(), joint_multiset_preserved=True)


def seeded_mappings(n, steps=300):
    def draw(rng):
        while True:
            p = rng.permutation(n).astype(np.int64)
            if np.all(p != np.arange(n)): return p
    fixed = draw(np.random.default_rng(1017)); rng = np.random.default_rng(2017)
    return fixed, np.asarray([draw(rng) for _ in range(steps)], np.int64)


def packet_metrics(branch, arrays, plan):
    roots=np.asarray(plan["shuffle_roots"],np.int64); sel=arrays["selected_candidate_indices"][roots]
    return {plan["scalers"]["targets"][h]["name"]:metrics(branch[roots,sel,h],arrays["targets"][roots,sel,h],arrays["target_mask"][roots,sel,h],plan["scalers"]["targets"][h]["scale"]) for h in plan["effect_columns"]}


def gate(initial, final):
    heads = {n:dict(absolute_pass=v["normalized_mae"] <= .05,
                   relative_pass=initial[n]["normalized_mae"] == 0 or v["normalized_mae"] <= .05*initial[n]["normalized_mae"],
                   sign_pass=v["zero_sign_accuracy"] >= .95) for n,v in final.items()}
    for h in heads.values(): h["passed"] = all(h.values())
    for n,h in heads.items(): h["relative_error_ratio"] = final[n]["normalized_mae"]/initial[n]["normalized_mae"] if initial[n]["normalized_mae"] else None
    return dict(passed=all(h["passed"] for h in heads.values()), per_head=heads, semantic_validated=False)


def audit_scalers(arrays, plan):
    train=partitions(arrays,plan)["train"]; result={}; varying=constant=0
    for key in ("context_features","candidate_features"):
        value=arrays[key][train]; axes=tuple(range(value.ndim-1))
        close(plan["scalers"][key]["center"],value.mean(axes),"TRAIN input center")
        close(plan["scalers"][key]["scale"],np.maximum(1,value.std(axes)),"TRAIN input scale")
    for key,mk in (("source_targets","source_mask"),("targets","target_mask")):
        result[key]=[]
        for h,spec in enumerate(plan["scalers"][key]):
            y,m=arrays[key][train,...,h],arrays[mk][train,...,h]>0; v=y[m].astype(np.float64)
            binary=spec["binary"]; center=0. if binary or not len(v) else float(v.mean()); scale=1. if binary or not len(v) else max(1.,float(v.std()))
            close(spec["center"],center,"TRAIN target center"); close(spec["scale"],scale,"TRAIN target scale")
            counts={str(s):int((np.sign(v)==s).sum()) for s in (-1,0,1)}; classes=sum(n>0 for n in counts.values())
            weights={s:len(v)/(classes*n) if n else 0. for s,n in counts.items()}
            for s in weights: close(spec["class_weights"][s],weights[s],"TRAIN class weight")
            isvarying=len(np.unique(v))>1; varying+=isvarying; constant+=bool(len(v) and not isvarying)
            require(spec["known"]==len(v) and spec["varying"]==isvarying,"TRAIN support")
            result[key].append(dict(name=spec["name"],known=len(v),mean=float(v.mean()) if len(v) else None,variance=float(v.var()) if len(v) else None,counts=counts,class_weights=weights))
    for key in ("source_targets","targets"):
        for spec in plan["scalers"][key]:
            coefficient=1./varying if spec["varying"] else .1/constant if spec["known"] and constant else 0.
            close(spec["loss_coefficient"],coefficient,"fixed head coefficient")
    return result


def audit_journal(rows, steps=300):
    forward=update=0; cursor=0
    def take(expected):
        nonlocal cursor
        require(cursor<len(rows),"truncated progress journal")
        row=rows[cursor]; cursor+=1
        require(all(row.get(k)==v for k,v in expected.items()),"journal order/counter/arm differs")
        if row["event"]=="optimizer-update": require(np.isfinite(row["loss"]) and np.isfinite(row["preclip_gradient_norm"]) and row["preclip_gradient_norm"]>=0,"journal nonfinite objective/gradient")
    for arm in ARMS:
        forward+=1; take(dict(event="forward-intent",kind="evaluate",arm=arm,step=0,global_forward=forward))
        for step in range(1,steps+1):
            forward+=1; take(dict(event="forward-intent",kind="train",arm=arm,step=step,global_forward=forward))
            update+=1; take(dict(event="optimizer-update",arm=arm,arm_update=step,global_update=update))
        forward+=1; take(dict(event="forward-intent",kind="evaluate",arm=arm,step=steps,global_forward=forward))
    require(cursor==len(rows),"extra progress exposure")
    return dict(optimizer_updates=update,training_forwards=update,evaluation_forwards=6,total_forwards=forward)


def audit_ledger(rows, plan_path, plan):
    require(len(rows)==3,"one initialized/start/finish attempt only")
    previous="0"*64
    for i,row in enumerate(rows):
        body={k:v for k,v in row.items() if k!="record_sha256"}
        require(row["sequence"]==i and row["previous_sha256"]==previous and digest(body)==row["record_sha256"],"ledger hash chain")
        previous=row["record_sha256"]
    require([r["event"]for r in rows]==["initialized","attempt-start","attempt-finish"],"ledger events")
    require(rows[0]["data"]["config"]==plan["config"],"ledger config")
    require(rows[1]["data"]["reservation"]==dict(seconds=30.,optimizer_updates=900,training_forwards=900,evaluation_forwards=6,export_forwards=0,native_applies=0),"fixed allocation")
    require(rows[0]["data"]["plan"]==pin(plan_path) and rows[0]["data"]["parent_final_record"]==plan["parent_final_record"],"ledger allocation pin")
    final=rows[-1]["data"]
    require(final["counts"]==dict(optimizer_updates=900,training_forwards=900,evaluation_forwards=6,export_forwards=0,backwards=900),"ledger all counters")
    require(final["status"]=="completed" and 0<=final["active_seconds"]<=30,"ledger incomplete/time")
    for key,value in (("charged_optimizer_updates",900),("charged_training_forwards",900),("charged_evaluation_forwards",6)): require(final[key]==value,"fixed exposure charge")
    return dict(last_record=previous,active_seconds=final["active_seconds"],attempts=1)


def ridge_design(arrays, plan, kind):
    n=len(arrays["source_cards"]); ids=np.zeros((n,len(plan["train_codes"])),np.float64)
    for i,code in enumerate(arrays["source_cards"]):
        if str(code) in plan["train_codes"]: ids[i,plan["train_codes"].index(str(code))]=1
    if kind=="source": raw=np.concatenate((arrays["context_features"],arrays["candidate_features"][np.arange(n),arrays["selected_candidate_indices"]],ids),-1)
    else: raw=np.concatenate((np.broadcast_to(arrays["context_features"][:,None,:],(n,8,18)),arrays["candidate_features"],np.broadcast_to(ids[:,None,:],(n,8,7))),-1)
    raw=raw.astype(np.float64); train=partitions(arrays,plan)["train"]; fitting=raw[train].reshape(-1,59)
    center=np.zeros(59); scale=np.ones(59); center[:52]=fitting[:,:52].mean(0); std=fitting[:,:52].std(0); scale[:52]=np.where(std>0,np.maximum(std,1e-8),1.)
    return (raw-center)/scale,dict(center=center,scale=scale,observations=len(fitting))


def ridge_residual(x, y, mask, spec, train, beta, ridge_lambda=1.):
    x=np.asarray(x,np.float64); y=np.asarray(y,np.float64); m=np.asarray(mask)>0; trainmask=np.zeros(m.shape,bool);trainmask[train]=m[train]
    count=m.astype(int) if m.ndim==1 else m.sum(-1)
    denominator=np.maximum(count,1) if m.ndim==1 else np.maximum(count[:,None],1)
    classes=spec["class_weights"]; w=np.where(y<0,classes["-1"],np.where(y>0,classes["1"],classes["0"]))*m/denominator
    design=np.concatenate((np.ones((int(trainmask.sum()),1)),x[trainmask]),1)
    target=y[trainmask] if spec["binary"] else (y[trainmask]-spec["center"])/spec["scale"]
    weights=w[trainmask]; beta=np.asarray(beta,np.float64)
    require(beta.shape==(60,) and np.isfinite(beta).all(),"ridge coefficient ABI")
    penalty=np.eye(60)*ridge_lambda;penalty[0,0]=0
    lhs=design.T@(weights[:,None]*design)+penalty; rhs=design.T@(weights*target)
    residual=lhs@beta-rhs; relative=float(np.linalg.norm(residual)/max(1.,np.linalg.norm(rhs),np.linalg.norm(lhs)*np.linalg.norm(beta)))
    raw=x@beta[1:]+beta[0]; native=raw if spec["binary"] else raw*spec["scale"]+spec["center"]
    return dict(relative_normal_equation_residual=relative,weights=weights,targets_native=y[trainmask],targets_normalized=target,
                objective=float(((design@beta-target)**2*weights).sum()+ridge_lambda*(beta[1:]**2).sum()),raw_native=native,scored=np.clip(native,0,1) if spec["binary"] else native)


def verify_ridge(directory, arrays, plan, fixed):
    result=read(directory/"result.json"); require(result["semantic_validated"] is False,"ridge semantic claim")
    require(result["status"]=="completed-data-analysis" and result["config"]["ridge_lambda"]==1. and result["config"]["intercept_penalized"] is False and result["config"]["search"] is False,"fixed ridge configuration")
    for item in (result["source"],result["plan"],result["design"]): require(pin(item["path"])==item,"ridge output/input pins")
    data_plan=read(result["plan"]["path"])
    for item in data_plan["pins"]: require(pin(item["path"])==item,"ridge protected pins")
    saved_design=load(directory/"design.npz")
    designs={k:ridge_design(arrays,plan,k)for k in ("source","target")}; summary={}
    for kind,(_,transform) in designs.items():
        for key in ("center","scale"): close(result["transforms"][kind][key],transform[key],"ridge TRAIN feature transform",atol=1e-11)
        require(result["transforms"][kind]["observations"]==transform["observations"],"ridge feature TRAIN rows")
        close(saved_design[kind+"_features"],designs[kind][0],"saved ridge feature design",atol=1e-11)
    for arm,data in (("correct",arrays),("fixed-shuffle",fixed)):
        saved=load(directory/(arm+"-predictions.npz")); summary[arm]={}
        for kind,key,mk,specs in (("source","source_targets","source_mask",plan["scalers"]["source_targets"]),("target","targets","target_mask",plan["scalers"]["targets"])):
            x=designs[kind][0]
            for h,spec in enumerate(specs):
                fit=result["ridge"][arm]["fit_details"][spec["name"]]
                if fit["status"]=="fitted-fixed-lambda": require(fit["ridge_lambda"]==1. and fit["intercept_penalized"] is False,"ridge per-head penalty")
                beta=fit.get("coefficients",np.zeros(60))
                r=ridge_residual(x,data[key][...,h],data[mk][...,h],spec,partitions(arrays,plan)["train"],beta)
                require(r["relative_normal_equation_residual"]<=2e-9,"ridge weighted normal equations")
                for f,k in (("weights","weights"),("train_targets_native","targets_native"),("train_targets_normalized","targets_normalized")):
                    if f in fit: close(fit[f],r[k],"ridge assigned targets/weights",atol=1e-10)
                close(saved["raw_"+kind][...,h],r["raw_native"],"ridge raw predictions",atol=1e-10); close(saved["scored_"+kind][...,h],r["scored"],"ridge scored predictions",atol=1e-10)
                if "total_objective"in fit: close(fit["total_objective"],r["objective"],"ridge objective",atol=1e-9)
                summary[arm][spec["name"]]=dict(relative_normal_equation_residual=r["relative_normal_equation_residual"],fit_status=fit["status"],observations=len(r["weights"]))
    return summary


def run(plan_path, run_dir, progress, ledger, ridge_dir, output):
    require(not output.exists(),"preserve independent receipt")
    plan=read(plan_path); arrays=load(plan["dataset"]); manifest=read(plan["manifest"]); result=read(run_dir/"result.json"); receipt=read(run_dir/"receipt.json")
    inputs=[plan_path,Path(plan["dataset"]),Path(plan["manifest"]),run_dir/"result.json",run_dir/"receipt.json",progress,ledger]
    for item in plan["pins"]: require(pin(item["path"])==item,"protected source/input pin")
    require(result["semantic_validated"] is False and result["status"]==receipt["status"]=="completed","no semantic/completion substitution")
    for obj in (result,receipt):
        require(obj["plan"]==pin(plan_path) and obj["source"]["sha256"]==plan["source_sha256"],"frozen run source/plan")
        require(pin(obj["source"]["path"])==obj["source"],"run source bytes")
    require(receipt["result"]==pin(run_dir/"result.json") and receipt["progress"]==pin(progress),"receipt result/journal pins")
    require(receipt["native_applies"]==receipt["paid_jobs"]==0 and receipt["counts"]["backwards"]==900 and receipt["counts"]["export_forwards"]==0,"no extra exposure")
    require(0<=receipt["active_seconds"]<=30 and receipt["guard"]["peak_live_rss_bytes"]<=1073741824 and receipt["guard"]["cpu_threads"]==1,"guard bounds")
    require(result["all_inputs_unchanged"] is True,"unaltered inputs witness")
    for key in ("targets","target_mask","source_targets","source_mask","selected_candidate_indices"):
        require(hashlib.sha256(arrays[key].tobytes()).hexdigest()==result["true_label_array_sha256"][key],"TRUE array content witness")
    cells=partitions(arrays,plan); require({k:len(v)for k,v in cells.items()}==dict(train=21,family_held=15,state_held=7,joint=5),"fixed split")
    require(plan["train_indices"]==cells["train"].tolist(),"all21 TRAIN order")
    require(len(plan["shuffle_roots"])==14 and set(plan["shuffle_roots"])<=set(plan["train_indices"]),"14 TRAIN packets")
    roots=np.asarray(plan["shuffle_roots"],np.int64); selected=arrays["selected_candidate_indices"][roots]; cols=np.asarray(plan["effect_columns"],np.int64)
    require(all(set(np.flatnonzero(arrays["target_mask"][cells["train"],:,h].any(-1)).tolist())==set(np.flatnonzero(np.isin(cells["train"],roots)).tolist()) for h in cols),"all five observed TRAIN root sets equal packet set")
    packets=arrays["targets"][roots[:,None],selected[:,None],cols]
    require(hashlib.sha256(packets.tobytes()).hexdigest()==plan["packet_sha256"],"original packet bytes")
    label_audit=audit_scalers(arrays,plan); fixed,change=assigned(arrays,plan,np.asarray(plan["fixed_mapping"],np.int64))
    expected_fixed,expected_fresh=seeded_mappings(14)
    require(np.array_equal(expected_fixed,plan["fixed_mapping"]) and np.array_equal(expected_fresh,plan["fresh_mappings"]),"frozen seeded packet schedules")
    for mapping in expected_fresh: assigned(arrays,plan,mapping)
    schedules=load(run_dir/"shuffle-schedules.npz")
    for key in ("train_indices","shuffle_roots","fixed_mapping","fresh_mappings"): require(np.array_equal(schedules[key],plan[key]),"saved schedule differs")
    count=audit_journal([json.loads(x)for x in progress.read_text().splitlines()]); accounting=audit_ledger([json.loads(x)for x in ledger.read_text().splitlines()],plan_path,plan)
    for key in ("optimizer_updates","training_forwards","evaluation_forwards"): require(result["counts"][key]==receipt["counts"][key]==count[key],"result/journal counters")
    initial=load(plan["initial_checkpoint"]); copied=load(run_dir/"initial-checkpoint.npz")
    require(set(initial)==set(copied) and all(np.array_equal(initial[k],copied[k])for k in initial),"saved named initialization differs")
    require(sum(a.size for a in initial.values())==11856,"fixed allocated graph")
    scores={}; packet_scores={}; movement={}
    for arm in ARMS:
        weights=load(run_dir/(arm+"-checkpoint.npz")); inputs.append(run_dir/(arm+"-checkpoint.npz"))
        require(set(weights)==set(initial),"checkpoint names")
        require(result["results"][arm]["checkpoint"]==pin(inputs[-1]),"checkpoint result pin")
        movement[arm]={}
        for name,value in weights.items():
            require(value.shape==initial[name].shape and np.isfinite(value).all(),"checkpoint shape/finite")
            delta=float(np.linalg.norm((value-initial[name]).astype(np.float64)));changed=int(np.count_nonzero(value!=initial[name]));saved=result["results"][arm]["weight_movement"][name]
            close(delta,saved["delta_l2"],"weight movement");require(changed==saved["changed"],"changed coordinate count")
            movement[arm][name]=dict(delta_l2=delta,changed=changed)
        scores[arm]={};packet_scores[arm]={}
        for step in (0,300):
            path=run_dir/f"{arm}-step{step}-predictions.npz";inputs.append(path);p=load(path)
            for key in ("source_cards","state_families","selected_candidate_indices"): require(np.array_equal(p[key],arrays[key]),"prediction root/intent pairing")
            scores[arm][str(step)]=dict(TRUE=score(p["source"],p["branch"],arrays,plan))
            packet_scores[arm][str(step)]=dict(TRUE=packet_metrics(p["branch"],arrays,plan))
            if arm=="fixed-shuffle":
                scores[arm][str(step)]["ASSIGNED_TRAIN"]=score(p["source"],p["branch"],fixed,plan,{"train":cells["train"]})
                packet_scores[arm][str(step)]["ASSIGNED"]=packet_metrics(p["branch"],fixed,plan)
            saved=result["results"][arm]["evaluations"][str(step)]
            for cell,heads in scores[arm][str(step)]["TRUE"].items():
                for name,value in heads.items():
                    old=saved["true_targets"]["cells"][cell]["heads"][name]
                    if value["mae"]is not None: close(value["mae"],old["mae"],"reported true MAE");close(value["normalized_mae"],old["train_scaled_mae"],"reported normalized MAE")
            for target_key,saved_key in (("TRUE","true_TRAIN_effects"),("ASSIGNED","assigned_TRAIN_effects")):
                if target_key in packet_scores[arm][str(step)]:
                    for name,value in packet_scores[arm][str(step)][target_key].items():
                        for key in ("mae","normalized_mae","zero_sign_accuracy"):close(value[key],saved[saved_key][name][key],"reported packet metric")
    overfit=gate(packet_scores["correct"]["0"]["TRUE"],packet_scores["correct"]["300"]["TRUE"])
    require(overfit["passed"]==result["correct_overfit_gate"]["passed"],"reported overfit gate")
    ridge=verify_ridge(ridge_dir,arrays,plan,fixed) if ridge_dir else None
    if ridge_dir: inputs.extend([ridge_dir/"result.json",ridge_dir/"design.npz",ridge_dir/"correct-predictions.npz",ridge_dir/"fixed-shuffle-predictions.npz"])
    report=dict(schema="learning-sanity-independent-verification/1",status="PASS",script=pin(__file__),inputs=[pin(p)for p in inputs],
                metrics=scores,packet_metrics=packet_scores,correct_overfit_gate=overfit,training_label_audit=label_audit,shuffle_fixed_change=change,
                schedule_and_mask_checks_passed=True,checkpoint_movement=movement,accounting=accounting,journal_counts=count,ridge_normal_equations=ridge,
                semantic_validated=False,held_interpretation="Previously consumed held data; descriptive only. No stopping, tuning, or independent validation claim.",
                audit_compute=dict(neural_forwards=0,native_applies=0,optimizer_updates=0,ridge_refits=0))
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open("x")as f:json.dump(report,f,indent=2,allow_nan=False);f.write("\n")
    return report


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument("--plan",type=Path,required=True);ap.add_argument("--run-dir",type=Path,required=True);ap.add_argument("--progress",type=Path,required=True);ap.add_argument("--ledger",type=Path,required=True);ap.add_argument("--ridge-dir",type=Path);ap.add_argument("--out",type=Path,required=True)
    a=ap.parse_args();r=run(a.plan,a.run_dir,a.progress,a.ledger,a.ridge_dir,a.out);print(json.dumps(dict(status=r["status"],path=str(a.out),sha256=sha(a.out))))


if __name__=="__main__":main()
