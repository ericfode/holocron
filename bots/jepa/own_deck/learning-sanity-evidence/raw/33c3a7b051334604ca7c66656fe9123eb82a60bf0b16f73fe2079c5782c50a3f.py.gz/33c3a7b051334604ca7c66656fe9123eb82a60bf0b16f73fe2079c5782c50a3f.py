"""One-shot in-process saved-data analyses. Preview by default; never spawn."""
import argparse,fcntl,gzip,hashlib,importlib.util,json,os,runpy,signal,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
E_PATH=HERE.parents[1]/'holocron-deck-context/bots/jepa/own_deck/effect_identifiability_fit.py'
E_SHA='90ef1c0c6e2a2626f0d54c1f031fea77a25ea80b9e6e351882cb7ddd38cbd765'
LIMITS={'data':10.,'verification':5.}
BLOCKED={'torch','tinygrad','tensorflow','jax','jaxlib','keras','transformers','cupy'}
def encoded(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(x):return hashlib.sha256(encoded(x)).hexdigest()
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p.resolve()),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def rows(p):return [json.loads(x)for x in Path(p).read_text().splitlines()if x.strip()]
def chain(records):
    last='0'*64
    for i,r in enumerate(records):
        body={k:v for k,v in r.items()if k!='record_sha256'}
        if r['sequence']!=i or r['previous_sha256']!=last or digest(body)!=r['record_sha256']:raise ValueError('damaged hash chain')
        last=r['record_sha256']
    return last
def append(p,event,data):
    records=rows(p)if p.exists()else[];body=dict(sequence=len(records),previous_sha256=chain(records),event=event,data=data)
    with p.open('a')as f:f.write(encoded(dict(body,record_sha256=digest(body))).decode()+'\n');f.flush();os.fsync(f.fileno())
def validate(desc):
    if desc['stage']not in LIMITS or desc['seconds']!=LIMITS[desc['stage']]:raise ValueError('exact stage/time allocation required')
    argv=desc['argv']
    if not isinstance(argv,list)or not argv or any(not isinstance(x,str)for x in argv):raise ValueError('structured script argv required')
    if not Path(argv[0]).is_absolute()or Path(argv[0]).suffix!='.py':raise ValueError('absolute Python script entrypoint required')
    checked={}
    for expected in desc['pins']:
        actual=pin(expected['path'])
        if actual!=expected:raise ValueError('input pin differs: '+expected['path'])
        checked[actual['path']]=actual
    for required in [Path(argv[0]),E_PATH,Path(__file__)]:
        if str(required.resolve())not in checked:raise ValueError('entrypoint/guard/runner source pin missing')
    if checked[str(E_PATH.resolve())]['sha256']!=E_SHA:raise ValueError('frozen own-process guard differs')
    for p in desc['outputs']:
        p=Path(p)
        if not p.is_absolute()or not p.resolve().is_relative_to(HERE)or p.exists():raise ValueError('outputs must be new campaign-local paths')
    if not desc['outputs']:raise ValueError('declare new output paths')
    return checked
def once(descriptor,execute=False):
    descriptor=Path(descriptor).resolve();desc=json.loads(descriptor.read_text());checked=validate(desc)
    ledger=HERE/'campaign-ledger.jsonl';marker=HERE/(desc['stage']+'.once.json');journal=HERE/'analysis-ledger.jsonl'
    with ledger.open('r')as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);nn=rows(ledger);chain(nn)
        if len(nn)!=3 or nn[-1]['event']!='attempt-finish' or nn[-1]['data']['status']!='completed':raise ValueError('neural attempt must be finished successfully')
        if marker.exists():raise FileExistsError('canonical stage already attempted; no retry')
        if journal.exists()and rows(journal)[-1]['event']!='finish':raise ValueError('unfinished analysis blocks later stages')
        preview=dict(status='preview-only',stage=desc['stage'],descriptor=pin(descriptor),neural_ledger=pin(ledger),pins=list(checked.values()),seconds=desc['seconds'],argv=desc['argv'],outputs=desc['outputs'])
        if not execute:return preview
        with marker.open('x')as f:f.write(encoded(preview).decode()+'\n');f.flush();os.fsync(f.fileno())
        append(journal,'start',preview);start=time.monotonic();active=[False];status='failed';error=None;guard=None
        def audit(event,args):
            if not active[0]:return
            if event=='import'and str(args[0]).split('.')[0]in BLOCKED:raise RuntimeError('neural import forbidden')
            if event.startswith(('socket.','subprocess.','os.exec','os.spawn','os.posix_spawn'))or event in('os.system','os.fork','os.forkpty','os.killpg'):raise RuntimeError('network/process execution forbidden')
            if event=='os.kill'and args!=(os.getpid(),signal.SIGALRM):raise RuntimeError('only own guard SIGALRM allowed')
        oldargv=sys.argv[:];sys.dont_write_bytecode=True
        for key in('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
        try:
            if any(k.split('.')[0]in BLOCKED for k in sys.modules):raise RuntimeError('neural module already loaded')
            sys.addaudithook(audit);active[0]=True
            spec=importlib.util.spec_from_file_location('frozen_effect_analysis_guard',E_PATH);E=importlib.util.module_from_spec(spec);spec.loader.exec_module(E);guard=E.Guard(max(.001,desc['seconds']-(time.monotonic()-start)))
            with guard:
                sys.argv=desc['argv'][:]
                try:runpy.run_path(desc['argv'][0],run_name='__main__')
                except SystemExit as exit:
                    if exit.code not in(None,0):raise
            if any(pin(p)!=expected for p,expected in checked.items()):raise ValueError('protected input changed')
            if pin(ledger)!=preview['neural_ledger']or any(not Path(p).exists()for p in desc['outputs']):raise ValueError('neural ledger changed or declared output missing')
            status='completed'
        except BaseException as exc:error=dict(type=type(exc).__name__,message=str(exc))
        finally:active[0]=False;sys.argv=oldargv
        elapsed=time.monotonic()-start
        if elapsed>desc['seconds']:status='failed';error=error or dict(type='WallLimit',message='stage elapsed exceeded allowance')
        output_pins=[]
        for name in desc['outputs']:
            p=Path(name);output_pins.extend(pin(q)for q in sorted(p.rglob('*'))if q.is_file())if p.is_dir()else output_pins.extend([pin(p)]if p.is_file()else[])
        receipt=dict(status=status,error=error,stage=desc['stage'],active_seconds=elapsed,descriptor=pin(descriptor),guard=guard.receipt()if guard else None,outputs=output_pins,neural_forwards=0,native_applies=0,optimizer_updates=0,paid_jobs=0,paid_spend_usd=0,neural_ledger_unchanged=pin(ledger)==preview['neural_ledger'])
        append(journal,'finish',receipt)
        target=HERE/(desc['stage']+'-analysis-receipt.json')
        with target.open('x')as f:json.dump(receipt,f,indent=2,allow_nan=False);f.write('\n')
        return receipt
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--descriptor',required=True);p.add_argument('--execute',action='store_true');a=p.parse_args();r=once(a.descriptor,a.execute);print(json.dumps(r,allow_nan=False));return 0 if r['status']in('completed','preview-only')else 1
if __name__=='__main__':sys.exit(main())
