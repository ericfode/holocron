"""Byte-only link to the closed first metadata failure; no campaign work."""
import copy
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = ROOT.with_name("semantic-discrimination-v1")
EXPECTED_LEDGER = "8657e782e0523b8a694ea50b95c61ed3a0f4d9bf9e4ac24f1414cc50ed98a864"
EXPECTED_FINAL = "5edada95312903f7fadd809e311d42cf5cc1eeb080adc6d94e262cbbb0381f88"


def require(value, message):
    if not value:
        raise ValueError(message)


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def pin(path):
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def prepare():
    ledger = OLD / "campaign-ledger.jsonl"
    lp = pin(ledger)
    require(lp["sha256"] == EXPECTED_LEDGER and lp["bytes"] == 72201, "exact closed first-attempt ledger required")
    rows = [json.loads(line) for line in ledger.read_text().splitlines() if line.strip()]
    previous = "0" * 64
    for index, row in enumerate(rows):
        body = {k: v for k, v in row.items() if k != "record_sha256"}
        require(row["sequence"] == index and row["previous_sha256"] == previous
                and hashlib.sha256(encoded(body)).hexdigest() == row["record_sha256"], "failed first hash chain changed")
        previous = row["record_sha256"]
    finish = rows[-1]
    require(previous == EXPECTED_FINAL and finish["event"] == "stage-finish"
            and finish["data"]["stage"] == "metadata" and finish["data"]["status"] == "failed", "first attempt must stay closed and failed")
    d = finish["data"]
    require(d["charged"]["seconds"] == 3. and all(v == 0 for k, v in d["charged"].items() if k != "seconds"), "retain only actual first metadata reservation")
    spec = json.loads((OLD / "campaign-spec.json").read_text())
    original_prior = json.loads((OLD / "prior-manifest.json").read_text())
    require(original_prior["carry"]["charged_seconds"] == 188.08889674965758, "original linked carry changed")
    value = copy.deepcopy(original_prior)
    value["carry"]["charged_seconds"] = 191.08889674965758
    value["repair_parent"] = dict(pin=lp, records=len(rows), final_chain=EXPECTED_FINAL,
        charged_seconds=3., observed_active_seconds=d["active_seconds"], charged_native_applies=0,
        charged_neural_forwards=0, charged_optimizer_updates=0, status="failed-metadata-before-plan-preparation",
        first_source_freeze_commit=spec["provenance"]["source_freeze_commit"],
        financial_scope="Existing batch ceiling100/reserve25/operating75 unchanged; no paid work.",
        no_reuse_of_unstarted_reservations=True)
    value["closed_journals"].append(dict(pin=lp, records=len(rows), final_chain=EXPECTED_FINAL,
        closed_event="stage-finish", genesis_previous=rows[0]["previous_sha256"]))
    values = value["pins"] + spec["pins"] + [pin(__file__)]
    values += [pin(p) for p in sorted(OLD.rglob("*")) if p.is_file() and "__pycache__" not in p.parts]
    unique = {}
    for expected in values:
        require(expected["path"] not in unique or unique[expected["path"]] == expected, "conflicting old byte pins")
        require(pin(expected["path"]) == expected, "changed old pinned bytes: " + expected["path"])
        unique[expected["path"]] = expected
    value["pins"] = [unique[k] for k in sorted(unique)]
    value["protected_roots"] = sorted(set(value["protected_roots"] + [str(OLD)]))
    empty = OLD / "metadata-1"
    require(empty.is_dir() and not list(empty.iterdir()), "first failed metadata output must remain empty")
    require(not (OLD / "native-plan.json").exists(), "first failure must not gain a generated plan")
    value["provenance"] = dict(value.get("provenance", {}), repair_manifest_source=pin(__file__),
        prior_manifest=pin(OLD / "prior-manifest.json"), old_failed_spec=pin(OLD / "campaign-spec.json"),
        old_failed_stage_receipt=pin(OLD / "metadata-1-stage-receipt.json"),
        empty_failed_output_observation=dict(path=str(empty), entries=[], scope="Byte-only prelaunch observation; old root is output-protected."),
        original_protected_file_count=80, old_sources_unchanged=True,
        no_native_model_or_fit_execution=True, no_ledger_initialization=True)
    return value


if __name__ == "__main__":
    value = prepare()
    target = ROOT / "prior-manifest.json"
    raw = encoded(value) + b"\n"
    with target.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps(dict(manifest=pin(target), closed_journals=len(value["closed_journals"]),
        original_protected_files=len(value["protected_files"]), pins=len(value["pins"]), carry=value["carry"],
        no_ledger_initialized=True, no_scientific_execution=True), allow_nan=False))
