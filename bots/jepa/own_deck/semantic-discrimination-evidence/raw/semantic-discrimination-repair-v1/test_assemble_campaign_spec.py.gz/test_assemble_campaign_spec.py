import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

path = Path(__file__).with_name("assemble_campaign_spec.py")
spec = importlib.util.spec_from_file_location("assembler", path)
B = importlib.util.module_from_spec(spec)
spec.loader.exec_module(B)
A = B.load_core()


class AssemblyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()
        self.entry = self.root / "entry.py"
        self.entry.write_text("# synthetic, never executed\n")
        self.prior = self.root / "prior.json"
        self.prior.write_text(json.dumps(dict(schema="jepa-campaign-prior-manifest/1",
            carry=dict(native_applies=208, active_seconds=191.08889674965758, observed_native_applies=None),
            pins=[], protected_files=[], closed_journals=[], protected_roots=[], original_workspaces=[],
            repair_parent=dict(charged_seconds=3.,charged_native_applies=0,charged_neural_forwards=0,charged_optimizer_updates=0,
                final_chain="5edada95312903f7fadd809e311d42cf5cc1eeb080adc6d94e262cbbb0381f88"))))
        self.descriptions = self.root / "descriptions.json"
        self.d = dict(schema="jepa-campaign-stage-descriptions/1", source_closure_reviewed=True,
            stage_descriptors={s: dict(argv=[str(Path(sys.executable).resolve()), str(self.entry)],
                outputs=[str(self.root / (s + "-out"))]) for s in A.STAGE_SECONDS}, pins=[])
        self.save()

    def save(self):
        self.descriptions.write_text(json.dumps(self.d))

    def tearDown(self):
        self.tmp.cleanup()

    def test_build_metadata_only(self):
        a, spec = B.build(self.descriptions, self.prior, self.root)
        self.assertEqual(spec["caps"]["seconds"], 118.)
        self.assertEqual(spec["counter_contracts"]["native"]["expected_roots"], 33)
        self.assertFalse((self.root / "campaign-ledger.jsonl").exists())

    def test_missing_entrypoint_rejected(self):
        self.d["stage_descriptors"]["verify"]["argv"][1] = str(self.root / "absent.py")
        self.save()
        with self.assertRaisesRegex(ValueError, "missing entrypoint"):
            B.build(self.descriptions, self.prior, self.root)

    def test_unreviewed_closure_rejected(self):
        self.d["source_closure_reviewed"] = False
        self.save()
        with self.assertRaisesRegex(ValueError, "owner-reviewed"):
            B.build(self.descriptions, self.prior, self.root)

    def test_exclusive_json_and_nan_before_write(self):
        p = self.root / "out.json"
        with self.assertRaises(ValueError):
            B.exclusive_json(p, dict(x=float("nan")), A)
        self.assertFalse(p.exists())
        B.exclusive_json(p, dict(x=1), A)
        with self.assertRaises(FileExistsError):
            B.exclusive_json(p, dict(x=2), A)


if __name__ == "__main__":
    unittest.main()
