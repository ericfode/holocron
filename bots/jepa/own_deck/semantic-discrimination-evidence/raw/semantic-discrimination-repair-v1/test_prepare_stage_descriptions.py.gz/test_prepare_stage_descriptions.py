import importlib.util
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location("description_prep", Path(__file__).with_name("prepare_stage_descriptions.py"))
P = importlib.util.module_from_spec(spec)
spec.loader.exec_module(P)


class DescriptionTests(unittest.TestCase):
    def test_ast_closure_does_not_execute_sources(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "entry.py").write_text("import direct\nNAMES=('dynamic',)\nP='computed.py'\nraise RuntimeError('must never execute')\n")
            for name in ("direct", "dynamic", "computed"):
                (root / (name + ".py")).write_text("raise RuntimeError('never execute')\n")
            found = P.source_closure([root / "entry.py"], root)
            self.assertEqual({Path(v["path"]).name for v in found}, {"entry.py", "direct.py", "dynamic.py", "computed.py"})

    def test_seven_exact_stage_output_shapes(self):
        d = P.descriptors()
        self.assertEqual(list(d), ["metadata", "build", "native", "prep", "fit", "baselines", "verify"])
        self.assertEqual([len(v["outputs"]) for v in d.values()], [3, 2, 1, 2, 3, 3, 2])
        for stage, value in d.items():
            self.assertTrue(Path(value["argv"][0]).is_absolute())
            self.assertTrue(all(Path(p).is_absolute() for p in value["outputs"]))
        self.assertIn(str(P.ROOT / "native-plan.json"), d["metadata"]["outputs"])
        self.assertEqual(d["verify"]["argv"][-4:], ["--out", str(P.ROOT / "verify-result.json"), "--receipt", str(P.ROOT / "verification-receipt.json")])

    def test_wrong_commit_rejected_before_source_reads(self):
        with self.assertRaisesRegex(ValueError, "frozen source commit"):
            P.prepare("not-a-commit")


if __name__ == "__main__":
    unittest.main()
