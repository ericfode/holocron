"""Metadata-only assembler. Default previews; --write exclusively freezes JSON.

No ledger initialization, scientific import, process launch or cache mutation.
Owner-supplied descriptor JSON must contain the full reviewed source closure.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path

CAMPAIGN = Path(__file__).resolve().parent
TASK = CAMPAIGN.parents[1]
CORE = TASK / "holocron-deck-context/bots/jepa/own_deck/semantic_discrimination_repair_accounting.py"


def load_core(path=CORE):
    spec = importlib.util.spec_from_file_location("semantic_campaign_accounting", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build(description_path, prior_path, campaign_root=CAMPAIGN):
    a = load_core()
    description_path, prior_path = Path(description_path).resolve(strict=True), Path(prior_path).resolve(strict=True)
    root = Path(campaign_root).resolve()
    d = json.loads(description_path.read_text())
    a.require(d.get("schema") == "jepa-campaign-stage-descriptions/1", "reviewed stage description schema required")
    a.require(d.get("source_closure_reviewed") is True, "explicit owner-reviewed full source/input closure required")
    descriptors = d["stage_descriptors"]
    pins = {}
    def add(expected):
        a.CORE.validate_pin(expected)
        a.require(expected["path"] not in pins or pins[expected["path"]] == expected, "conflicting source/input pins")
        a.verify_pin(expected)
        pins[expected["path"]] = expected
    for expected in d["pins"] + [a.pin(description_path), a.pin(__file__), a.pin(CORE)]:
        add(expected)
    future = {p for descriptor in descriptors.values() for p in descriptor["outputs"]}
    for descriptor in descriptors.values():
        a.CORE.validate_descriptor(descriptor)
        argv = descriptor["argv"]
        entrypoints = [argv[0]] + ([argv[1]] if "python" in Path(argv[0]).name.lower() and len(argv) > 1 else [])
        for path in entrypoints:
            if Path(path).is_file():
                add(a.pin(path))
            else:
                a.require(path in future, "missing entrypoint must be an exact declared earlier build output")
    spec = a.make_spec(root, a.pin(prior_path), descriptors, list(pins.values()), sealed=True,
                       environment=d.get("environment", {}), provenance=dict(d.get("provenance", {}),
                           assembler=a.pin(__file__), description=a.pin(description_path),
                           scientific_execution=False, prior_reset=False))
    a.Campaign.validate_document(spec, root / "campaign-spec.json")
    # Pure prelaunch parent validation does not instantiate or open a ledger.
    prior = json.loads(prior_path.read_text())
    view = a.Campaign.__new__(a.Campaign)
    view.prior = prior
    view.validate_prior()
    for expected in prior["pins"] + prior["protected_files"]:
        a.verify_pin(expected)
    return a, spec


def exclusive_json(path, value, a):
    raw = a.encoded(value) + b"\n"  # Serialization completes before exclusive create.
    with Path(path).open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    return a.pin(path)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--descriptions", type=Path, required=True)
    parser.add_argument("--prior", type=Path, default=CAMPAIGN / "prior-manifest.json")
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args(argv)
    a, spec = build(args.descriptions, args.prior)
    target = CAMPAIGN / "campaign-spec.json"
    receipt = CAMPAIGN / "spec-assembly-receipt.json"
    a.require(not (CAMPAIGN / "campaign-ledger.jsonl").exists(), "existing ledger blocks reassembly; never reset")
    result = dict(schema="jepa-campaign-spec-assembly/1", status="preview-only-no-writes",
        prospective_spec=dict(path=str(target), sha256=hashlib.sha256(a.encoded(spec) + b"\n").hexdigest(), bytes=len(a.encoded(spec) + b"\n")),
        source=a.pin(__file__), accounting_source=spec["source"], prior_manifest=spec["prior_manifest"],
        stage_order=spec["stage_order"], caps=spec["caps"], pins=len(spec["pins"]),
        ledger_initialized=False, scientific_execution=False)
    if args.write:
        a.require(not target.exists() and not receipt.exists(), "exclusive new spec/receipt only")
        result["spec"] = exclusive_json(target, spec, a)
        result["status"] = "sealed-metadata-only-awaiting-root-GO"
        exclusive_json(receipt, result, a)
    print(json.dumps(result, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
