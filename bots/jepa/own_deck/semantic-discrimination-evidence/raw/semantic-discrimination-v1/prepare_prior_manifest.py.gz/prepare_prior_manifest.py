"""Read-only prior-accounting inventory; writes only a new prior manifest.

No science modules, model/engine calls, numerical fits, ledger initialization or
old-artifact writes. The source-specific unknown observed counts stay unknown.
"""
import hashlib
import json
from pathlib import Path

TASK=Path(__file__).resolve().parents[2]
EXP=TASK/'experiments'
OUT=Path(__file__).with_name('prior-manifest.json')
JOURNALS=('effect-identifiability-v2/campaign-ledger','learning-sanity-v1/campaign-ledger','learning-sanity-v1/analysis-ledger',
 'public-input-binding-v1/campaign-ledger','public-input-binding-v2/campaign-ledger','public-input-binding-v2/supplemental-verification-ledger',
 'binding-transfer-v1/campaign-ledger','binding-transfer-fixture-validation-v1/campaign-ledger','binding-transfer-v2/campaign-ledger',
 'binding-transfer-repair-v1/campaign-ledger','binding-transfer-report-recovery-v1/campaign-ledger')


def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def pin(path):
 p=Path(path).resolve();raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def read(path):return json.loads(Path(path).read_text())
def require(value,message):
 if not value:raise ValueError(message)


def inspect_journal(path):
 rows=[json.loads(line)for line in path.read_text().splitlines()if line.strip()]
 require(bool(rows),'empty closed journal')
 previous=rows[0]['previous_sha256'];genesis=previous
 for i,row in enumerate(rows):
  body={k:v for k,v in row.items()if k!='record_sha256'}
  require(row['sequence']==i and row['previous_sha256']==previous and hashlib.sha256(encoded(body)).hexdigest()==row['record_sha256'],'closed journal sequence/hash mismatch: '+str(path))
  previous=row['record_sha256']
 require(rows[-1]['event']in('attempt-finish','finish','stage-finish'),'journal not terminally closed')
 return dict(pin=pin(path),records=len(rows),final_chain=previous,closed_event=rows[-1]['event'],genesis_previous=genesis)


def main():
 require(not OUT.exists(),'preserve prior manifest; no overwrite')
 journals=[inspect_journal(EXP/(name+'.jsonl'))for name in JOURNALS]
 latest=EXP/'binding-transfer-report-recovery-v1';closure=read(latest/'experiment-closure.json');handoff=read(latest/'publication-handoff.json')
 require(closure['native']['cumulative_charged_applications']==208 and closure['budget']['cumulative_charged_seconds']==188.08889674965758,'authoritative prior carry changed')
 require(closure['closed_campaign']['pending']is None and not closure['closed_campaign']['violated'],'latest prior campaign is unresolved')
 snapshot=EXP/'next-cycle-preservation-v1/protected-before.json';before=read(snapshot);protected={}
 for p in before['protected_files']+before['additional_protected_artifacts']:
  q={k:p[k]for k in('path','sha256','bytes')};require(q['path']not in protected or protected[q['path']]==q,'conflicting prior byte pin');protected[q['path']]=q
 require(len(protected)==80 and len(before['original_workspaces'])==3,'original preservation scope changed')
 # Verify bytes, without launching Git in any original workspace.
 for expected in protected.values():require(pin(expected['path'])==expected,'protected bytes changed: '+expected['path'])
 pins={p['path']:p for p in protected.values()}
 for path in(Path(__file__),snapshot,latest/'experiment-closure.json',latest/'publication-handoff.json',*(Path(j['pin']['path'])for j in journals)):
  value=pin(path);pins[value['path']]=value
 # Existing closure/index manifests suffice; do not crawl large archives.
 for name in('evidence',):
  for value in handoff.get(name,{}).values():
   if isinstance(value,dict)and set(('path','sha256','bytes'))<=set(value)and Path(value['path']).is_file():
    p={k:value[k]for k in('path','sha256','bytes')};require(pin(p['path'])==p,'publication evidence pin changed');pins[p['path']]=p
 pointer_candidates=[TASK/'holocron-deck-context/bots/jepa/own_deck/research-feed/current.json',TASK/'experiments/publication-feed/current.json']
 pointers=[pin(p)for p in pointer_candidates if p.is_file()]
 for p in pointers:pins[p['path']]=p
 value=dict(schema='jepa-campaign-prior-manifest/1',carry=dict(charged_native_applies=208,charged_seconds=188.08889674965758,observed_native_applies=None,
   scope='Closed binding experiments only; earlier PR36/37 and other historical scopes remain separately linked.',
   failed_fit_official_observed=dict(neural_forwards=None,optimizer_updates=None),known_durable_failed_fit_prefix=dict(neural_forwards=5436,optimizer_updates=5400),
   report_recovery_scope=dict(numerical_fit_attempts=64,actual_lstsq_solver_calls=64,new_neural_forwards=0,new_optimizer_updates=0),paid_spend_usd=0),
  pins=sorted(pins.values(),key=lambda p:p['path']),closed_journals=journals,protected_files=sorted(protected.values(),key=lambda p:p['path']),
  protected_roots=sorted({str((EXP/name).parent.resolve())for name in JOURNALS}|{w['path']for w in before['original_workspaces']}),
  original_workspaces=before['original_workspaces'],provenance=dict(source=pin(__file__),latest_closure=pin(latest/'experiment-closure.json'),publication_handoff=pin(latest/'publication-handoff.json'),
   previous_current_pointer=before.get('previous_current_pointer'),current_local_pointer_pins=pointers,original_112_charge_snapshot=pin(snapshot),
   original_112_charge=before['closed_current_study_accounting'],old_failure_records_preserved=True,
   original_workspace_status='Frozen saved records reused; no new Git invocation.',no_scientific_imports_or_execution=True))
 with OUT.open('x')as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
 print(json.dumps(dict(manifest=pin(OUT),journals=len(journals),protected_files=len(protected),original_workspaces=3,ledger_initialized=False,scientific_calls=0)))


if __name__=='__main__':main()
