"""Read-only source/env closure and exact seven commands; --write freezes JSON.

Run after owners HOLD their sources. No scientific imports, ledger, subprocess,
package install, native preparation, model call or fitted transform is used.
"""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TASK = ROOT.parents[1]
OWN = TASK / "holocron-deck-context/bots/jepa/own_deck"
ENGINE = Path("/Users/ericfode/Documents/Codex/2026-10-17/task-5/kessel-pilot-source")
VENV = Path("/Users/ericfode/src/crown-jepa/.venv")
PYTHON = (VENV / "bin/python").resolve()
SITE = VENV / "lib/python3.11/site-packages"
ARCHIVES = [Path("/Users/ericfode/.cache/uv/archive-v0") / name for name in (
    "rehTsShR29rpWi8Dqz5BL", "ntYsJgeLWxSB0rhe6n9sh", "5i8dYw1S9c5zrvrF0rCIy",
    "C7W22kpzl1cAe-Hdx0N-2", "F1isPlsf9ooQ4EGhGPl5V", "PVyRmcnszTpMFeVdyuyJs",
    "fDmWyEr9slZLLcHdlujql", "khxszcG0X4WuYCMH_DEdE", "7h7hIgcQT6GjZZGqqRrhM")]


def require(value, message):
    if not value:
        raise ValueError(message)


def pin(path):
    path = Path(path).resolve(strict=True)
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def source_closure(entrypoints, own=OWN):
    """AST/literal-local lookup only; computed routes remain explicitly seeded."""
    pending, found = [Path(p).resolve(strict=True) for p in entrypoints], set()
    while pending:
        path = pending.pop()
        if path in found:
            continue
        found.add(path)
        if path.suffix != ".py":
            continue
        tree, names, literals = ast.parse(path.read_text(), filename=str(path)), set(), set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names.update(a.name.split(".")[0] for a in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                names.add(node.module.split(".")[0])
            elif isinstance(node, ast.Constant) and isinstance(node.value, str):
                if (own / (node.value + ".py")).is_file():
                    names.add(node.value)
                if node.value.endswith(".py"):
                    literals.add(node.value)
        candidates = [own / (name + ".py") for name in names]
        for literal in literals:
            candidate = Path(literal)
            candidates += ([candidate] if candidate.is_absolute() else [path.parent / candidate, own / candidate])
        pending.extend(p.resolve() for p in candidates if p.is_file())
    return [pin(p) for p in sorted(found)]


def environment_pins():
    values = [pin(PYTHON), pin(VENV / "pyvenv.cfg")]
    distributions = {}
    for root, name in [(SITE, "numpy")] + [(p, None) for p in ARCHIVES]:
        require(root.is_dir(), "existing cached dependency required; no installation: " + str(root))
        matches = sorted(root.glob((name + "-" if name else "") + "*.dist-info"))
        require(len(matches) == 1, "one expected installed distribution per root")
        distribution = matches[0]
        package = name or distribution.name.split("-")[0]
        pins = [pin(distribution / part) for part in ("METADATA", "RECORD", "WHEEL")]
        pins += [pin(p) for p in (root / package / "__init__.py", root / (package + ".py")) if p.is_file()]
        values += pins
        distributions[package] = dict(root=str(root), distribution=str(distribution), pins=pins)
    environment = dict(PYTHONPATH=os.pathsep.join(map(str, [OWN, SITE, *ARCHIVES])),
        PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
        MKL_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1", NUMEXPR_NUM_THREADS="1")
    return values, environment, distributions


def descriptors():
    py, worker, spec = str(PYTHON), str(OWN / "semantic_discrimination_fit.py"), str(ROOT / "campaign-spec.json")
    prefix = [py, worker, "--spec", spec]
    plan = str(ROOT / "prep-1/sealed-fit-plan.json")
    native_plan = str(ROOT / "native-plan.json")
    binary = TASK / "experiments/typed-ir-microprobe/target/debug/semantic-discrimination-native-collector"
    crate = OWN / "semantic_discrimination_native_collector"
    return dict(
        metadata=dict(argv=prefix + ["metadata", "--native-plan", native_plan, "--out", str(ROOT / "metadata-1")],
            outputs=[native_plan, str(ROOT / "metadata-1"), str(ROOT / "metadata-1-stage-receipt.json")]),
        build=dict(argv=["/Users/ericfode/.cargo/bin/cargo", "build", "--offline", "--locked", "--manifest-path", str(crate / "Cargo.toml"),
            "--bin", "semantic-discrimination-native-collector", "-j", "1"], outputs=[str(ROOT / "native-build-1"), str(binary)]),
        native=dict(argv=[str(binary), str(ROOT / "native-attempt-1/native-receipt.json")], outputs=[str(ROOT / "native-attempt-1")]),
        prep=dict(argv=prefix + ["prep", "--native-receipt", str(ROOT / "native-attempt-1/native-receipt.json"),
            "--journal", str(ROOT / "native-attempt-1/native-transitions.jsonl"), "--native-plan", native_plan,
            "--metadata", str(ROOT / "metadata-1/learner-prepared.json"), "--out", str(ROOT / "prep-1")],
            outputs=[str(ROOT / "prep-1"), str(ROOT / "prep-1-stage-receipt.json")]),
        fit=dict(argv=prefix + ["fit", "--plan", plan, "--out", str(ROOT / "fit-1"), "--progress", str(ROOT / "fit-progress.jsonl")],
            outputs=[str(ROOT / "fit-1"), str(ROOT / "fit-progress.jsonl"), str(ROOT / "fit-1-stage-receipt.json")]),
        baselines=dict(argv=prefix + ["baselines", "--plan", plan, "--fit-result", str(ROOT / "fit-1/result.json"),
            "--out", str(ROOT / "baselines-1"), "--progress", str(ROOT / "baseline-progress.jsonl")],
            outputs=[str(ROOT / "baselines-1"), str(ROOT / "baseline-progress.jsonl"), str(ROOT / "baselines-1-stage-receipt.json")]),
        verify=dict(argv=[py, str(OWN / "semantic_discrimination_verify.py"), "--spec", spec, "--plan", plan,
            "--fit-dir", str(ROOT / "fit-1"), "--fit-progress", str(ROOT / "fit-progress.jsonl"),
            "--baselines-dir", str(ROOT / "baselines-1"), "--baseline-progress", str(ROOT / "baseline-progress.jsonl"),
            "--out", str(ROOT / "verify-result.json"), "--receipt", str(ROOT / "verification-receipt.json")],
            outputs=[str(ROOT / "verify-result.json"), str(ROOT / "verification-receipt.json")]))


def prepare(source_freeze_commit):
    require(len(source_freeze_commit) == 40 and all(c in "0123456789abcdef" for c in source_freeze_commit), "actual frozen source commit required")
    entries = sorted(OWN.glob("semantic_discrimination*.py")) + sorted(OWN.glob("test_semantic_discrimination*.py"))
    # Explicit computed routes and the original source-only algebra/guard are
    # seeds even if they are referenced by a dynamically selected module name.
    entries += [OWN / name for name in ("binding_transfer_data_v2.py", "learning_sanity_data.py", "effect_identifiability_fit.py",
        "public_input_binding_model_v1.py", "whole_card_encoder.py")]
    entries += [Path(__file__), ROOT / "assemble_campaign_spec.py", ROOT / "prepare_prior_manifest.py"]
    entries += sorted(ROOT.glob("test_*.py"))
    closure = source_closure(entries)
    crate = OWN / "semantic_discrimination_native_collector"
    closure += [pin(p) for p in sorted(crate.rglob("*")) if p.is_file() and "__pycache__" not in p.parts and "target" not in p.parts]
    closure += [pin(OWN / "SEMANTIC_DISCRIMINATION_PROTOCOL.md"), pin(ENGINE / "Cargo.toml"), pin(ENGINE / "Cargo.lock")]
    closure += [pin(p) for p in sorted((ENGINE / "crates/kessel").rglob("*")) if p.is_file() and "target" not in p.parts]
    closure += [pin(p) for p in sorted((ENGINE / "compiler/generated").glob("*.json"))]
    closure += [pin(TASK / "experiments/actual-corpus/coverage-v2/actual-corpus-coverage.json"), pin("/Users/ericfode/.cargo/bin/cargo")]
    target = TASK / "experiments/typed-ir-microprobe/target/debug"
    preserved = [pin(target / name) for name in ("binding-transfer-native-collector", "binding-transfer-fixture-validator")]
    require([p["sha256"] for p in preserved] == ["f7bdbbef31a08aaeb4c3fb28be04bcece3a82782849fbc829b98ba59922dbaeb",
        "b87a950a132f0e88b1edf7a9f7d83257306f68cc2d15184f11271df3691060ad"], "protected prior binaries changed")
    closure += preserved
    env_pins, environment, distributions = environment_pins()
    closure += env_pins
    unique = {}
    for p in closure:
        require(p["path"] not in unique or unique[p["path"]] == p, "conflicting closure pin")
        unique[p["path"]] = p
    return dict(schema="jepa-campaign-stage-descriptions/1", source_closure_reviewed=True,
        stage_descriptors=descriptors(), pins=[unique[k] for k in sorted(unique)], environment=environment,
        provenance=dict(source_freeze_commit=source_freeze_commit, preparation="AST/byte-only; no imported scientific code",
            dependency_scope="Installed METADATA/RECORD/WHEEL and import entrypoints pinned; not complete wheel-file attestation.",
            dependencies=distributions, cached_archives=list(map(str, ARCHIVES)),
            computed_routes_explicit=["binding_transfer_data_v2", "learning_sanity_data", "effect_identifiability_fit", "public_input_binding_model_v1", "whole_card_encoder"],
            mutable_build_cache_scope="Existing target directory is a warm mutable cache, not a frozen scientific input; compiled binary is new and pinned by completed build.",
            no_scientific_execution=True, no_ledger_initialization=True))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-freeze-commit", required=True)
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    value = prepare(args.source_freeze_commit)
    raw = (json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
    target = ROOT / "stage-descriptions.json"
    require(not (ROOT / "campaign-ledger.jsonl").exists(), "never prepare over initialized campaign")
    if args.write:
        with target.open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
    print(json.dumps(dict(status="metadata-frozen" if args.write else "preview-only-no-writes", path=str(target),
        sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), pins=len(value["pins"]),
        stage_descriptors=value["stage_descriptors"], ledger_initialized=False, scientific_execution=False), allow_nan=False))


if __name__ == "__main__":
    main()
